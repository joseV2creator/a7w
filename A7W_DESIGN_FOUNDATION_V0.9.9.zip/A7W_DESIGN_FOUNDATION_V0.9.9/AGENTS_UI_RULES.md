# Regras de UI/UX para agentes — A7W Platform

Estas regras devem ser incorporadas ao `AGENTS.md` oficial quando o repositório GitHub for criado.

1. Não redesenhar uma tela inteira para resolver um detalhe local.
2. Preservar funcionalidades e rotas existentes salvo decisão explícita.
3. Antes de criar componente complexo, consultar `DESIGN_REFERENCES.md`.
4. Classificar referência como inspiração, padrão ou dependência open source.
5. Não adicionar biblioteca apenas por estética.
6. Toda dependência deve ter licença, peso e manutenção avaliados.
7. Usar `A7W_DESIGN_SYSTEM.md` para spacing, motion, estados, cores e comportamento.
8. Skeleton somente para carregamento perceptível e previsível.
9. Lazy loading somente para conteúdo realmente adiável/pesado.
10. Progresso somente quando houver progresso real.
11. Interações de alta frequência devem ser rápidas e discretas.
12. Respeitar `prefers-reduced-motion`.
13. Não usar scale/glow/pulsação como efeito padrão.
14. Toda tela deve possuir estados: loading, vazio, erro, sucesso quando aplicável.
15. Desktop e mobile devem ser validados antes de merge.
16. Sarah deve respeitar permissão do usuário antes de apresentar dados sensíveis.
17. Mudanças grandes de arquitetura visual devem ser propostas e auditadas antes de implementação.
