# A7W Platform — Design System v0.1

Objetivo: uma interface moderna, sofisticada, silenciosa e operacional. O usuário deve perceber qualidade sem sentir que a interface está tentando chamar atenção para si mesma.

## 1. Princípios

### Clareza antes de decoração
Dados, ações e estado operacional têm prioridade sobre efeitos.

### Sofisticação por sutileza
Separar áreas principalmente por espaço, contraste suave, tipografia e hierarquia. Evitar excesso de bordas, sombras e cartões.

### Movimento com propósito
Animação deve indicar causa, consequência, continuidade ou mudança de contexto.

### Consistência
Uma nova tela não inventa novos botões, novos cards e nova linguagem visual sem necessidade.

### Mapa é ferramenta, não fundo
Na Gestão de Frota o mapa deve ser dominante. Painéis aparecem para explicar ou controlar o mapa, não para escondê-lo.

## 2. Superfícies

Direção visual:
- fundo geral quase branco/cinza muito claro;
- sidebar em tom discretamente diferente;
- cards apenas quando houver agrupamento real;
- bordas de baixo contraste;
- azul A7W reservado para ação, seleção e informação institucional;
- vermelho reservado para erro/risco real;
- âmbar reservado para atenção;
- verde reservado para sucesso/online/concluído.

## 3. Espaçamento

Escala sugerida:
- 4 px — microajustes;
- 8 px — elementos relacionados;
- 12 px — controles compactos;
- 16 px — espaço padrão;
- 24 px — separação de grupos;
- 32 px — seções;
- 48 px — divisões maiores.

Evitar valores aleatórios fora da escala sem motivo visual claro.

## 4. Bordas e raio

- controles pequenos: 8–10 px;
- cards: 12–16 px;
- dialogs/painéis premium: 16–20 px;
- pills: 999 px somente quando semanticamente são pills/status.

## 5. Hover e foco

Hover padrão:
- mudança suave de fundo/contraste;
- ícone pode deslocar 1–2 px quando isso comunicar direção;
- nada de scale forte em cards;
- sombra só aumenta quando o elemento realmente sobe de camada.

Foco:
- sempre visível por teclado;
- contraste suficiente;
- não remover outline sem substituição acessível.

## 6. Motion

Tempos recomendados:
- hover/foco: 100–160 ms;
- dropdown/tooltip: 120–180 ms;
- painel/drawer: 180–240 ms;
- mudança de contexto/página: 200–320 ms;
- mapa/câmera: duração adaptada à distância, sem movimentos bruscos.

Curvas:
- entradas: desaceleração suave;
- saídas: ligeiramente mais rápidas que entradas;
- não usar bounce em operação séria.

Não animar:
- dados que atualizam a cada poucos segundos;
- toda linha de tabela;
- números críticos a cada refresh;
- qualquer coisa cuja animação atrase uma ação repetitiva.

Sempre respeitar `prefers-reduced-motion`.

## 7. Loading

### Ação curta
Até ~300 ms: normalmente nenhum spinner.

### Conteúdo previsível
Usar skeleton quando a estrutura da tela é conhecida e a espera é perceptível.

### Ação com estado real
Mostrar progresso somente quando houver progresso mensurável.

### Mapas e módulos pesados
Carregar o shell primeiro e o recurso pesado depois.

## 8. Empty states

Todo estado vazio deve explicar:
- o que está vazio;
- por que pode estar vazio;
- qual ação o usuário pode tomar.

Evitar simplesmente “Nenhum resultado”.

## 9. Tabelas e dados

- cabeçalhos claros;
- densidade adequada ao uso operacional;
- números alinhados de forma consistente;
- ações secundárias aparecem por contexto, sem poluir cada linha;
- filtros persistentes quando úteis;
- no celular, priorizar as 2–4 informações mais importantes e levar o restante para detalhe.

## 10. Sarah

Sarah não deve parecer um chatbot anexado ao sistema.

Padrões desejados:
- presença discreta no shell;
- painel lateral contextual;
- pode explicar a tela atual;
- pode destacar anomalias;
- pode sugerir ações;
- acesso e permissões sempre respeitados antes de responder;
- alertas importantes distinguem fato, interpretação e sugestão.

## 11. Gestão de Frota

Ao selecionar veículo:
- destaque visual do veículo;
- demais veículos perdem prioridade sem desaparecer;
- painel de contexto aparece com transição curta;
- rota/histórico relevante ganha destaque;
- câmera pode ajustar enquadramento suavemente;
- heading deve futuramente orientar o ícone continuamente.

## 12. Proibições visuais

Evitar como padrão:
- glow azul em tudo;
- gradientes decorativos sem função;
- glassmorphism excessivo;
- cards dentro de cards dentro de cards;
- hover que aumenta todos os componentes;
- animação infinita em elementos não críticos;
- ícones sem rótulo quando o significado não é universal;
- misturar cinco estilos de botão na mesma tela.
