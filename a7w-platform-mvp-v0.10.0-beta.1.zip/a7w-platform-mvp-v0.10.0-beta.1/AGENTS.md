# A7W Platform — Regras para agentes

Base desta linha: v0.9.9 funcional. Evolução visual iniciada em v0.10.0-beta.1.

## Regra principal

Não destruir o legado para resolver uma melhoria local. Banco, telemetria, Sarah, relatórios e rotas existentes devem ser preservados salvo decisão explícita e testada.

## Arquitetura da informação

Antes de criar uma página ou controle novo, consulte:
- `INFORMATION_ARCHITECTURE_AUDIT.md`;
- `A7W_DESIGN_SYSTEM.md`;
- `DESIGN_REFERENCES.md`;
- `UI_ROADMAP.md`.

Toda função deve responder: qual problema resolve, quem usa, com que frequência e em qual domínio o usuário procuraria naturalmente por ela.

## UI/UX

- Clareza antes de decoração.
- Não adicionar biblioteca apenas por estética.
- Antes de criar componente complexo, estudar referência madura e compatível.
- Motion rápido e discreto; sem glow, scale forte ou pulsação como padrão.
- Skeleton somente para carregamento perceptível e previsível.
- Progresso somente quando houver progresso real.
- Respeitar `prefers-reduced-motion`.
- Desktop e mobile devem permanecer utilizáveis.
- Estados de foco por teclado não podem desaparecer.

## Sarah

Sarah possui domínio próprio no produto. Configuração de canal, cérebro, voz e orçamento não deve voltar a ser misturada com regras de telemetria.

Antes de liberar Sarah em outros aparelhos, implementar identidade e permissões por usuário/canal. Localização e telemetria sensível não podem ser respondidas apenas porque alguém afirma ser José.

## Gestão de Frota

O mapa é ferramenta central, não decoração. Evoluções de mapa devem preservar o fluxo funcional atual. MapLibre é evolução planejada; não migrar apenas por aparência. Geofence e saída de rota só podem gerar fatos quando houver geometria/regra confiável.

## GitHub quando o repositório oficial estiver conectado

Mudanças relevantes devem seguir Issue → branch → testes → Pull Request → merge → deploy. O PR deve referenciar a Issue. Não criar burocracia para correções triviais de texto, mas bugs, novas funções, mudanças de arquitetura e segurança devem ser rastreáveis.
