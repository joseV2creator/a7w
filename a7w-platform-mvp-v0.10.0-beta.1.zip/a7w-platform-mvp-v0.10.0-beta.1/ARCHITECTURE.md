# A7W Platform — arquitetura do novo núcleo

## Decisão central

O A7W Track legado continua existindo até a nova plataforma superar suas funções. A A7W Platform é um núcleo paralelo e modular, com o **PEDIDO** como eixo entre comercial, operação, logística, entrega e relacionamento.

## Experiências separadas

Mesmo hospedado em `beta.a7w.com.br` durante o desenvolvimento, o sistema usa páginas e permissões independentes. A evolução futura pode distribuir as mesmas experiências em:

- `admin.a7w.com.br`
- `comercial.a7w.com.br`
- `operacao.a7w.com.br`
- `logistica.a7w.com.br`
- `clientes.a7w.com.br`

A separação visual não substitui autorização: o backend filtra dados por `role`, `seller_user_id`, `driver_id` e `company_id`.

## Camadas

1. **Identidade e acesso** — usuários, perfis, sessões e auditoria.
2. **B2B** — empresas, compradores, catálogo, carrinho e pedidos.
3. **Comercial** — carteira, cotações e vendas do vendedor.
4. **Operação** — análise, crédito, preparação, faturamento e expedição.
5. **Logística** — motorista, veículo, entregas, rota e comprovantes.
6. **Tracking** — pontos GPS, estado atual, métricas, paradas e histórico.
7. **Integrações** — eventos para n8n, mapas e e-mail transacional.

## Tracking

A posição recebida é guardada em `platform_location_points`. O estado mais recente fica em `platform_tracking_devices`. O vínculo motorista/veículo/dispositivo continua em `platform_assignments`.

O cálculo do MVP considera intervalos, distância geodésica, velocidade reportada/calculada, precisão e lacunas de sinal. As métricas precisam ser validadas em trajetos reais antes de virarem indicador disciplinar ou financeiro.

O planejamento de paradas usa `platform_route_stops`, separado do histórico GPS. Isso evita confundir **rota planejada** com **rota realmente percorrida**.

## Busca e mapas

A camada atual usa Leaflet/OpenStreetMap para visualização. A busca de lugares pode usar Google Places sem exigir que todo o mapa já tenha sido migrado para Google Maps. Isso permite medir custo e qualidade antes de uma troca completa de provedor.

## n8n

A tabela `platform_integration_events` mantém eventos operacionais para automação. O n8n reage a eventos, mas não substitui o banco principal nem as regras de autorização.

## Próximas fases

- validação real do rastreamento com aparelho corporativo;
- geofences e chegada automática;
- comprovante de entrega completo;
- detalhamento corporativo de clientes e contatos;
- conversão cotação → pedido;
- roteirização com distância/ETA de estrada;
- Google Maps/Routes/Places com orçamento e quotas;
- verificação de e-mail, recuperação de senha e 2FA;
- n8n, notificações e observabilidade;
- VPS endurecida, backups e armazenamento de documentos.


## Decisão de mapas e rotas após 0.5.0
- monitoramento atual: Leaflet + tiles LocationIQ/OpenStreetMap;
- rastreamento definitivo: Traccar;
- visual 3D futuro: MapLibre GL JS com provedor vetorial/terreno (avaliar MapTiler);
- roteirização é serviço separado do Traccar; avaliar HERE Routing + Waypoints Sequence para sequência de entregas e alternativas;
- não acoplar telemetria, mapa e otimização como se fossem a mesma tecnologia.


## 0.6.0 — Gestão de Frota e comprovantes

O módulo antes chamado Rastreamento passa a ser Gestão de Frota. A UI separa monitoramento, rotas/entregas, frota/locais e relatórios. A prova de conclusão é persistida em `platform_delivery_proofs` e vinculada à entrega. Para o MVP atual, fotos são reduzidas no navegador e armazenadas no MySQL; em produção com volume maior, migrar os binários para object storage e manter apenas URL/hash/metadados no banco.

## v0.8.3 · Sarah Rodrigues / cérebro operacional

Fluxo atual sem n8n:

Telegram -> webhook HTTPS da A7W -> parser local / Gemini -> consultas locais A7W -> Telegram.

Princípios:
- `TELEGRAM_CHAT_ID` funciona como allowlist inicial: outros chats não recebem dados operacionais.
- Webhook usa `secret_token` derivado no servidor; ele não precisa ser exposto como nova variável.
- `GEMINI_API_KEY` fica apenas no backend.
- Perguntas simples conhecidas podem ser interpretadas localmente para economizar quota/latência.
- Gemini interpreta linguagem livre e áudio; não recebe a telemetria bruta do banco.
- Localização, velocidade, bateria, rota e demais fatos são buscados no MySQL e respondidos deterministicamente.
- Mensagens de voz são processadas em memória, sem gravação permanente do arquivo de áudio.
- A memória curta enviada ao Gemini contém apenas mensagens do usuário, não respostas operacionais com telemetria.

Quando Traccar/n8n entrarem, a interface conversacional permanece e a camada de ferramentas troca a fonte dos dados.

## v0.8.3 · cérebro conversacional + condition watches
A Sarah continua usando o Gemini apenas como camada de linguagem. Dados operacionais permanecem locais. Para pedidos do tipo “me avise quando...”, a aplicação grava uma observação persistente em `platform_sara_watches` e o backend reavalia as condições periodicamente. O Telegram é notificado diretamente quando a condição muda para verdadeira; n8n não é necessário nesta fase.


## v0.8.3 · personalidade Sarah + fallback gratuito
- Modelo Gemini padrão atualizado para `gemini-3.8-flash`.
- Personalidade da Sarah refinada: doce, suave, acolhedora, inteligente, segura e profissional, sem teatralidade.
- Confirmações de avisos usam linguagem natural, por exemplo: `Anderson já está disponível, senhor.`
- Comandos operacionais claros continuam funcionando localmente sem consumir IA.
- Fallback opcional Groq para conversa/classificação quando a cota do Gemini falhar.
- Áudio pode usar `whisper-large-v3-turbo` no Groq como fallback.
- Variáveis opcionais: `GROQ_API_KEY`, `GROQ_MODEL`, `GROQ_TRANSCRIBE_MODEL`.
- Nenhuma API hospedada gratuita é ilimitada; o modo local garante continuidade das funções operacionais básicas.

## v0.9.0 · Sarah Voice Core + AI Router + telemetria de uso

A Sarah passa a separar identidade, ferramentas e provedores de IA. Comandos operacionais claros continuam sendo resolvidos localmente; linguagem natural pode usar Gemini, Groq e DeepSeek como fallback configurável. A saída de voz usa Gemini 3.1 Flash TTS Preview e o Telegram recebe voice note por `sendVoice`.

A camada atual ainda vive dentro do Beta, por decisão de etapa. Na futura KVM4, o mesmo contrato deverá ser extraído para `sara-api` / `sara-worker`, sem dar acesso direto da IA aos bancos da A7W ou do Traccar.

O medidor `platform_sara_usage` registra provedor, modelo, finalidade, tokens, áudio, falha e estimativa de custo. O teto mensal fica em `platform_sara_settings`; a v0.9.0 mede e apresenta, mas ainda não bloqueia provedores por orçamento. Esse bloqueio pertence ao futuro Spend Governor.


## v0.10.0-beta.1 — Design Foundation e arquitetura da informação

A interface passa a ter uma navegação centralizada por perfil em `public/js/common.js`, evitando que cada página invente seu próprio menu. A organização interna segue domínios: Gestão de Frota, Sarah, Administração e os portais específicos por papel.

Sarah passa a ter uma superfície própria (`/sarah`). Eventos & Alertas mantém somente telemetria e regras da frota. As APIs e tabelas existentes da Sarah são reaproveitadas; não há duplicação de configuração.

O mapa continua em Leaflet nesta fase para preservar estabilidade. A v0.10.0-beta.1 melhora a experiência ao redor do mapa; a migração para MapLibre é uma mudança arquitetural futura e deve ocorrer em gate separado.

Documentos de produto que passam a orientar alterações futuras: `A7W_DESIGN_SYSTEM.md`, `DESIGN_REFERENCES.md`, `INFORMATION_ARCHITECTURE_AUDIT.md`, `UI_ROADMAP.md`, `DECISION_LOG.md` e `AGENTS.md`.
