# CODEBASE MAP — v0.10.0-beta.1

## Objetivo

Primeiro incremento da A7W Design Foundation sem reescrever o motor funcional da v0.9.9.

## `public/js/common.js`
- navegação interna passa a ser montada por perfil em um único lugar;
- sidebar agrupada por domínio e recolhível;
- Sarah aparece como domínio próprio para admin/gerência;
- ícones SVG internos, hover/focus e acesso rápido à Sarah;
- subnavegação de Gestão de Frota inclui Monitoramento, Rotas, Frota, Eventos e Relatórios.

## `public/css/app.css`
- tokens e motion da nova fundação visual;
- shell mais silencioso e consistente;
- foco acessível e `prefers-reduced-motion`;
- spinner apenas em botões com ação real;
- utilitário de skeleton disponível, sem aplicar indiscriminadamente;
- estilos dos novos controles do mapa;
- layout da Central Sarah.

## `public/sarah.html` + `public/js/sarah.js`
- nova área `/sarah`;
- Telegram, AI Router, voz, política texto/áudio, uso e orçamento saem de Eventos & Alertas;
- usa as APIs existentes, sem duplicar configuração no banco.

## `public/tracking-events.html` + `public/js/tracking-events.js`
- volta a focar em eventos e regras da frota;
- mostra link para a Central Sarah;
- não carrega mais polling/configuração da Sarah nessa tela.

## `public/tracking.html` + `public/js/tracking.js`
- mapa continua em Leaflet nesta etapa;
- zoom passa para a pilha de controles à direita;
- Minha localização via navegador;
- enquadrar rota/veículo/referências;
- tela cheia;
- estilos A7W Claro, A7W Escuro e OpenStreetMap;
- preferência de estilo persiste em `localStorage`;
- satélite/híbrido não são simulados: ficam para MapLibre/provedor homologado.

## Backend
- `/sarah` protegido para `admin` e `manager`;
- `/health` e `/api/version` = `0.10.0-beta.1`;
- nenhuma migração destrutiva;
- novo changelog aditivo.
