# A7W Platform v0.9.3 — mapa da base

Base direta da v0.9.1. Nenhum módulo de negócio foi refeito.

## Correção de voz
`src/routes/telegram-assistant.js` mantém todo o fluxo da Sarah.

Fluxo de saída v0.9.3:

Sarah texto → Gemini `gemini-3.1-flash-tts-preview` → PCM bruto 24 kHz/16-bit/mono → `@breezystack/lamejs` → MP3 64 kbps → Telegram `sendVoice`.

O Gemini não recebe mais `mime_type` de MP3 ou OGG no `response_format`.

## Groq
Permanece inalterado:
- `GROQ_MODEL=openai/gpt-oss-20b`
- `GROQ_TRANSCRIBE_MODEL=whisper-large-v3-turbo`

## Identidade
Nome visível: **Sarah Rodrigues**. Identificadores técnicos legados `sara_*` são preservados para compatibilidade.
