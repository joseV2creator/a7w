# A7W Platform v0.9.4 — mapa rápido

- `src/routes/telegram-assistant.js`: cérebro da Sarah, Groq STT, AI Router, Fish Audio TTS primário, Gemini TTS fallback, Telegram.
- `src/routes/tracking.js`: endpoints de status/teste/configuração da Sarah.
- `public/js/tracking-events.js`: painel Sarah Voice / uso / status.
- `src/schema.js`: tabelas `platform_sara_*` e changelog.
- `.env.example`: variáveis de IA/TTS.
- `server.js`: bootstrap e `/health`.
