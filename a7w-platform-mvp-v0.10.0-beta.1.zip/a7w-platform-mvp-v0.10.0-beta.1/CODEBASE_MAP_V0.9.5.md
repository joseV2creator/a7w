# A7W Platform v0.9.5 — mapa rápido

## Mudanças centrais

- `src/routes/telegram-assistant.js`
  - personalidade contextual da Sarah Rodrigues;
  - `typing` renovado enquanto processa;
  - `record_voice` durante geração de áudio e `upload_voice` durante envio;
  - Fish Audio com direção vocal automática por contexto;
  - `usage_report` por conversa;
  - medição mensal de uso, saldo do teto e Spend Governor mínimo;
  - DeepSeek desligado por padrão;
  - áudio proativo ocasional configurável por `SARA_PROACTIVE_VOICE_RATE`.

- `public/tracking-events.html`
  - remove seletor de vozes antigas;
  - mostra Sarah Rodrigues como voz oficial;
  - mantém política de voz, teto mensal e câmbio.

- `public/js/tracking-events.js`
  - painel passa a exibir custo, saldo restante, chamadas Fish, segundos de áudio e janela gratuita configurada.

- `.env.example`
  - `FISH_FREE_ACCESS_UNTIL=2026-11-30`
  - `SARA_PROACTIVE_VOICE_RATE=0.15`
  - `DEEPSEEK_ENABLED=false`

## Compatibilidade

- Banco existente preservado.
- Tabelas técnicas `platform_sara_*` mantidas por compatibilidade.
- Fish continua voz principal; Gemini TTS permanece fallback.
- Telegram continua canal atual; WhatsApp permanece etapa posterior.
