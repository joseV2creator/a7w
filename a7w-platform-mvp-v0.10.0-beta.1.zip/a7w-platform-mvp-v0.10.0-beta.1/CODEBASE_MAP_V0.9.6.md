# CODEBASE MAP — v0.9.6

- `src/routes/telegram-assistant.js`: personalidade, memória, IA Router, voz Fish/Gemini, relatórios históricos, mensagens e alertas proativos.
- `src/routes/tracking.js`: geração de eventos de frota e encaminhamento dos eventos relevantes para Sarah.
- `src/schema.js`: memória persistente da Sarah e migrações de configuração.
- `server.js`: health v0.9.6.
