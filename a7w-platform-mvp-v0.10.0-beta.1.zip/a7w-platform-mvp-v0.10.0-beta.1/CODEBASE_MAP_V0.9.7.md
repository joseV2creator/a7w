# CODEBASE MAP — v0.9.7

## Arquivos alterados
- `src/routes/telegram-assistant.js`: parser histórico de datas, consulta de velocidade máxima, resolução contextual de motorista/veículo e normalização fonética para TTS.
- `src/schema.js`: memória persistente reforçada para nome preferido José / normalização Joseph/Josef.
- `server.js`, `src/routes/core.js`, `package.json`: versão 0.9.7.
- `README.md`: notas da versão.
