# CODEBASE MAP — v0.9.8

## Escopo desta versão

A v0.9.8 refina a continuidade conversacional e a camada de fala da Sarah sem alterar a arquitetura de telemetria nem as consultas históricas validadas na v0.9.7.

### `src/routes/telegram-assistant.js`
- histórico recente agora inclui entradas e saídas operacionais com horário;
- `conversationState()` mede o intervalo desde a última interação;
- `applyConversationCadence()` controla reentrada, uso de José/Zé e supressão de cumprimentos repetidos;
- mensagens proativas sempre reabrem o contexto;
- `speechPronunciation()` normaliza A7W, datas, relógio 24h, AM/PM, durações, km/h, km, minutos, segundos e porcentagens;
- relatórios históricos preservam os dados da v0.9.7, com saída vocal mais natural.

### `src/schema.js`
- novas memórias persistentes de continuidade conversacional e leitura de terminologia operacional;
- changelog da v0.9.8.

### versão
- `server.js`, `src/routes/core.js` e `package.json`: 0.9.8.
