# CODEBASE MAP — v0.9.9

## Escopo

### `src/routes/telegram-assistant.js`
- `deliveryPlan()` decide texto, voz ou ambos conforme contexto e política.
- áudio casual recebido pode retornar somente voz.
- relatórios/métricas/localização são âncoras de texto.
- `generateVoiceCompanion()` cria comentário vocal complementar baseado apenas nos fatos fornecidos, com Gemini e fallback Groq/local.
- relatório individual inclui fatos comparativos do dia anterior quando disponíveis.
- vícios de linguagem leves são esporádicos e desativados em alertas.

### `src/schema.js`
- `voice_policy` inclui `mix`.
- `voice_audio_percent` armazena 20, 25, 50, 60 ou 80 por cento de áudio.
- novas memórias persistentes para autonomia de modalidade, humanidade vocal e análise factual.

### `public/tracking-events.html` + `public/js/tracking-events.js` + `public/css/app.css`
- seletor de política vira menu contextual com submenu de proporções.
- correção de corte/overflow das opções.

### versão
- 0.9.9.
