# A7W Platform — Decision Log

## 2026-09-21 — Base de trabalho

- v0.9.9 permanece a base funcional de referência.
- A v0.10.0 exploratória não deve ser tratada como release oficial de produção.
- GitHub/PR/CI serão implantados quando a conta/repositório corretos estiverem disponíveis.
- Até lá, mudanças de design devem ser planejadas antes de alteração do código de produção.

## 2026-09-21 — Direção visual

- Produto: moderno, sofisticado, premium e operacional.
- Referências são usadas para aprender padrões, não para copiar identidade.
- Motion deve ser sutil e funcional.
- Arquitetura da informação será reorganizada depois que funções principais estiverem estáveis.
- Sarah deverá evoluir para uma camada contextual do produto, não apenas um bot externo.

## 2026-09-21 — v0.10.0-beta.1

- A evolução visual passa a ser incremental sobre a v0.9.9, não uma reescrita total.
- Primeiro passo: shell único + organização da Sarah + UX do mapa.
- Leaflet permanece nesta versão para reduzir risco; MapLibre será avaliado em um gate próprio.
- Satélite/híbrido só entram com fonte/provedor tecnicamente e juridicamente adequado.
- Geofences, grupos e calendários entram depois de identidade/permissões e fundação Traccar estarem definidas.
