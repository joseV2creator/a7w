# A7W Platform — Design References

Status: base de referência para evolução visual e de UX da A7W Platform.
Base funcional considerada: v0.9.9.

## Objetivo

Usar projetos maduros como biblioteca de soluções, sem transformar a A7W em cópia de outro produto e sem trocar arquitetura apenas por estética.

Toda referência deve ser classificada antes de entrar no projeto:

1. **Inspiração** — ideia visual ou de organização; nenhum código é copiado.
2. **Padrão** — estudamos a solução e implementamos uma versão própria compatível com a A7W.
3. **Componente open source** — só é incorporado após checagem de licença, peso, acessibilidade, dependências e impacto no legado.

## Referências principais

### Traccar Web
Uso na A7W: Gestão de Frota.

Estudar:
- prioridade visual do mapa;
- relação entre veículo selecionado, mapa e painel lateral;
- filtros e seleção de dispositivos;
- geofences, relatórios e eventos;
- organização de uma quantidade grande de dados operacionais.

Não copiar:
- identidade visual;
- Material UI como dependência apenas por aparência;
- fluxos que não fazem sentido para a operação A7W.

Classificação: **Padrão + inspiração**.

### Adminator
Uso na A7W: shell administrativo e organização visual.

Estudar:
- sidebar recolhível;
- hierarquia de navegação;
- variáveis CSS e tokens;
- dark/light como referência futura;
- tabelas, formulários, estados e páginas administrativas.

Classificação: **Padrão + inspiração**.

### Floating UI
Uso na A7W: dropdowns, tooltips, submenus e popovers.

Problema que resolve diretamente:
- menus cortados pelo viewport;
- submenu abrindo para o lado errado;
- posicionamento ao rolar;
- colisão com bordas da tela.

Classificação: **candidato a componente open source**.

### MapLibre GL JS
Uso na A7W: evolução futura do mapa.

Estudar/adotar quando a fundação de rastreamento estiver estável:
- mapa vetorial acelerado por GPU;
- rotação contínua do veículo por heading;
- câmera suave ao selecionar veículo;
- camadas de rota, alertas e geofences;
- clusters;
- estilos de mapa próprios;
- transições e destaque contextual.

Classificação: **candidato a componente open source / evolução arquitetural**.

### shadcn/ui
Uso na A7W: referência de acabamento e coerência de componentes.

Estudar:
- spacing;
- cards;
- dialogs;
- dropdowns;
- tabs;
- forms;
- estados de foco;
- composição visual limpa.

Regra: **não migrar a A7W para React só para usar shadcn**. Usar os padrões como referência e reproduzir com a arquitetura atual quando fizer sentido.

Classificação: **inspiração + padrão**.

### Design Motion Principles
Uso na A7W: manual de movimento.

Princípios adotados:
- animação precisa explicar mudança, não decorar;
- interações frequentes devem ser rápidas e discretas;
- evitar scale exagerado em cards e botões;
- evitar glow, pulsação e movimento contínuo sem função;
- respeitar `prefers-reduced-motion`;
- transição deve acompanhar causa e efeito;
- em ferramentas de produtividade, sensação de rapidez é mais importante que espetáculo.

Classificação: **padrão oficial de motion**.

## Critério de adoção

Antes de adicionar qualquer biblioteca ou copiar solução, responder:

- Resolve um problema real da A7W?
- Já existe solução suficiente no código atual?
- Vai reduzir manutenção ou aumentar?
- Funciona bem em desktop e celular?
- É acessível por teclado/toque?
- A licença permite nosso uso?
- A dependência é proporcional ao benefício?
- É possível remover sem quebrar metade do sistema?

Se a resposta não for claramente favorável, usar apenas como referência.

## Regra para agentes de IA

Antes de criar do zero um componente complexo, pesquisar uma solução madura e compatível. Reutilizar conceitos ou componentes somente quando forem compatíveis com a arquitetura, identidade A7W, desempenho, acessibilidade e licença. Não adicionar dependência apenas por estética.
