# HANDOFF DELTA — v0.10.0-beta.1

## O que esta versão resolve

1. Começa o “armário” da A7W: navegação por domínio em vez de links soltos por página.
2. Sarah ganha endereço próprio e deixa de ficar escondida em Eventos & Alertas.
3. Shell visual fica consistente sem trocar a arquitetura funcional.
4. Monitoramento recebe controles de mapa mais próximos de um produto de frota profissional.
5. Design system, referências e regras para agentes passam a viajar junto do código.

## O que deliberadamente NÃO entra ainda

- MapLibre;
- satélite/híbrido sem provedor homologado;
- geofences;
- grupos de dispositivos;
- calendário operacional;
- permissões multicanal da Sarah;
- WhatsApp/Evolution;
- GitHub/PR/CI reais, pois o repositório oficial ainda não foi conectado.

Esses itens permanecem no roadmap e não devem ser simulados visualmente como se já funcionassem.

## Gate de teste

- `/health` retorna `0.10.0-beta.1`;
- todas as páginas internas exibem navegação coerente com o perfil;
- sidebar abre/recolhe em desktop e funciona como menu no celular;
- `/sarah` carrega status, voz e orçamento atuais;
- `/tracking/events` continua filtrando/salvando regras e não depende dos elementos da Sarah;
- `/tracking` mantém telemetria, histórico e playback;
- zoom, localização, enquadramento, tela cheia e troca de estilo do mapa funcionam;
- nenhuma tabela `platform_*` é removida ou recriada destrutivamente.
