# A7W Platform — Delta v0.9.2

## Motivo
Após o deploy da v0.9.1, o teste de voz retornou:

`Audio MIME type AUDIO_MP3 is not supported for models/gemini-3.1-flash-tts-preview`

## Causa
O modelo TTS 3.1 Flash entrega PCM bruto no fluxo documentado. Pedir MP3/OGG diretamente ao modelo é incompatível.

## Correção
- `response_format` agora é somente `{type:'audio'}`;
- áudio recebido é tratado como PCM 24 kHz, 16-bit, mono;
- conversão PCM → MP3 64 kbps é feita no backend;
- MP3 é enviado pelo Telegram `sendVoice`;
- nenhuma nova variável de ambiente é necessária;
- Groq e demais módulos não foram alterados.

## Dependência
`@breezystack/lamejs` 1.2.7 (encoder MP3 em JavaScript).

## Gate imediato
1. `/health` deve mostrar `0.9.2`;
2. clicar em **Ouvir teste no Telegram**;
3. confirmar recebimento e reprodução da voz;
4. só então testar política `smart` e áudio de entrada.
