# A7W Platform v0.9.3 — Delta do handoff

## Motivo
A v0.9.2 corrigiu o formato do Gemini TTS para PCM e adicionou conversão local PCM → MP3, mas o teste no Beta retornou `MP3_ENCODER_INVALID`.

## Causa raiz
`@breezystack/lamejs` v1.2.7 declara `type: module`. Seu caminho CommonJS (`require`) aponta para o bundle IIFE, que não expõe `Mp3Encoder` como esperado pela aplicação. A exportação de módulo usada pela biblioteca expõe `Mp3Encoder` via ESM.

## Correção
- substitui `require('@breezystack/lamejs')` por `import('@breezystack/lamejs')` dinâmico;
- cacheia a classe `Mp3Encoder` após a primeira importação;
- `pcm16leToMp3` passa a ser assíncrona;
- `geminiTtsAttempt` aguarda a conversão;
- mantém Gemini TTS em PCM 24 kHz / 16-bit / mono;
- mantém MP3 64 kbps e Telegram `sendVoice`;
- nenhuma nova variável de ambiente;
- nenhuma alteração destrutiva de banco;
- Groq, mapa, rotas e AI Router permanecem inalterados.

## Teste do gate
1. `/health` deve mostrar `0.9.3`.
2. Em Gestão de Frota → Eventos & Alertas, usar **Ouvir teste no Telegram**.
3. Confirmar recebimento da voice note.
4. Se falhar, registrar a mensagem exata antes de qualquer nova alteração.
