# A7W Platform v0.9.4 — Delta de handoff

## Escopo
Integração não destrutiva da voz clonada da Sarah Rodrigues via Fish Audio.

## Mudanças
- Fish Audio passa a ser o TTS primário quando `FISH_TTS_ENABLED=true`, `FISH_API_KEY` e `FISH_VOICE_ID` estão configurados.
- Modelo padrão: `s2.1-pro-free`.
- Voz clonada: `FISH_VOICE_ID`.
- Saída direta em MP3 44.1 kHz / 128 kbps, sem conversão PCM local.
- Parâmetros padrão de expressividade: temperature 0.78, top_p 0.82 e speed 1.02.
- Em mensagens operacionais/proativas, a expressividade é reduzida automaticamente para preservar clareza e firmeza.
- Gemini TTS permanece como fallback automático se Fish Audio falhar.
- O painel de Eventos & Alertas reconhece Fish Audio como provedor de voz principal e mantém as vozes Gemini como fallback.
- Sem renomear tabelas/rotas técnicas `sara_*`; compatibilidade preservada.

## Variáveis novas
- `FISH_API_KEY`
- `FISH_VOICE_ID`
- `FISH_MODEL=s2.1-pro-free`
- `FISH_TTS_ENABLED=true`
- opcionais: `FISH_TEMPERATURE`, `FISH_TOP_P`, `FISH_SPEED`

## Gate de validação
1. `/health` deve retornar `0.9.4`.
2. Painel Sarah Voice deve mostrar Fish Audio / `s2.1-pro-free`.
3. “Ouvir teste no Telegram” deve usar a voz clonada da Sarah.
4. Se Fish falhar, Gemini TTS deve assumir automaticamente.
5. Texto, áudio de entrada, localização, watches, mapa e eventos não podem regredir.
