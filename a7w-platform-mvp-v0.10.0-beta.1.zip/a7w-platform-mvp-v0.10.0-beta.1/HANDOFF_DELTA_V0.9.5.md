# A7W Platform v0.9.5 — Delta de handoff

## Objetivo

Fechar a experiência de presença e personalidade da Sarah antes da migração de canal para WhatsApp.

## Entregue

1. **Presença de conversa no Telegram**
   - `typing` enquanto Sarah processa;
   - `record_voice` enquanto o TTS está sendo produzido;
   - `upload_voice` no envio final do áudio.

2. **Personalidade contextual**
   - conversa geral com José/Senhor Rodrigues: mais próxima, brilhante e expressiva;
   - operação, relatórios e números: profissional e precisa;
   - alertas: firmes, sérios e sem risadas.
   - a direção vocal é inserida internamente para a Fish; o usuário não escreve tags.

3. **Voz oficial única**
   - seletor de vozes Gemini removido do painel;
   - UI mostra Sarah Rodrigues como voz oficial;
   - fallback Gemini permanece técnico e invisível.

4. **Áudio proativo esporádico**
   - na política `smart`, áudio de entrada continua favorecendo resposta em áudio;
   - pedidos explícitos de voz continuam respeitados;
   - alertas proativos viram áudio apenas ocasionalmente;
   - padrão: `SARA_PROACTIVE_VOICE_RATE=0.15`.

5. **Relatório de gastos/uso**
   - novo intent `usage_report`;
   - frases como “quanto já gastei?” e “relatório de gastos” retornam resumo mensal;
   - painel mostra custo estimado real, teto, saldo restante, chamadas e segundos de áudio;
   - Fish free registra custo real como zero e calcula apenas equivalente pago de referência.

6. **Spend Governor mínimo**
   - provedores marcados como `paid` precisam de USD→BRL configurado;
   - bloqueio em aproximadamente 92% do teto ou margem de R$ 2, o que ocorrer primeiro;
   - com teto de R$ 25, o bloqueio prático é R$ 23.

7. **DeepSeek**
   - permanece dormente;
   - só entra no roteador com `DEEPSEEK_ENABLED=true`.

## Gate de teste

- `/health` retorna `0.9.5`;
- texto mostra “digitando” antes da resposta;
- áudio mostra “gravando áudio” durante TTS;
- voz enviada é Sarah Rodrigues/Fish;
- “quanto já gastei?” retorna relatório;
- painel não possui mais seletor Achernar/Leda/etc.;
- watches continuam avisando sem regressão de localização/mapa.
