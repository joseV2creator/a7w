# HANDOFF DELTA — A7W Platform v0.9.6

## Escopo
Sarah Operational Memory, consultas históricas de telemetria e alertas proativos com contexto.

## Novidades
- `platform_sara_memory`: memória persistente de identidade, autoridade operacional, relação com José e iniciativa.
- Novas intenções: `vehicle_day_report` e `fleet_day_report`.
- Consultas aceitam hoje, ontem, `DD/MM/AAAA` e `AAAA-MM-DD`.
- Relatório por veículo/motorista: velocidade máxima e horário, média em movimento, distância estimada, movimento/parado, paradas >=5 min, overspeed, unplanned stop, idle, primeiro/último ponto e volume de telemetria.
- Relatório consolidado da frota por data.
- Eventos `attention`/`critical` são enviados pela Sarah em tom profissional e humano; áudio continua esporádico pela política `smart`.
- `stop_alert_minutes` migra de 8 para 5 somente se ainda estiver exatamente no valor legado 8.

## Limite deliberado
“Fora da rota” literal ainda não é disparado porque a plataforma atual possui paradas planejadas, mas não uma geometria/corredor de rota confiável. Até essa camada existir, Sarah alerta parada não planejada, excesso de velocidade e marcha lenta sem fingir que conhece um desvio de rota.
