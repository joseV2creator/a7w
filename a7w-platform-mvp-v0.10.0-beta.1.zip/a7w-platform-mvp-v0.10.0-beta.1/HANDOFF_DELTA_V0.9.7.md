# HANDOFF DELTA — v0.9.7

## Objetivo
Corrigir falhas observadas em consultas históricas e na pronúncia da voz oficial da Sarah.

## Correções
1. `A7W` é transformado em texto falável “A sete dábliu” antes do TTS.
2. Datas `DD/MM/YYYY` e `DD/MM/YY` são transformadas para leitura “D do M de YYYY” antes do TTS.
3. O parser reconhece hoje, ontem, anteontem, `dia N`, dias da semana, ISO e datas completas.
4. Novas intenções: `vehicle_max_speed` e `fleet_max_speed`.
5. Relatórios históricos resolvem entidades genéricas por contexto recente/telemetria do dia e pedem esclarecimento quando houver mais de uma possibilidade.
6. Classificadores Gemini/Groq/DeepSeek conhecem as intenções históricas e o campo `date`.
7. José é o nome preferido do criador; Joseph/Josef referente a ele é normalizado para José.

## Compatibilidade
- Mantém Fish Audio como voz principal e Gemini TTS como fallback.
- Não renomeia tabelas `platform_sara_*`.
- Não altera mapas, rastreamento atual, watches ou integrações existentes.
