# HANDOFF DELTA — v0.9.8

## O que mudou

1. Sarah não trata cada áudio/mensagem como primeiro contato.
2. Menos de 1h: continuação direta; 1–2h: reentrada leve; acima de 2h: cumprimento variado permitido.
3. Alertas proativos sempre podem abrir com saudação curta e humana.
4. Respostas operacionais deixam de usar `Senhor Rodrigues` repetidamente.
5. Voz normaliza automaticamente:
   - `18/09/2026` → `18 do 9 de 2026`;
   - `17:36` / `17h36` → `17 horas e 36 minutos`;
   - `5:36 PM` → `17 horas e 36 minutos`;
   - `153 km/h` → `153 quilômetros por hora`;
   - `3h 43min` → `3 horas e 43 minutos`;
   - `1h` → `1 hora`;
   - `5 min` → `5 minutos`.
6. A consulta histórica e o cálculo de velocidade máxima da v0.9.7 foram preservados.

## Gate de teste
- `/health` = 0.9.8;
- enviar 3 áudios seguidos: apenas a primeira/reentrada deve poder cumprimentar;
- pedir relatório de 18/09/2026 e ouvir data, velocidade, horário e duração;
- simular retorno após mais de 2h para validar cumprimento curto;
- validar alerta proativo com abertura amigável e corpo profissional.
