# HANDOFF DELTA — v0.9.9

## O que mudou
1. Texto e áudio deixam de ser duplicados por padrão.
2. Voz recebida + conversa comum: resposta pode ser somente áudio.
3. Relatórios/dados importantes: texto permanece; se houver áudio, ele comenta e analisa os dados sem repetir o relatório.
4. Comparações com o dia anterior só aparecem quando há telemetria real desse dia.
5. Pausas e vícios leves de linguagem aparecem raramente em fala não crítica.
6. Nova política `mix` com 80/20, 75/25, 50/50, 40/60 e 20/80 (texto/áudio).
7. Novo menu de política corrige opções cortadas e abre submenu de proporções.

## Gate de teste
- `/health` = 0.9.9;
- áudio casual -> somente áudio em `smart`;
- relatório por áudio -> texto estruturado + áudio diferente do texto;
- áudio de relatório não pode inventar comparação sem telemetria anterior;
- alterar política para `mix 80/20` e `mix 20/80` e validar comportamento;
- alertas permanecem firmes e sem vícios de linguagem.
