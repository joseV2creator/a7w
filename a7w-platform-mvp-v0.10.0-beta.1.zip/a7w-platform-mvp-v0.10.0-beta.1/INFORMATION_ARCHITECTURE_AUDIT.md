# A7W Platform — Auditoria Inicial de Arquitetura da Informação

Base analisada: v0.9.9.

## Situação atual

A plataforma já possui áreas funcionais separadas, mas várias funções nasceram no lugar mais conveniente para implementação e não necessariamente no lugar mais intuitivo para o usuário.

Telas identificadas na base atual:

### Administração
- Administração
- Empresas
- Usuários
- Acessos
- Atualizações

### Gestão de Frota
- Gestão de Frota / monitoramento
- Frota & Locais
- Rotas & Entregas
- Eventos & Alertas
- Relatórios de Frota

### Comercial
- Visão geral
- Cotações
- Minhas vendas

### Operação
- Operação
- Pedidos

### Logística / entregador
- Minhas entregas
- Mapa da rota

### Portal B2B
- Portal B2B
- Catálogo
- Ofertas
- Meus pedidos
- Minha conta

### Autenticação
- Login
- Cadastro B2B

## Problemas de organização já visíveis

1. **Sarah está parcialmente escondida dentro de Eventos & Alertas.** Voz, custos, política de resposta e integração não são conceitos de “evento de frota”; merecem área própria.
2. **Frota, monitoramento, relatórios, rotas e eventos estão corretos como domínio, mas a navegação pode parecer fragmentada.** Devem formar um único armário chamado Gestão de Frota.
3. **Operação, Rotas & Entregas e Logística têm interseções.** A diferença entre planejamento interno e tela do entregador precisa ficar evidente.
4. **Configurações técnicas aparecem próximas de tarefas operacionais.** Integrações, chaves, Telegram/WhatsApp, IA e custos devem ficar fora do fluxo diário.
5. **As telas já estão visualmente relacionadas, mas faltam regras globais fortes para hierarquia, hover, loading, motion, empty states e feedback.**

## Arquitetura proposta

### Início / Command Center
- resumo do dia;
- alertas realmente importantes;
- atalhos recentes;
- busca universal;
- ações rápidas;
- resumo da Sarah.

### Gestão de Frota
- Monitoramento
- Veículos
- Motoristas
- Rotas & Entregas
- Eventos & Alertas
- Relatórios
- Locais de Interesse

### Operação
- Pedidos
- Expedição
- Entregas
- Ocorrências

### Comercial
- Visão Geral
- CRM / Clientes
- Cotações
- Vendas
- Follow-up

### Sarah
- Conversa / Central Sarah
- Alertas & Observações
- Automações
- Uso & Custos
- Voz & Personalidade
- Integrações
- Memória operacional

### Administração
- Empresas
- Usuários
- Perfis & Permissões
- Integrações do sistema
- Segurança
- Atualizações
- Auditoria

### Portal do Cliente
Permanece separado da interface interna.

## Regra do “armário”

Toda função deve responder quatro perguntas:

1. Qual problema resolve?
2. Quem usa?
3. Com que frequência usa?
4. Em qual domínio o usuário procuraria naturalmente essa função?

Se a resposta “onde está hoje” for diferente da resposta “onde o usuário procuraria”, a função entra no backlog de reorganização.

## Próxima auditoria

Quando as funções principais estabilizarem, montar inventário completo com colunas:

- função;
- URL/tela atual;
- usuário/papel;
- frequência;
- criticidade;
- dependências;
- localização ideal;
- manter / mover / fundir / remover.
