# Open-source notices

## @breezystack/lamejs 1.2.7
Used by A7W Platform v0.9.4 to encode the PCM output produced by Gemini TTS into MP3 before delivery through Telegram.

Package: `@breezystack/lamejs`
License: LGPL-3.0
Upstream: https://github.com/shijinyu/lamejs
LAME project: https://lame.sourceforge.io/

The library is consumed as a separate npm dependency and is not modified by A7W Platform.
