# A7W Platform — v0.10.0-beta.1

Quarta etapa do novo núcleo A7W Platform. Esta versão reorganiza a experiência em páginas reais, amadurece o Portal B2B e devolve o rastreamento/logística ao centro da operação sem transformar a interface em um painel confuso.

## Atualização segura a partir da 0.2/0.3

- use o mesmo banco MySQL da A7W Platform;
- preserve as variáveis atuais;
- não apague usuários, empresas, pedidos ou cotações;
- não é necessário importar SQL manualmente: `ensureSchema()` cria as novas tabelas de rastreamento e planejamento;
- para GPS real, adicione `TRACKING_DEVICE_TOKEN` e mantenha `OSMAND_SPEED_UNIT=knots` se usar Traccar Client/OsmAnd;
- `/health` deve retornar `version: 0.10.0-beta.1`.

## Navegação multipágina

Os módulos deixam de depender de uma única tela com âncoras. O beta continua em um único domínio para facilitar os testes, mas cada contexto já tem sua própria URL e página.

### Administração
- `/admin`
- `/admin/companies`
- `/admin/users`
- `/admin/access`
- `/admin/updates`

### Gestão de Frota
- `/tracking` — monitoramento, histórico e métricas
- `/tracking/routes` — busca e planejamento de rota
- `/fleet` — veículos, motoristas, dispositivos e locais
- `/tracking/events` — eventos e regras de alertas
- `/reports` — relatórios de frota

### Sarah
- `/sarah` — canal, cérebro IA, voz, política de resposta, uso e orçamento

### Comercial
- `/commercial`
- `/commercial/quotes`
- `/commercial/sales`

### Operação
- `/operations`
- `/operations/orders`

### Logística
- `/logistics`
- `/logistics/map`

### Comprador B2B
- `/client`
- `/client/catalog`
- `/client/offers`
- `/client/orders`
- `/client/account`

## Portal B2B

A direção visual usa como referência o nível de clareza de catálogos industriais modernos: navegação horizontal, hero institucional, categorias, produtos, ofertas, carrinho e acompanhamento de pedidos. A identidade e os componentes são próprios da A7W.

O comprador pode:
- navegar por linhas/categorias;
- buscar produtos;
- ver ofertas e benefícios;
- montar carrinho;
- solicitar faturamento ou condição comercial;
- acompanhar pedidos e sua evolução;
- consultar a própria empresa e situação de crédito.

## Usuários fictícios de teste

Em `Administração > Usuários` existe o bloco **Laboratório**. O administrador escolhe uma senha temporária e cria, sob demanda:

- Gerência — `gerencia.teste@a7w.com.br`
- Comercial — `comercial.teste@a7w.com.br`
- Operação — `operacao.teste@a7w.com.br`
- Logística — `logistica.teste@a7w.com.br`
- Comprador B2B — `comprador.teste@clientea7w.com.br`

O mesmo botão também cria empresa, produtos, cotação, pedido, veículo, motorista, rota e telemetria demonstrativos. Há uma ação separada para excluir o ambiente de teste.

## Rastreamento operacional

O monitoramento `/tracking` apresenta:
- posição atual;
- estado online / sem atualização;
- velocidade atual;
- bateria;
- última atualização;
- histórico no mapa;
- quilometragem estimada;
- tempo em movimento;
- tempo parado;
- velocidade média em movimento;
- velocidade máxima;
- tempo sem sinal;
- quantidade de pontos GPS;
- paradas detectadas a partir de 5 minutos.

O planejamento `/tracking/routes` permite:
- escolher veículo e data;
- pesquisar empresa/endereço/lugar;
- adicionar paradas ao mapa;
- alterar ordem;
- remover paradas;
- visualizar sequência numerada;
- abrir a sequência no Google Maps.

A busca prioriza Google Places quando `GOOGLE_MAPS_SERVER_KEY` estiver configurada. No beta há fallback para LocationIQ e, por último, OpenStreetMap/Nominatim.

## GPS real

Endpoint compatível com OsmAnd / Traccar Client:

`https://beta.a7w.com.br/api/tracking/osmand?token=SEU_TOKEN`

Consulte `TRACKING_SETUP.md`.

## Hostinger

- Express
- Node 22.x
- Diretório raiz `./`
- npm
- Entrada `server.js`

## Health

`https://beta.a7w.com.br/health`

Esperado:

```json
{"ok":true,"product":"A7W Platform","version":"0.9.0"}
```


## 0.4.2 — ponte temporária de rastreamento
Para manter o mesmo celular enviando ao A7W Track e também alimentar o beta, atualize o A7W Track para 1.4.1 e configure nele:
`TRACKING_FORWARD_URL=https://beta.a7w.com.br/api/tracking/location`

Se o token do beta for igual ao `DEVICE_TOKEN` do Track, não é necessário definir `TRACKING_FORWARD_TOKEN`.
O beta também deve ter `LOCATIONIQ_TOKEN` para os mapas.


## 0.5.1 — logística organizada
- rastreamento ao vivo atualiza automaticamente a cada 5 s sem exigir o botão Atualizar;
- “Acompanhar veículo” ativa follow mode; mover/zoom manual desativa;
- novo módulo `/fleet` para cadastrar veículo, motorista e vincular dispositivo GPS;
- pontos de referência fixos, inclusive “Usar minha localização” via permissão do navegador;
- distância do veículo à referência principal no monitoramento;
- busca de rota com autocomplete por digitação e referências A7W prioritárias;
- `/reports` com semana/mês/ano e modo de apresentação;
- host `relatorios.*` preparado para redirecionar ao módulo de relatórios quando o DNS for configurado.

### Ainda não é 3D nem otimização definitiva
O mapa continua Leaflet + LocationIQ/OSM nesta versão. A migração para MapLibre GL + mapa vetorial/3D e um motor de roteirização/otimização será feita após a fundação Traccar/VPS estar estabilizada. Não foi simulada uma rota “otimizada” sem motor adequado.


## 0.5.1 — refinamento responsivo
- containers respeitam seus limites em telas pequenas;
- navegação logística em faixa no desktop e seletor expansível no celular;
- menu principal vira hambúrguer no celular;
- menu da conta concentra configurações, atualizações e saída;
- paradas passam a usar amarelo/âmbar; vermelho fica reservado para desvios/alertas;
- referência A7W usa pin em gota com animação sutil de flutuação.


## 0.6.0 — Gestão de Frota

- Rastreamento passa a ser apresentado como Gestão de Frota.
- Monitoramento ganha mapa dominante, linha do tempo de eventos e cartão flutuante/dock do veículo.
- Planejamento evolui para Rotas & Entregas com resumo operacional do dia.
- Frota ganha mapa de Locais de Interesse, pesquisa e marcação direta no mapa.
- Entregador ganha prova de conclusão com status, recebedor, observação, GPS e foto comprimida.
- Relatórios passam a ser organizados por assunto e exportam resumo CSV.
- Layout inspirado em boas práticas de gestão de frota, mantendo identidade própria A7W.


## v0.7.2 · Sarah Rodrigues / Telegram
Eventos & Alertas agora exibe status da integração Telegram, último envio e última falha sem expor segredos. O painel possui teste direto e pode aplicar o nome público `Sarah Rodrigues` ao bot via Bot API.


## v0.7.3 · playback responsivo e diagnóstico Sarah
- controles do mapa passam a formar uma pilha responsiva: painel do veículo, seletor, playback e legenda;
- seletor compacto permite painel sobre o veículo, painel no canto ou ocultar;
- data e filtros recebem contenção reforçada no celular;
- playback ganha 160× com avanço por salto de pontos em velocidades altas;
- assets CSS/JS recebem cache-busting por versão para evitar interface nova usando JavaScript antigo;
- integração Telegram passa a mostrar a última verificação e erros reais do servidor;
- teste e alteração de nome usam referências DOM explícitas e validação do nome via Bot API.


## v0.8.3 · Sarah Rodrigues com Gemini
- Telegram passa a receber texto e mensagens de voz por webhook autenticado;
- `GEMINI_API_KEY` habilita Gemini 2.5 Flash como camada de linguagem;
- comandos operacionais consultam o banco A7W localmente; o Gemini não recebe a telemetria bruta para responder localização;
- “Onde está Anderson?” e “Onde está a Saveiro?” retornam status, última posição, endereço quando disponível, pin do Telegram e link de navegação;
- busca de empresas/locais usa primeiro a base A7W e depois LocationIQ;
- “Quais veículos estão online?” e “Resumo da operação de hoje” funcionam;
- áudio curto é baixado do Telegram em memória e enviado ao Gemini como `audio/ogg`;
- conversa é restrita ao `TELEGRAM_CHAT_ID` configurado;
- Eventos & Alertas ganha status do cérebro, teste do Gemini e botão para ativar o webhook.

## v0.8.3 · Sarah conversacional e observações inteligentes
- Corrige respostas vazias da Gemini Interactions aumentando o orçamento de saída, reduzindo o nível de pensamento e lendo respostas `steps`, `output_text` e o esquema legado como fallback.
- A Sarah ganha personalidade conversacional própria: elegante, calma, objetiva e com presença discreta de central de comando.
- Comandos condicionais persistentes pelo Telegram: “me avise quando tiver um motorista disponível”, “me avise quando Anderson ficar online”, “quais avisos estão ativos?” e “pare de me avisar”.
- “Disponível” nesta fase significa motorista com GPS online, veículo parado e sem entrega ativa em `loaded`, `on_route` ou `arrived`.
- Observações são one-shot: disparam uma vez quando a condição é atendida. Se já estiver atendida no momento do pedido, Sarah avisa imediatamente.
- O painel mostra a quantidade de observações ativas.


## v0.8.3 · personalidade Sarah + fallback gratuito
- Modelo Gemini padrão atualizado para `gemini-3.8-flash`.
- Personalidade da Sarah refinada: doce, suave, acolhedora, inteligente, segura e profissional, sem teatralidade.
- Confirmações de avisos usam linguagem natural, por exemplo: `Anderson já está disponível, senhor.`
- Comandos operacionais claros continuam funcionando localmente sem consumir IA.
- Fallback opcional Groq para conversa/classificação quando a cota do Gemini falhar.
- Áudio pode usar `whisper-large-v3-turbo` no Groq como fallback.
- Variáveis opcionais: `GROQ_API_KEY`, `GROQ_MODEL`, `GROQ_TRANSCRIBE_MODEL`.
- Nenhuma API hospedada gratuita é ilimitada; o modo local garante continuidade das funções operacionais básicas.


## v0.9.0 · Sarah Voice Core + AI Router
- Voz de saída no Telegram via Gemini 3.1 Flash TTS em OGG/Opus.
- Voz padrão `Achernar` (suave), alterável no painel; opções jovens/gentis incluídas.
- Política de voz: inteligente, espelhar áudio, somente explícita, sempre ou desligada.
- Em `smart`, mensagens de voz, pedidos explícitos e alertas proativos podem receber texto + áudio.
- AI Router: comandos locais → Gemini 3.8 Flash → Groq GPT-OSS 20B → DeepSeek Flash opcional → fallback local.
- Áudio de entrada prioriza Groq Whisper quando a chave Groq estiver configurada, poupando a cota multimodal do Gemini.
- Telemetria de uso mensal: tokens, segundos de áudio, falhas, custo estimado real e equivalente se os provedores fossem pagos.
- Teto mensal padrão da Sarah: R$ 25; câmbio USD→BRL é configurável no painel para estimativas de provedores pagos.
- Novas tabelas `platform_sara_settings` e `platform_sara_usage`; migração aditiva.
- Nenhuma chave nova é obrigatória para voz: a mesma `GEMINI_API_KEY` é usada pelo TTS.

## v0.9.0 · Sarah Voice Core

Primeira fase consolidada da arquitetura da Sarah:
- resposta de voz pelo Telegram;
- TTS Gemini 3.1 Flash;
- políticas de voz configuráveis;
- Groq Whisper como transcrição preferencial quando configurado;
- AI Router: local → Gemini → Groq → DeepSeek → fallback local;
- comandos operacionais claros não consomem IA;
- telemetria de uso e estimativa de custo por provedor;
- teto mensal de referência configurável;
- painel para testar a voz e acompanhar consumo.


## v0.9.4 · Sarah Voice Core — Fish Audio
- Fish Audio passa a ser o TTS primário quando as variáveis `FISH_*` estão configuradas.
- A voz clonada oficial da Sarah Rodrigues é chamada por `FISH_VOICE_ID`.
- Modelo padrão: `s2.1-pro-free`.
- Saída direta em MP3 44.1 kHz / 128 kbps.
- Expressividade padrão controlada por `temperature`, `top_p` e `prosody`, sem exigir comandos manuais do usuário.
- Em mensagens operacionais/proativas, a expressividade é reduzida automaticamente para priorizar clareza.
- Gemini TTS permanece como fallback automático.
- Nenhuma migração destrutiva de banco.

## v0.9.3 · Sarah Voice Core — PCM para MP3
- Gemini TTS passa a usar somente `response_format: { type: "audio" }`.
- O `gemini-3.1-flash-tts-preview` retorna PCM bruto 24 kHz / 16-bit / mono.
- O backend A7W converte o PCM localmente para MP3 64 kbps.
- Telegram recebe o MP3 via `sendVoice`.
- Remove tentativa de solicitar OGG/MP3 diretamente ao Gemini.
- Nova dependência pura JavaScript: `@breezystack/lamejs`.
- Nenhuma variável de ambiente nova é necessária.

## v0.9.1 · Sarah Voice Core — correção TTS
- Nome oficial visível padronizado para **Sarah Rodrigues**.
- Identificadores técnicos `sara` permanecem por compatibilidade.
- TTS Interactions deixa de enviar `delivery: inline`.
- Voz solicita OGG/Opus e possui fallback MP3 para `sendVoice` do Telegram.
- Retry curto em falhas transitórias do Gemini TTS.
- Sem migração destrutiva de dados.

## v0.9.3 · Sarah Voice Core — carregamento ESM do encoder MP3
- Corrige `MP3_ENCODER_INVALID` observado no Beta.
- `@breezystack/lamejs` passa a ser carregado com `import()` dinâmico, compatível com sua exportação ESM.
- Conversão permanece PCM 24 kHz / 16-bit / mono → MP3 64 kbps → Telegram `sendVoice`.
- Nenhuma variável de ambiente nova.
- Nenhuma migração destrutiva de banco.


## v0.9.7 · Sarah Context Core, presença e orçamento

- Telegram mostra **digitando** durante o processamento de mensagens e **gravando áudio** durante a geração de voz; a ação é renovada enquanto o trabalho continua.
- A voz visível passa a ser apenas **Sarah Rodrigues**. As antigas opções Gemini ficam como fallback técnico interno e não aparecem mais no painel.
- Fish Audio recebe direção vocal automática por contexto: conversa comum mais brilhante, próxima e expressiva; operação mais clara e profissional; alertas mais firmes e sérios.
- Na política `smart`, alertas proativos são principalmente texto e podem virar áudio ocasionalmente. A taxa padrão é `SARA_PROACTIVE_VOICE_RATE=0.15` e pode ser alterada depois.
- Novo comando conversacional de uso/orçamento: perguntas como “quanto já gastei?”, “relatório de gastos” ou “quanto falta para o limite?” retornam o resumo mensal.
- O painel mostra custo estimado real, teto mensal, saldo restante, chamadas Fish e segundos de áudio registrados.
- `s2.1-pro-free` continua tratado como gratuito; `FISH_FREE_ACCESS_UNTIL` registra a janela gratuita anunciada atualmente para facilitar revisão futura.
- Spend Governor mínimo: provedores marcados como `paid` precisam de câmbio USD→BRL e são bloqueados perto de 92% do teto ou com margem de R$ 2, o que ocorrer primeiro.
- DeepSeek permanece dormente por padrão e só entra no roteador com `DEEPSEEK_ENABLED=true`.


## v0.9.7 · Sarah Operational Memory, relatórios históricos e alertas proativos

- memória persistente de identidade/governança e relação de trabalho com José Rodrigues;
- personalidade separa conversa pessoal de contexto operacional;
- relatório histórico por veículo/motorista com velocidade máxima, média em movimento, distância estimada, tempos, paradas e eventos;
- relatório consolidado da frota por data;
- alertas de atenção/críticos passam pela Sarah com abertura humana, texto profissional e voz apenas conforme política inteligente;
- parada não planejada usa 5 min como padrão quando a configuração ainda estava no valor legado de 8 min;
- desvio real de rota não é inferido sem geometria/corredor de rota confiável.


## v0.9.7 · Sarah Historical Query Core e pronúncia

- Corrige consultas naturais de velocidade máxima e relatório histórico por motorista/veículo.
- Entende datas completas (`17/05/2024`, `17/05/24`), dia do mês (`dia 17`) e dias da semana (`quinta-feira`, `sexta-feira`).
- Para consultas genéricas como “o motorista”, tenta resolver pelo contexto recente e pela telemetria do dia; se houver ambiguidade, pede o motorista/veículo e lista opções.
- Adiciona respostas concisas para `vehicle_max_speed` e `fleet_max_speed`, mantendo `vehicle_day_report` e `fleet_day_report` para relatórios completos.
- Antes de sintetizar áudio, normaliza `A7W` para “A sete dábliu” e datas numéricas para leitura como “17 do 5 de 2024”.
- Joseph/Josef, quando se referirem ao criador da Sarah, são tratados como José.
- O parser local de data tem prioridade sobre data inferida por IA nas consultas históricas.


## v0.9.8 · Sarah Conversation Continuity + fala natural

- Sarah passa a usar todo o histórico recente, incluindo respostas operacionais, com horário, em vez de enxergar apenas entradas do usuário e conversa geral.
- Aberturas deixam de ser repetitivas: conversa ativa por menos de 1 hora continua sem novo cumprimento; entre 1 e 2 horas há reentrada leve; após 2 horas pode haver cumprimento curto e variado.
- Alertas e mensagens proativas reabrem o contexto de forma amigável porque podem chegar enquanto José está ocupado com outra tarefa.
- Tratamento varia entre resposta direta, `José,` e ocasionalmente `Zé,` em contexto próximo; `Senhor Rodrigues` deixa de ser repetido nas respostas operacionais.
- TTS normaliza datas, horários, AM/PM, km/h, km, horas, minutos, segundos e porcentagens antes da Fish/Gemini falar.
- Relatórios usam horário limpo na velocidade máxima e mensagens de ausência de telemetria ganham variações naturais.


## v0.9.9 · Sarah multimodal contextual
- áudio recebido em conversa comum pode receber somente áudio, evitando duplicar texto + voz;
- relatórios, localização, métricas e custos preservam texto como registro consultável;
- quando relatório recebe áudio, a voz gera um comentário complementar com observações factuais e não repete a lista escrita;
- relatório individual pode comparar com o dia anterior somente quando a telemetria anterior existe;
- fala pode usar pausas e um vício leve de linguagem ocasional em contexto não crítico;
- nova política `mix` permite escolher proporções 80/20, 75/25, 50/50, 40/60 e 20/80 entre texto e áudio;
- painel troca o seletor cortado por menu contextual com submenu de porcentagens.


## v0.10.0-beta.1 · A7W Design Foundation

Esta versão inicia a reorganização visual e de arquitetura da informação sem reescrever o motor funcional da v0.9.9.

- shell interno unificado e navegação centralizada por perfil;
- sidebar agrupada por domínio, recolhível e responsiva;
- microinterações discretas, foco acessível e `prefers-reduced-motion`;
- Sarah ganha área própria em `/sarah`;
- Eventos & Alertas volta a focar somente em eventos e regras da frota;
- monitoramento mantém Leaflet, mas recebe zoom à direita, localização do usuário, enquadramento, tela cheia e estilos A7W Claro/Escuro/OpenStreetMap;
- design system, referências, auditoria da informação e regras para agentes passam a fazer parte do pacote;
- nenhuma migração destrutiva de banco.

Itens como MapLibre, satélite/híbrido, geofences, grupos, calendários e permissões multicanal da Sarah permanecem em gates futuros e não são simulados como se já estivessem prontos.
