# A7W Platform 0.4.0 — rastreamento GPS

## Endpoint do Traccar Client / OsmAnd

Configure o aplicativo do aparelho corporativo para enviar para:

`https://beta.a7w.com.br/api/tracking/osmand?token=SEU_TRACKING_DEVICE_TOKEN`

O protocolo aceita GET ou POST e os campos usuais do OsmAnd/Traccar Client, incluindo `id`, `lat`, `lon`, `timestamp`, `speed`, `bearing`, `accuracy` e `batt`.

## Variáveis novas

```env
TRACKING_DEVICE_TOKEN=gere_um_token_longo_e_privado
OSMAND_SPEED_UNIT=knots
LOCATIONIQ_TOKEN=
```

O Traccar Client envia velocidade em nós (knots) por padrão. A plataforma converte para km/h antes de gravar. Se a fonte já enviar km/h, altere `OSMAND_SPEED_UNIT=kmh`.

## Busca de empresas e lugares

Ordem do provedor:
1. Google Places, quando `GOOGLE_MAPS_SERVER_KEY` estiver configurada.
2. LocationIQ, quando `LOCATIONIQ_TOKEN` estiver configurado.
3. OpenStreetMap/Nominatim como fallback de baixa escala para o beta.

A rota planejada pode ser aberta no Google Maps através de URL oficial, sem exigir cobrança de Directions para esse botão.

## Métricas iniciais

A tela `/tracking` calcula para a data selecionada:
- distância estimada;
- tempo em movimento;
- tempo parado;
- tempo sem sinal;
- velocidade média em movimento;
- velocidade máxima;
- paradas de pelo menos 5 minutos;
- posição atual, bateria e última atualização.

Essas métricas são operacionais e devem ser validadas com trajetos reais antes de serem usadas para decisões de desempenho ou cobrança.

## Sarah Rodrigues + Telegram + Gemini (v0.8.3)

Variáveis adicionais:

```env
GEMINI_API_KEY=
GEMINI_MODEL=gemini-3.8-flash
```

As variáveis `TELEGRAM_BOT_TOKEN` e `TELEGRAM_CHAT_ID` continuam sendo as mesmas já configuradas.

Depois do deploy:
1. Eventos & Alertas -> Testar cérebro Gemini.
2. Eventos & Alertas -> Ativar conversa da Sarah.
3. Envie ao bot: `Onde está Anderson?`.
4. Teste uma mensagem de voz curta com a mesma pergunta.

Quando o webhook estiver ativo, `getUpdates` do Telegram deixa de ser o método de recebimento normal; as mensagens passam a chegar diretamente no endpoint HTTPS da A7W.


## Gemini 3.6 Flash / Interactions API (v0.8.3)

A Sarah usa a API Interactions, não mais `generateContent`.

Variáveis:
```env
GEMINI_API_KEY=...
GEMINI_MODEL=gemini-3.8-flash
```

Se `GEMINI_MODEL` ainda estiver como `gemini-2.5-flash`, a v0.8.3 migra automaticamente para `gemini-3.8-flash`. O prefixo `models/` também é removido automaticamente.

## Observações condicionais da Sarah (v0.8.3)
Não há variável obrigatória nova. Depois que Telegram + Gemini + webhook já estiverem ativos, teste pelo próprio Telegram:
- `Me avise quando tiver um motorista disponível.`
- `Me avise quando Anderson ficar online.`
- `Quais avisos estão ativos?`
- `Pare de me avisar.`

A checagem ocorre aproximadamente a cada 30 segundos. Pode ser desligada opcionalmente com `SARA_WATCHES_BACKGROUND=false`.


## v0.8.3 · personalidade Sarah + fallback gratuito
- Modelo Gemini padrão atualizado para `gemini-3.8-flash`.
- Personalidade da Sarah refinada: doce, suave, acolhedora, inteligente, segura e profissional, sem teatralidade.
- Confirmações de avisos usam linguagem natural, por exemplo: `Anderson já está disponível, senhor.`
- Comandos operacionais claros continuam funcionando localmente sem consumir IA.
- Fallback opcional Groq para conversa/classificação quando a cota do Gemini falhar.
- Áudio pode usar `whisper-large-v3-turbo` no Groq como fallback.
- Variáveis opcionais: `GROQ_API_KEY`, `GROQ_MODEL`, `GROQ_TRANSCRIBE_MODEL`.
- Nenhuma API hospedada gratuita é ilimitada; o modo local garante continuidade das funções operacionais básicas.

## v0.9.0 · Voz da Sarah

A saída de voz usa a mesma `GEMINI_API_KEY` já configurada. O modelo de TTS padrão é `gemini-3.1-flash-tts-preview` e a voz inicial é `Achernar`.

No painel Gestão de Frota → Eventos & Alertas → Sarah Rodrigues · Voice Core, o administrador pode escolher voz, política de fala e teto mensal de referência.

Políticas:
- `smart`: áudio recebido, pedido explícito de voz e alertas proativos podem gerar texto + voz;
- `mirror`: responde em voz quando a entrada foi voz;
- `explicit`: somente quando o usuário pedir;
- `always`: sempre texto + voz;
- `off`: desativada.

Fallbacks opcionais:
```env
GROQ_API_KEY=
GROQ_MODEL=openai/gpt-oss-20b
GROQ_TRANSCRIBE_MODEL=whisper-large-v3-turbo
DEEPSEEK_API_KEY=
DEEPSEEK_MODEL=deepseek-flash
SARA_GEMINI_BILLING=free
SARA_GROQ_BILLING=free
SARA_DEEPSEEK_BILLING=paid
```

Nenhuma dessas chaves opcionais é necessária para a voz se o Gemini já estiver funcionando.
