# A7W Platform — Roadmap de UX/UI

Este roadmap não substitui o roadmap funcional. Ele organiza a evolução visual sem quebrar o legado.

## Fase 0 — Fundamentos e inventário

Status: iniciado.

Entregáveis:
- referências oficiais;
- arquitetura da informação inicial;
- design system v0.1;
- regras de motion;
- lista de problemas e oportunidades.

Não altera produção.

## Fase 1 — Shell único da A7W

Objetivo: todas as áreas internas parecerem partes do mesmo produto.

Trabalhos:
- sidebar/navegação padronizada;
- estados ativo/hover/focus;
- topbar consistente;
- hierarquia de título/subtítulo/ações;
- espaçamento global;
- responsividade do shell;
- ícones consistentes.

Benefício: reduz sensação de telas montadas separadamente.

## Fase 2 — Feedback e motion

Trabalhos:
- skeleton apenas onde necessário;
- loading de botão;
- transição de menus/dialogs/drawers;
- empty states;
- toasts;
- hover e focus;
- `prefers-reduced-motion`;
- correção de menus cortados.

Benefício: interface parece rápida, viva e confiável sem virar espetáculo.

## Fase 3 — Gestão de Frota premium

Trabalhos:
- revisar relação mapa/painel/timeline;
- seleção de veículo com foco contextual;
- ícone orientado por heading;
- transição de câmera;
- layers de rota/eventos;
- clusters;
- geofences;
- avaliar migração Leaflet → MapLibre somente com benefício comprovado.

Benefício: transforma o módulo central em ferramenta operacional de alto nível.

## Fase 4 — Sarah integrada ao produto

Trabalhos:
- painel contextual da Sarah;
- busca/comando universal;
- explicação de telas e dados;
- alertas e sugestões;
- uso/custos/configurações em área própria;
- identidade e permissões por usuário/canal.

Benefício: Sarah deixa de ser “bot do Telegram” e vira camada inteligente da A7W.

## Fase 5 — Reorganização do armário

Depois de estabilizar funcionalidades:
- mapear 100% das funções;
- medir frequência/criticidade;
- mover funções para o domínio correto;
- fundir telas redundantes;
- remover controles obsoletos;
- simplificar navegação.

Benefício: o sistema passa a ser organizado pela cabeça do usuário, não pela história de implementação.

## Fase 6 — Polimento e qualidade

- acessibilidade;
- performance;
- lazy loading real;
- testes visuais/e2e;
- auditoria mobile;
- consistência de textos;
- dark mode somente se houver valor operacional.

## Ordem recomendada

Não redesenhar tudo de uma vez.

Primeiro: shell + navegação + estados globais.
Depois: Gestão de Frota.
Depois: Sarah.
Depois: módulos secundários.
Por último: reorganização completa quando a funcionalidade estiver estável.
