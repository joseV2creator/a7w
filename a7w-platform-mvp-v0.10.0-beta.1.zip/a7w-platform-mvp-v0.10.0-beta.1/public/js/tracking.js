let tMap,tBaseLayer=null,tDevices=[],tHistory=[],tRouteLayers=[],tStopLayers=[],tVehicleMarker=null,tPlaybackMarker=null,tUserMarker=null,tFollow=false,tInitialFit=false,tReferences=[],tReferenceLayers=[],tLastLive=null,tMetrics={},tStops=[],tPlannedStops=[],tFleetEvents=[],tSettings={fuel_efficiency_km_l:10},tProgress={};
let tMapStyle=['light','dark','osm'].includes(localStorage.getItem('a7wMapStyle'))?localStorage.getItem('a7wMapStyle'):'light';
let tBubbleMode=['vehicle','dock','hidden'].includes(localStorage.getItem('a7wVehicleCardMode'))?localStorage.getItem('a7wVehicleCardMode'):'vehicle',tPlaybackTimer=null,tPlaybackIndex=0;

(async()=>{
  if(!await boot(['admin','manager']))return;
  initTrackingMap();trackingDate.value=new Date().toLocaleDateString('en-CA');
  await Promise.all([loadDevices(),loadReferences(),loadSettings()]);bindTracking();await refreshTracking();
  setInterval(refreshLiveOnly,5000);
  setInterval(()=>{if(isToday())refreshMetricsOnly()},60000);
  setInterval(()=>{if(isToday())evaluateAlerts(false)},30000);
})();

function initTrackingMap(){
  tMap=L.map('trackingMap',{zoomControl:false}).setView([-23.46,-46.53],12);
  setMapStyle(tMapStyle,false);
  bindMapTools();
  ['mousedown','touchstart','wheel'].forEach(ev=>tMap.on(ev,()=>{if(tFollow){tFollow=false;syncFollow()}}));
  document.addEventListener('fullscreenchange',()=>setTimeout(()=>tMap?.invalidateSize(),80));
}
function mapLayer(mode){
  if(mode==='osm')return L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'&copy; OpenStreetMap contributors'});
  return L.tileLayer('/api/map/tiles/{z}/{x}/{y}.png',{maxZoom:19,attribution:'&copy; OpenStreetMap · <a href="https://locationiq.com" target="_blank" rel="noopener">Search by LocationIQ.com</a>'});
}
function setMapStyle(mode,persist=true){
  const next=['light','dark','osm'].includes(mode)?mode:'light';
  if(tBaseLayer){try{tMap.removeLayer(tBaseLayer)}catch(_){}}
  tBaseLayer=mapLayer(next).addTo(tMap);tBaseLayer.bringToBack?.();tMapStyle=next;
  document.querySelector('.fleet-map-shell')?.classList.toggle('map-theme-dark',next==='dark');
  document.querySelectorAll('[data-map-style]').forEach(b=>b.classList.toggle('active',b.dataset.mapStyle===next));
  if(persist)localStorage.setItem('a7wMapStyle',next);
}
function bindMapTools(){
  const zIn=document.getElementById('mapZoomIn'),zOut=document.getElementById('mapZoomOut'),loc=document.getElementById('mapLocateMe'),fit=document.getElementById('mapFitData'),full=document.getElementById('mapFullscreen'),toggle=document.getElementById('mapLayerToggle'),wrap=document.getElementById('mapLayersControl'),menu=document.getElementById('mapLayerMenu');
  if(zIn)zIn.onclick=()=>tMap.zoomIn();if(zOut)zOut.onclick=()=>tMap.zoomOut();if(loc)loc.onclick=locateUser;if(fit)fit.onclick=fitMapData;if(full)full.onclick=toggleMapFullscreen;
  if(toggle&&wrap){toggle.onclick=e=>{e.stopPropagation();const open=wrap.classList.toggle('open');toggle.setAttribute('aria-expanded',String(open))};menu?.querySelectorAll('[data-map-style]').forEach(b=>b.onclick=e=>{e.stopPropagation();setMapStyle(b.dataset.mapStyle);wrap.classList.remove('open');toggle.setAttribute('aria-expanded','false')});document.addEventListener('click',e=>{if(!wrap.contains(e.target)){wrap.classList.remove('open');toggle.setAttribute('aria-expanded','false')}})}
}
function locateUser(){
  if(!navigator.geolocation)return toast('Este navegador não oferece localização.','bad');
  const btn=document.getElementById('mapLocateMe');if(btn){btn.disabled=true;btn.classList.add('locating')}
  navigator.geolocation.getCurrentPosition(pos=>{const pt=[pos.coords.latitude,pos.coords.longitude];if(tUserMarker){tUserMarker.setLatLng(pt)}else{tUserMarker=L.marker(pt,{icon:L.divIcon({className:'a7w-user-location',html:'<span></span>',iconSize:[18,18],iconAnchor:[9,9]})}).addTo(tMap).bindTooltip('Sua localização',{direction:'top',offset:[0,-10]})}tMap.setView(pt,Math.max(tMap.getZoom(),16),{animate:true});if(btn){btn.disabled=false;btn.classList.remove('locating')}},err=>{if(btn){btn.disabled=false;btn.classList.remove('locating')}toast(err.code===1?'Permissão de localização não concedida.':'Não consegui obter sua localização.','bad')},{enableHighAccuracy:true,timeout:8000,maximumAge:30000});
}
function fitMapData(){
  const layers=[...tRouteLayers,...tStopLayers,...tReferenceLayers,tVehicleMarker,tUserMarker].filter(Boolean);if(!layers.length)return toast('Ainda não há pontos suficientes para enquadrar.','bad');
  try{const group=L.featureGroup(layers);const bounds=group.getBounds();if(bounds.isValid())tMap.fitBounds(bounds,{padding:[45,45],maxZoom:16,animate:true})}catch(_){centerCurrent()}
}
function toggleMapFullscreen(){const shell=document.querySelector('.fleet-map-shell');if(!shell)return;if(document.fullscreenElement)document.exitFullscreen?.();else if(shell.requestFullscreen)shell.requestFullscreen();else toast('Tela cheia não é suportada neste navegador.','bad')}

function bindTracking(){
  deviceSelect.onchange=()=>{stopPlayback();tFollow=false;tInitialFit=false;refreshTracking()};
  trackingDate.onchange=()=>{stopPlayback();tInitialFit=false;refreshTracking()};
  centerVehicle.onclick=()=>{tFollow=!tFollow;syncFollow();if(tFollow)centerCurrent()};
  refreshTrackingBtn.onclick=refreshTracking;
  vehicleCardMode.onclick=e=>{e.stopPropagation();const open=vehicleDisplayControl.classList.toggle('open');vehicleCardMode.setAttribute('aria-expanded',String(open))};
  vehicleDisplayMenu.querySelectorAll('[data-vehicle-mode]').forEach(btn=>btn.onclick=e=>{e.stopPropagation();setBubbleMode(btn.dataset.vehicleMode);vehicleDisplayControl.classList.remove('open');vehicleCardMode.setAttribute('aria-expanded','false')});
  document.addEventListener('click',e=>{if(!e.target.closest('#vehicleDisplayControl')){vehicleDisplayControl.classList.remove('open');vehicleCardMode.setAttribute('aria-expanded','false')}});
  playbackBtn.onclick=togglePlayback;
  playbackRange.oninput=()=>{stopPlayback(false);setPlaybackIndex(Number(playbackRange.value||0),true)};
}
function syncFollow(){centerVehicle.textContent=tFollow?'Seguindo veículo':'Acompanhar veículo';centerVehicle.classList.toggle('primary',tFollow);liveMode.textContent=tFollow?'Acompanhamento ativo':'Atualização automática'}
function setBubbleMode(mode){tBubbleMode=['vehicle','dock','hidden'].includes(mode)?mode:'vehicle';localStorage.setItem('a7wVehicleCardMode',tBubbleMode);syncBubbleMode();renderVehicleCard()}
function syncBubbleMode(){
  vehicleDock.classList.toggle('visible',tBubbleMode==='dock');
  vehicleDisplayControl.dataset.mode=tBubbleMode;
  vehicleDisplayMenu.querySelectorAll('[data-vehicle-mode]').forEach(b=>b.classList.toggle('active',b.dataset.vehicleMode===tBubbleMode));
  vehicleCardMode.title=tBubbleMode==='vehicle'?'Painel sobre o veículo':tBubbleMode==='dock'?'Painel no canto':'Painel oculto';
}
function isToday(){return trackingDate.value===new Date().toLocaleDateString('en-CA')}
async function loadSettings(){try{tSettings=await api('/api/tracking/settings')}catch(_){tSettings={fuel_efficiency_km_l:10}}}
async function loadDevices(){const previous=deviceSelect.value;tDevices=await api('/api/tracking/devices');deviceSelect.innerHTML=tDevices.length?tDevices.map(d=>`<option value="${esc(d.device_key)}">${esc(d.vehicle_name||d.label||d.device_key)}${d.driver_name?' · '+esc(d.driver_name):''}</option>`).join(''):'<option value="">Nenhum dispositivo</option>';if(previous&&tDevices.some(d=>d.device_key===previous))deviceSelect.value=previous;syncBubbleMode()}
async function loadReferences(){try{tReferences=await api('/api/tracking/references');drawReferences()}catch(_){tReferences=[]}}
function drawReferences(){tReferenceLayers.forEach(x=>{try{tMap.removeLayer(x)}catch(_){}});tReferenceLayers=[];tReferences.forEach(r=>{const inner=r.is_primary?'<img src="/assets/a7w-logo-light.png" alt="A7W">':'<span>◆</span>';const icon=L.divIcon({className:'a7w-reference-icon',html:`<div class="a7w-ref-float"><div class="a7w-ref-drop"><div class="a7w-ref-core">${inner}</div></div><i class="a7w-ref-shadow"></i></div>`,iconSize:[54,68],iconAnchor:[27,62]});const m=L.marker([Number(r.latitude),Number(r.longitude)],{icon}).addTo(tMap).bindPopup(`<b>${esc(r.name)}</b><br>${esc(r.address||'Ponto de referência')}`);tReferenceLayers.push(m)})}
function primaryReference(){return tReferences.find(x=>x.is_primary)||tReferences[0]}
function havKm(a,b,c,d){const R=6371,rad=x=>x*Math.PI/180,p1=rad(a),p2=rad(c),dp=rad(c-a),dl=rad(d-b),x=Math.sin(dp/2)**2+Math.cos(p1)*Math.cos(p2)*Math.sin(dl/2)**2;return 2*R*Math.atan2(Math.sqrt(x),Math.sqrt(1-x))}
function selectedDevice(){return tDevices.find(x=>x.device_key===deviceSelect.value)||tDevices[0]}
async function loadPlannedRoute(){const d=selectedDevice();tPlannedStops=[];if(!d?.vehicle_id||!trackingDate.value)return;try{tPlannedStops=await api(`/api/tracking/route-stops?vehicle_id=${encodeURIComponent(d.vehicle_id)}&date=${encodeURIComponent(trackingDate.value)}`)}catch(_){}}
function cardData(){const d=selectedDevice();if(!d)return null;const ref=primaryReference();let dist='';if(ref&&Number.isFinite(Number(d.last_lat))&&Number.isFinite(Number(d.last_lon)))dist=`${havKm(Number(d.last_lat),Number(d.last_lon),Number(ref.latitude),Number(ref.longitude)).toFixed(1).replace('.',',')} km da ${esc(ref.name)}`;const next=tProgress.next||tPlannedStops[0];return {d,dist,next}}
function vehicleCardHtml(){const x=cardData();if(!x)return '<div class="vehicle-card-empty">Sem veículo selecionado</div>';const {d,dist,next}=x;return `<div class="vehicle-bubble-card"><div class="vehicle-bubble-head"><span class="signal-rings"><i></i><i></i><i></i></span><div><b>${esc(d.vehicle_name||d.label||d.device_key)}</b><small>${esc(d.driver_name||'Sem motorista')}</small></div></div><div class="vehicle-bubble-speed">${Number(d.last_speed||0).toFixed(0)} <small>km/h</small></div>${next?`<div class="vehicle-bubble-destination"><span>Próxima parada</span><b>${esc(next.name)}</b><small>${esc(next.address||'Endereço não informado')}${tProgress.eta_minutes?' · ~'+tProgress.eta_minutes+' min':''}</small></div>`:''}<div class="vehicle-bubble-foot"><span>${d.last_seen_at?'GPS '+fmtDate(d.last_seen_at):'Sem atualização'}</span>${dist?`<span>${dist}</span>`:''}</div></div>`}
function renderVehicleCard(){const html=vehicleCardHtml();vehicleDock.innerHTML=html;vehicleDock.classList.toggle('visible',tBubbleMode==='dock');if(!tVehicleMarker)return;tVehicleMarker.unbindTooltip();if(tBubbleMode==='vehicle'){tVehicleMarker.bindTooltip(html,{permanent:true,direction:'top',offset:[0,-18],className:'vehicle-live-bubble',opacity:1}).openTooltip()}}

async function refreshLiveOnly(){if(!isToday())return;const key=deviceSelect.value;if(!key)return;try{await loadDevices();const d=tDevices.find(x=>x.device_key===key);if(!d)return;moveLiveMarker(d);metricCurrent.textContent=(Number(d.last_speed||0)).toFixed(0)+' km/h';renderEvents()}catch(_){}}
async function refreshMetricsOnly(){const key=deviceSelect.value,date=trackingDate.value;if(!key||!date)return;try{const [metrics,progress]=await Promise.all([api(`/api/tracking/metrics?device_id=${encodeURIComponent(key)}&date=${encodeURIComponent(date)}`),api(`/api/tracking/route-progress?device_id=${encodeURIComponent(key)}&date=${encodeURIComponent(date)}`)]);tMetrics=metrics;tStops=tMetrics.stops||[];tProgress=progress||{};renderMetrics(tMetrics);renderStops(tStops);renderProgress();renderEvents();await evaluateAlerts(false)}catch(_){}}
async function refreshTracking(){
  const key=deviceSelect.value,date=trackingDate.value;if(!key||!date){renderMetrics({});renderStops([]);renderProgress();renderEvents();return}
  try{
    await loadPlannedRoute();
    const [hist,metrics,progress]=await Promise.all([
      api(`/api/tracking/history?device_id=${encodeURIComponent(key)}&date=${encodeURIComponent(date)}`),
      api(`/api/tracking/metrics?device_id=${encodeURIComponent(key)}&date=${encodeURIComponent(date)}`),
      api(`/api/tracking/route-progress?device_id=${encodeURIComponent(key)}&date=${encodeURIComponent(date)}`)
    ]);
    tHistory=hist;tMetrics=metrics;tStops=metrics.stops||[];tProgress=progress||{};
    renderMetrics(metrics);renderStops(tStops);drawHistory(tStops);drawReferences();setupPlayback();renderProgress();await evaluateAlerts(false);renderEvents();renderVehicleCard();
  }catch(e){toast(e.message,'bad')}
}
function renderMetrics(m){
  const km=Number(m.distance_km||0),eff=Number(tSettings.fuel_efficiency_km_l||10);
  metricKm.textContent=km.toLocaleString('pt-BR',{minimumFractionDigits:1,maximumFractionDigits:1})+' km';
  metricFuel.textContent=eff>0?(km/eff).toLocaleString('pt-BR',{minimumFractionDigits:1,maximumFractionDigits:1})+' L':'—';
  metricMove.textContent=minutesLabel(m.moving_minutes);metricStop.textContent=minutesLabel(m.stopped_minutes);
  metricCurrent.textContent=(Number(m.last?.speed_kmh||selectedDevice()?.last_speed||0)).toFixed(0)+' km/h';metricMax.textContent=(Number(m.max_speed_kmh||0)).toFixed(0)+' km/h';metricAvg.textContent=(Number(m.avg_moving_kmh||0)).toFixed(0)+' km/h';metricGap.textContent=minutesLabel(m.gap_minutes);metricPoints.textContent=Number(m.points||0).toLocaleString('pt-BR')
}
function renderProgress(){const p=tProgress||{};routeProgressPct.textContent=(p.percent||0)+'%';routeProgressBar.style.width=(p.percent||0)+'%';routeProgressText.textContent=p.total?`${p.reached||0} de ${p.total} paradas alcançadas`:'Sem rota planejada';routeNextStop.textContent=p.next?.name||'—';routeEta.textContent=p.next?(p.eta_minutes?`ETA aproximado: ${p.eta_minutes} min · ${Number(p.next.distance_km||0).toFixed(1).replace('.',',')} km em linha reta`:`${Number(p.next.distance_km||0).toFixed(1).replace('.',',')} km em linha reta · veículo parado ou sem velocidade`):'Rota concluída ou sem próxima parada'}
async function evaluateAlerts(showToast=false){const key=deviceSelect.value,date=trackingDate.value;if(!key||!date)return;try{const r=await api('/api/tracking/events/evaluate',{method:'POST',body:JSON.stringify({device_id:key,date})});tFleetEvents=await api(`/api/tracking/events?device_id=${encodeURIComponent(key)}&start=${encodeURIComponent(date)}&end=${encodeURIComponent(date)}`);const attention=tFleetEvents.filter(x=>x.severity!=='info').length;alertCount.textContent=attention;if(showToast&&r.created)toast(`${r.created} novo(s) evento(s) registrado(s).`);renderEvents()}catch(_){}}
function eventTitle(e){return e.title||({overspeed:'Excesso de velocidade',delivery_stop:'Parada de entrega provável',traffic_stop:'Trânsito provável',unplanned_stop:'Parada não planejada',idle:'Marcha lenta'})[e.event_type]||e.event_type}
function renderEvents(){const d=selectedDevice(),events=[];if(d?.last_seen_at)events.push({time:d.last_seen_at,type:Number(d.last_speed||0)>=4?'moving':'gps',title:Number(d.last_speed||0)>=4?'Veículo em movimento':'Última atualização GPS',detail:`${Number(d.last_speed||0).toFixed(0)} km/h${d.battery!=null?' · bateria '+Math.round(Number(d.battery))+'%':''}`});tStops.forEach((s,i)=>events.push({time:s.start,type:'stop',title:`Parada ${i+1} · ${minutesLabel(Number(s.duration_seconds||0)/60)}`,detail:`${fmtDate(s.start)} → ${fmtDate(s.end)}`}));tFleetEvents.forEach(e=>events.push({time:e.occurred_at,type:e.severity==='critical'?'critical':e.event_type==='overspeed'||e.event_type==='unplanned_stop'||e.event_type==='idle'?'alert':'event',title:eventTitle(e),detail:e.details||''}));events.sort((a,b)=>new Date(b.time)-new Date(a.time));eventCount.textContent=events.length;eventTimeline.innerHTML=events.length?events.slice(0,22).map(e=>`<div class="fleet-event ${esc(e.type)}"><span class="fleet-event-dot"></span><time>${timeOnly(e.time)}</time><div><b>${esc(e.title)}</b><small>${esc(e.detail)}</small></div></div>`).join(''):'<div class="empty">Sem eventos para este período.</div>'}
function timeOnly(v){if(!v)return'—';const d=new Date(v);return Number.isNaN(d.getTime())?'—':d.toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'})}
function renderStops(stops){stopList.className=stops.length?'stop-list':'empty';stopList.innerHTML=stops.length?stops.map((s,i)=>`<button class="stop-row" data-stop="${i}"><span>${i+1}</span><div><b>${minutesLabel(Number(s.duration_seconds||0)/60)} parado</b><small>${fmtDate(s.start)} → ${fmtDate(s.end)}</small></div></button>`).join(''):'Nenhuma parada de 5 minutos ou mais detectada para esta data.';stopList.querySelectorAll?.('[data-stop]').forEach(b=>b.onclick=()=>{const s=stops[Number(b.dataset.stop)];tFollow=false;syncFollow();tMap.setView([s.lat,s.lon],17)})}
function minutesLabel(v){v=Number(v||0);if(v<60)return `${Math.round(v)} min`;return `${Math.floor(v/60)}h ${Math.round(v%60)}m`}

function clearDataLayers(){tRouteLayers.forEach(x=>{try{tMap.removeLayer(x)}catch(_){}});tRouteLayers=[];tStopLayers.forEach(x=>{try{tMap.removeLayer(x)}catch(_){}});tStopLayers=[];if(tVehicleMarker){try{tMap.removeLayer(tVehicleMarker)}catch(_){ }tVehicleMarker=null}if(tPlaybackMarker){try{tMap.removeLayer(tPlaybackMarker)}catch(_){ }tPlaybackMarker=null}}
function deviceStatus(d){if(!d?.last_seen_at||Date.now()-new Date(d.last_seen_at).getTime()>5*60*1000)return'offline';if(Number(d.last_speed||0)>=4)return'moving';return'stopped'}
function vehicleIcon(b,status='moving'){const angle=((Number(b)||0)%360+360)%360;const svg=`<svg viewBox="0 0 30 50" aria-hidden="true"><path class="vehicle-body" d="M7 4h16l4 8v28c0 3-2 6-5 6H8c-3 0-5-3-5-6V12z"/><path class="vehicle-glass" d="M8 10h14l2.5 6H5.5z"/><rect class="vehicle-roof" x="7" y="19" width="16" height="16" rx="4"/><path class="vehicle-front" d="M8 39h14l-2 4H10z"/><circle class="vehicle-light" cx="8" cy="7" r="1.4"/><circle class="vehicle-light" cx="22" cy="7" r="1.4"/></svg>`;return L.divIcon({className:`vehicle-status-icon ${status}`,html:`<span class="vehicle-map-shell" style="--vehicle-bearing:${angle}deg">${svg}</span>`,iconSize:[34,50],iconAnchor:[17,25]})}
function speedColor(v){v=Number(v||0);if(v<15)return'#4c9b72';if(v<60)return'#2f78ae';if(v<90)return'#4c62a7';return'#d59b24'}
function drawHistory(stops){
  clearDataLayers();const rows=tHistory.filter(x=>Number.isFinite(Number(x.latitude))&&Number.isFinite(Number(x.longitude)));
  for(let i=1;i<rows.length;i++){const a=rows[i-1],b=rows[i];const line=L.polyline([[Number(a.latitude),Number(a.longitude)],[Number(b.latitude),Number(b.longitude)]],{weight:4,opacity:.82,color:speedColor(b.speed_kmh),className:'tracked-route-line'}).addTo(tMap);tRouteLayers.push(line)}
  if(rows.length){const last=rows.at(-1),pt=[Number(last.latitude),Number(last.longitude)];tLastLive=pt;tVehicleMarker=L.marker(pt,{icon:vehicleIcon(last?.bearing,deviceStatus(selectedDevice()))}).addTo(tMap);renderVehicleCard();if(!tInitialFit&&tRouteLayers.length){const group=L.featureGroup(tRouteLayers);tMap.fitBounds(group.getBounds(),{padding:[40,40],maxZoom:16});tInitialFit=true}if(tFollow)tMap.panTo(pt)}
  stops.forEach((s,i)=>{const m=L.circleMarker([s.lat,s.lon],{radius:7,weight:2,color:'#c88709',fillColor:'#f2b72a',fillOpacity:.88,className:'tracking-stop-marker'}).addTo(tMap).bindPopup(`<b>Parada ${i+1}</b><br>${minutesLabel(Number(s.duration_seconds||0)/60)}<br>${fmtDate(s.start)} → ${fmtDate(s.end)}`);tStopLayers.push(m)})
}
function appendRouteSegment(from,to,speed){if(!from||!to)return;const d=havKm(from[0],from[1],to[0],to[1]);if(d<0.003)return;const line=L.polyline([from,to],{weight:4,opacity:.82,color:speedColor(speed),className:'tracked-route-line'}).addTo(tMap);tRouteLayers.push(line)}
function moveLiveMarker(d){const lat=Number(d.last_lat),lon=Number(d.last_lon);if(!Number.isFinite(lat)||!Number.isFinite(lon))return;const to=[lat,lon],from=tLastLive;if(from)appendRouteSegment(from,to,d.last_speed);if(!tVehicleMarker){tVehicleMarker=L.marker(to,{icon:vehicleIcon(d.last_bearing,deviceStatus(d))}).addTo(tMap)}else{animateMarker(tVehicleMarker,from||tVehicleMarker.getLatLng(),to,1200);tVehicleMarker.setIcon(vehicleIcon(d.last_bearing,deviceStatus(d)))}tLastLive=to;renderVehicleCard();if(tFollow)tMap.panTo(to,{animate:true,duration:.8})}
function animateMarker(marker,from,to,duration){const a=Array.isArray(from)?from:[from.lat,from.lng],start=performance.now();function step(now){const p=Math.min(1,(now-start)/duration),ease=1-Math.pow(1-p,3);marker.setLatLng([a[0]+(to[0]-a[0])*ease,a[1]+(to[1]-a[1])*ease]);if(p<1)requestAnimationFrame(step)}requestAnimationFrame(step)}
function centerCurrent(){const d=selectedDevice();if(d&&Number.isFinite(Number(d.last_lat))&&Number.isFinite(Number(d.last_lon)))tMap.setView([Number(d.last_lat),Number(d.last_lon)],17,{animate:true})}

function setupPlayback(){if(tPlaybackMarker){try{tMap.removeLayer(tPlaybackMarker)}catch(_){ }tPlaybackMarker=null}playbackRange.max=Math.max(0,tHistory.length-1);playbackRange.value=0;tPlaybackIndex=0;playbackBtn.disabled=tHistory.length<2;playbackTime.textContent=tHistory.length?fmtDate(tHistory[0].recorded_at):'—';if(tVehicleMarker)tVehicleMarker.setOpacity(1)}
function playbackTick(){if(!tPlaybackTimer)return;const speed=Math.max(1,Number(playbackSpeed.value||1)),step=speed>40?Math.ceil(speed/40):1;tPlaybackIndex+=step;if(tPlaybackIndex>=tHistory.length){stopPlayback();return}setPlaybackIndex(tPlaybackIndex,true);const delay=Math.max(24,900/Math.min(speed,40));tPlaybackTimer=setTimeout(playbackTick,delay)}
function togglePlayback(){if(tPlaybackTimer){stopPlayback();return}if(tHistory.length<2)return;if(tVehicleMarker)tVehicleMarker.setOpacity(0);setPlaybackIndex(tPlaybackIndex||0,false);playbackBtn.textContent='❚❚';tPlaybackTimer=setTimeout(playbackTick,Math.max(24,900/Math.min(Math.max(1,Number(playbackSpeed.value||1)),40)))}
function stopPlayback(resetIcon=true){if(tPlaybackTimer){clearTimeout(tPlaybackTimer);tPlaybackTimer=null}if(tPlaybackMarker){try{tMap.removeLayer(tPlaybackMarker)}catch(_){ }tPlaybackMarker=null}if(tVehicleMarker)tVehicleMarker.setOpacity(1);if(resetIcon&&playbackBtn)playbackBtn.textContent='▶'}
function setPlaybackIndex(i,pan=false){if(!tHistory.length)return;tPlaybackIndex=Math.max(0,Math.min(tHistory.length-1,i));playbackRange.value=tPlaybackIndex;const r=tHistory[tPlaybackIndex],pt=[Number(r.latitude),Number(r.longitude)];playbackTime.textContent=fmtDate(r.recorded_at);if(tVehicleMarker)tVehicleMarker.setOpacity(0);if(!tPlaybackMarker)tPlaybackMarker=L.marker(pt,{icon:vehicleIcon(r.bearing,'playback'),zIndexOffset:1000,keyboard:false}).addTo(tMap);else{tPlaybackMarker.setLatLng(pt);tPlaybackMarker.setIcon(vehicleIcon(r.bearing,'playback'))}if(pan)tMap.panTo(pt,{animate:true,duration:.28})}
