const { pool } = require('./db');

async function audit(req, action, entityType=null, entityId=null, metadata=null){
  try{
    await pool.execute(`INSERT INTO platform_audit_log(actor_user_id,action,entity_type,entity_id,ip_address,metadata) VALUES(?,?,?,?,?,?)`,[
      req.session?.user?.id || null, action, entityType, entityId ? String(entityId) : null,
      req.ip || null, metadata ? JSON.stringify(metadata) : null
    ]);
  }catch(_){ }
}
async function event(eventType, entityType, entityId, payload){
  await pool.execute(`INSERT INTO platform_integration_events(event_type,entity_type,entity_id,payload) VALUES(?,?,?,?)`,[
    eventType, entityType || null, entityId ? String(entityId) : null, JSON.stringify(payload || {})
  ]);
}
function orderCode(){
  const now = new Date();
  return `A7W-${now.getFullYear()}${String(now.getMonth()+1).padStart(2,'0')}-${String(Date.now()).slice(-6)}`;
}
function quoteCode(){ return `COT-${String(Date.now()).slice(-8)}`; }
function cleanText(v,max=500){ return String(v ?? '').trim().slice(0,max); }
module.exports={audit,event,orderCode,quoteCode,cleanText};
