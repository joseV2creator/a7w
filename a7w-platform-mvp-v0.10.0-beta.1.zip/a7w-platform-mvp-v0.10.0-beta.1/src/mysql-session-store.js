const session = require('express-session');

class MySQLSessionStore extends session.Store {
  constructor(pool){
    super(); this.pool=pool;
  }
  async init(){
    await this.pool.query(`CREATE TABLE IF NOT EXISTS platform_sessions (
      session_id VARCHAR(128) PRIMARY KEY,
      expires_at BIGINT NOT NULL,
      data MEDIUMTEXT NOT NULL,
      INDEX idx_sessions_exp(expires_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
    setInterval(()=>this.pool.execute('DELETE FROM platform_sessions WHERE expires_at < ?',[Date.now()]).catch(()=>{}),15*60*1000).unref();
  }
  get(sid,cb){this.pool.execute('SELECT data,expires_at FROM platform_sessions WHERE session_id=? LIMIT 1',[sid]).then(([r])=>{if(!r[0]||Number(r[0].expires_at)<Date.now())return cb(null,null);cb(null,JSON.parse(r[0].data));}).catch(cb);}
  set(sid,sess,cb){const exp=sess.cookie?.expires?new Date(sess.cookie.expires).getTime():Date.now()+8*60*60*1000;this.pool.execute(`INSERT INTO platform_sessions(session_id,expires_at,data) VALUES(?,?,?) ON DUPLICATE KEY UPDATE expires_at=VALUES(expires_at),data=VALUES(data)`,[sid,exp,JSON.stringify(sess)]).then(()=>cb&&cb()).catch(e=>cb&&cb(e));}
  destroy(sid,cb){this.pool.execute('DELETE FROM platform_sessions WHERE session_id=?',[sid]).then(()=>cb&&cb()).catch(e=>cb&&cb(e));}
  touch(sid,sess,cb){const exp=sess.cookie?.expires?new Date(sess.cookie.expires).getTime():Date.now()+8*60*60*1000;this.pool.execute('UPDATE platform_sessions SET expires_at=? WHERE session_id=?',[exp,sid]).then(()=>cb&&cb()).catch(e=>cb&&cb(e));}
}
module.exports={MySQLSessionStore};
