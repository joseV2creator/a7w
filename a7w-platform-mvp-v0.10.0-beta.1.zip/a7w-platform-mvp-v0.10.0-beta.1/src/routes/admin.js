const express=require('express');
const {pool}=require('../db');
const {requireRole,hashPassword,normalizeEmail,validEmail}=require('../security');
const {audit,event,cleanText}=require('../helpers');
const router=express.Router();
router.use(requireRole('admin','manager'));

router.get('/overview',async(req,res)=>{
  const [[users],[companies],[orders],[pendingCompanies]] = await Promise.all([
    pool.execute(`SELECT COUNT(*) total FROM platform_users WHERE active=1`),
    pool.execute(`SELECT COUNT(*) total FROM platform_companies WHERE status='approved'`),
    pool.execute(`SELECT COUNT(*) total FROM platform_orders WHERE created_at>=DATE_FORMAT(CURRENT_DATE,'%Y-%m-01')`),
    pool.execute(`SELECT COUNT(*) total FROM platform_companies WHERE status='pending'`)
  ]);
  res.json({users:users[0].total,companies:companies[0].total,orders:orders[0].total,pending_companies:pendingCompanies[0].total});
});

router.get('/companies',async(req,res)=>{
  const [rows]=await pool.execute(`SELECT c.*,u.full_name assigned_seller,u.email assigned_seller_email
    FROM platform_companies c LEFT JOIN platform_users u ON u.id=c.assigned_sales_user_id
    ORDER BY FIELD(c.status,'pending','approved','suspended','rejected'),c.id DESC LIMIT 500`);
  res.json(rows);
});
router.put('/companies/:id',async(req,res)=>{
  const id=Number(req.params.id),status=String(req.body.status||'');
  if(!['pending','approved','rejected','suspended'].includes(status))return res.status(400).json({error:'INVALID_STATUS'});
  const seller=req.body.assigned_sales_user_id?Number(req.body.assigned_sales_user_id):null;
  const creditStatus=String(req.body.credit_status||'not_reviewed');
  if(!['not_reviewed','under_review','approved','rejected'].includes(creditStatus))return res.status(400).json({error:'INVALID_CREDIT_STATUS'});
  const creditLimit=req.body.credit_limit==null||req.body.credit_limit===''?null:Number(req.body.credit_limit);
  await pool.execute(`UPDATE platform_companies SET status=?,assigned_sales_user_id=?,credit_status=?,credit_limit=? WHERE id=?`,[status,seller,creditStatus,creditLimit,id]);
  if(status==='approved') await pool.execute(`UPDATE platform_users SET active=1,email_verified_at=COALESCE(email_verified_at,NOW()) WHERE company_id=? AND role='buyer'`,[id]);
  if(['suspended','rejected'].includes(status)) await pool.execute(`UPDATE platform_users SET active=0 WHERE company_id=? AND role='buyer'`,[id]);
  await audit(req,'company.updated','company',id,{status,seller,credit_status:creditStatus,credit_limit:creditLimit});
  await event('company.updated','company',id,{status,seller_user_id:seller,credit_status:creditStatus,credit_limit:creditLimit});
  res.json({ok:true});
});

router.get('/users',async(req,res)=>{
  const [rows]=await pool.execute(`SELECT u.id,u.company_id,u.full_name,u.email,u.role,u.active,u.email_verified_at,u.last_login_at,u.created_at,c.trade_name,c.legal_name
    FROM platform_users u LEFT JOIN platform_companies c ON c.id=u.company_id ORDER BY u.id DESC LIMIT 700`);
  res.json(rows);
});
router.post('/users',requireRole('admin'),async(req,res)=>{
  const email=normalizeEmail(req.body.email),name=cleanText(req.body.full_name,160),role=String(req.body.role||''),password=String(req.body.password||'');
  if(!name||!validEmail(email)||password.length<8||!['admin','manager','sales','operations','logistics','buyer'].includes(role))return res.status(400).json({error:'INVALID_USER'});
  const [exists]=await pool.execute(`SELECT id FROM platform_users WHERE email=? LIMIT 1`,[email]);if(exists.length)return res.status(409).json({error:'EMAIL_IN_USE'});
  const hash=await hashPassword(password);const companyId=req.body.company_id?Number(req.body.company_id):null;
  const verified=role==='buyer'?null:new Date();
  const [r]=await pool.execute(`INSERT INTO platform_users(company_id,full_name,email,password_hash,role,active,email_verified_at,driver_id) VALUES(?,?,?,?,?,?,?,?)`,[companyId,name,email,hash,role,req.body.active===false?0:1,verified,req.body.driver_id||null]);
  await audit(req,'user.created','user',r.insertId,{role,email,company_id:companyId});res.json({ok:true,id:r.insertId});
});
router.put('/users/:id',requireRole('admin'),async(req,res)=>{
  const id=Number(req.params.id);const [rows]=await pool.execute(`SELECT id,role FROM platform_users WHERE id=? LIMIT 1`,[id]);if(!rows.length)return res.status(404).json({error:'NOT_FOUND'});
  if(id===Number(req.session.user.id)&&req.body.active===false)return res.status(400).json({error:'CANNOT_DISABLE_SELF'});
  const allowedRoles=['admin','manager','sales','operations','logistics','buyer'];
  const fields=[],vals=[];
  if(req.body.full_name!==undefined){const name=cleanText(req.body.full_name,160);if(!name)return res.status(400).json({error:'INVALID_USER'});fields.push('full_name=?');vals.push(name);}
  if(req.body.role!==undefined){const role=String(req.body.role);if(!allowedRoles.includes(role))return res.status(400).json({error:'INVALID_USER'});fields.push('role=?');vals.push(role);}
  if(req.body.active!==undefined){fields.push('active=?');vals.push(req.body.active?1:0);}
  if(req.body.company_id!==undefined){fields.push('company_id=?');vals.push(req.body.company_id?Number(req.body.company_id):null);}
  if(!fields.length)return res.json({ok:true});vals.push(id);await pool.execute(`UPDATE platform_users SET ${fields.join(',')} WHERE id=?`,vals);
  await audit(req,'user.updated','user',id,{fields:fields.map(x=>x.split('=')[0])});res.json({ok:true});
});
router.post('/users/:id/reset-password',requireRole('admin'),async(req,res)=>{
  const id=Number(req.params.id),password=String(req.body.password||'');if(password.length<8)return res.status(400).json({error:'INVALID_PASSWORD'});
  const hash=await hashPassword(password);await pool.execute(`UPDATE platform_users SET password_hash=? WHERE id=?`,[hash,id]);await audit(req,'user.password_reset','user',id);res.json({ok:true});
});
router.get('/sales-users',async(req,res)=>{const [rows]=await pool.execute(`SELECT id,full_name,email FROM platform_users WHERE role='sales' AND active=1 ORDER BY full_name`);res.json(rows);});

router.get('/products',async(req,res)=>{const [rows]=await pool.execute(`SELECT * FROM platform_products ORDER BY active DESC,id DESC`);res.json(rows);});
router.post('/products',async(req,res)=>{
  const sku=cleanText(req.body.sku,80),name=cleanText(req.body.name,180);if(!sku||!name)return res.status(400).json({error:'INVALID_PRODUCT'});
  const [r]=await pool.execute(`INSERT INTO platform_products(sku,name,category,description,unit,price,promo_price,negotiation_min_qty,free_shipping,offer_of_day,image_url,active) VALUES(?,?,?,?,?,?,?,?,?,?,?,1)`,[sku,name,cleanText(req.body.category,100)||null,cleanText(req.body.description,3000)||null,cleanText(req.body.unit,40)||'un',Number(req.body.price||0),req.body.promo_price==null?null:Number(req.body.promo_price),req.body.negotiation_min_qty==null?null:Number(req.body.negotiation_min_qty),req.body.free_shipping?1:0,req.body.offer_of_day?1:0,cleanText(req.body.image_url,500)||null]);
  await audit(req,'product.created','product',r.insertId,{sku});res.json({ok:true,id:r.insertId});
});
router.get('/audit',requireRole('admin'),async(req,res)=>{const [rows]=await pool.execute(`SELECT a.*,u.full_name actor_name,u.email actor_email FROM platform_audit_log a LEFT JOIN platform_users u ON u.id=a.actor_user_id ORDER BY a.id DESC LIMIT 200`);res.json(rows);});


router.post('/demo-environment',requireRole('admin'),async(req,res)=>{
  const password=String(req.body.password||'');
  if(password.length<8)return res.status(400).json({error:'INVALID_PASSWORD'});
  const hash=await hashPassword(password);
  const conn=await pool.getConnection();
  const emails={manager:'gerencia.teste@a7w.com.br',sales:'comercial.teste@a7w.com.br',operations:'operacao.teste@a7w.com.br',logistics:'logistica.teste@a7w.com.br',buyer:'comprador.teste@clientea7w.com.br'};
  try{
    await conn.beginTransaction();
    await conn.execute(`INSERT INTO platform_companies(cnpj,legal_name,trade_name,status,credit_status,credit_limit) VALUES('00.000.000/0000-00','Empresa Demonstração A7W Ltda','Cliente A7W · Demonstração','approved','approved',50000) ON DUPLICATE KEY UPDATE legal_name=VALUES(legal_name),trade_name=VALUES(trade_name),status='approved',credit_status='approved',credit_limit=50000`);
    const [[company]]=await conn.execute(`SELECT id FROM platform_companies WHERE cnpj='00.000.000/0000-00' LIMIT 1`);
    const companyId=company.id;
    const upsertUser=async(name,email,role,company=null,driver=null)=>{
      const [[u]]=await conn.execute(`SELECT id FROM platform_users WHERE email=? LIMIT 1`,[email]);
      if(u){await conn.execute(`UPDATE platform_users SET full_name=?,password_hash=?,role=?,active=1,email_verified_at=NOW(),company_id=?,driver_id=? WHERE id=?`,[name,hash,role,company,driver,u.id]);return u.id}
      const [r]=await conn.execute(`INSERT INTO platform_users(company_id,full_name,email,password_hash,role,active,email_verified_at,driver_id) VALUES(?,?,?,?,?,1,NOW(),?)`,[company,name,email,hash,role,driver]);return r.insertId;
    };
    const managerId=await upsertUser('Mariana Gerência · Teste',emails.manager,'manager');
    const salesId=await upsertUser('Lucas Comercial · Teste',emails.sales,'sales');
    const opsId=await upsertUser('Carla Operação · Teste',emails.operations,'operations');
    await conn.execute(`UPDATE platform_companies SET assigned_sales_user_id=? WHERE id=?`,[salesId,companyId]);
    let [[driver]]=await conn.execute(`SELECT id FROM platform_drivers WHERE name='Anderson Entregador · Teste' LIMIT 1`);
    if(!driver){const [r]=await conn.execute(`INSERT INTO platform_drivers(name,phone,active) VALUES('Anderson Entregador · Teste','11999990000',1)`);driver={id:r.insertId}}
    let [[vehicle]]=await conn.execute(`SELECT id FROM platform_vehicles WHERE plate='DEM0A7W' LIMIT 1`);
    if(!vehicle){const [r]=await conn.execute(`INSERT INTO platform_vehicles(name,plate,active) VALUES('Saveiro A7W · Teste','DEM0A7W',1)`);vehicle={id:r.insertId}}
    await conn.execute(`INSERT INTO platform_tracking_devices(device_key,label,last_lat,last_lon,last_speed,battery,last_seen_at) VALUES('A7W_DEMO_01','Dispositivo · Teste',-23.4543,-46.5337,0,78,UTC_TIMESTAMP()) ON DUPLICATE KEY UPDATE label=VALUES(label),battery=78,last_seen_at=UTC_TIMESTAMP()`);
    const [[device]]=await conn.execute(`SELECT id FROM platform_tracking_devices WHERE device_key='A7W_DEMO_01' LIMIT 1`);
    const [[assign]]=await conn.execute(`SELECT id FROM platform_assignments WHERE driver_id=? AND vehicle_id=? AND active=1 LIMIT 1`,[driver.id,vehicle.id]);
    if(!assign)await conn.execute(`INSERT INTO platform_assignments(driver_id,vehicle_id,tracking_device_id,active) VALUES(?,?,?,1)`,[driver.id,vehicle.id,device.id]);else await conn.execute(`UPDATE platform_assignments SET tracking_device_id=? WHERE id=?`,[device.id,assign.id]);
    const logisticsId=await upsertUser('Anderson Entregador · Teste',emails.logistics,'logistics',null,driver.id);
    const buyerId=await upsertUser('Fernanda Compradora · Teste',emails.buyer,'buyer',companyId,null);

    const demoProducts=[
      ['DEMO-KAL-AZ','Courvin Kaleidos Azul/Amarelo','Courvins','Revestimento automotivo impermeável e flexível.','m²',47,43.9,40,1,1],
      ['DEMO-DAMA-GR','Passadeira Dama Grafite','Passadeiras','Piso vinílico amadeirado para vans executivas e escolares.','m²',58,52.9,20,1,1],
      ['DEMO-CV-PR','Courvin Preto Automotivo','Courvins','Acabamento preto de alta versatilidade para interiores.','m²',45,null,35,0,0],
      ['DEMO-PISO-SA','Piso Serra Azul','Pisos','Piso automotivo para aplicações de alto tráfego.','m²',61.6,null,25,0,0]
    ];
    for(const x of demoProducts)await conn.execute(`INSERT INTO platform_products(sku,name,category,description,unit,price,promo_price,negotiation_min_qty,free_shipping,offer_of_day,active) VALUES(?,?,?,?,?,?,?,?,?,?,1) ON DUPLICATE KEY UPDATE name=VALUES(name),category=VALUES(category),description=VALUES(description),unit=VALUES(unit),price=VALUES(price),promo_price=VALUES(promo_price),negotiation_min_qty=VALUES(negotiation_min_qty),free_shipping=VALUES(free_shipping),offer_of_day=VALUES(offer_of_day),active=1`,x);

    const [[quote]]=await conn.execute(`SELECT id FROM platform_quotes WHERE code='DEMO-COT-001' LIMIT 1`);
    if(!quote)await conn.execute(`INSERT INTO platform_quotes(code,seller_user_id,company_id,customer_name,amount,status) VALUES('DEMO-COT-001',?,?, 'Cliente A7W · Demonstração',12840,'negotiation')`,[salesId,companyId]);
    let [[order]]=await conn.execute(`SELECT id FROM platform_orders WHERE code='DEMO-PED-001' LIMIT 1`);
    if(!order){const [r]=await conn.execute(`INSERT INTO platform_orders(code,company_id,buyer_user_id,seller_user_id,status,payment_mode,requested_terms,total_amount,negotiation_requested,notes) VALUES('DEMO-PED-001',?,?,?,'approved','invoice_request','30/60/90 dias',9138,1,'Pedido demonstrativo para testes de fluxo.')`,[companyId,buyerId,salesId]);order={id:r.insertId};await conn.execute(`INSERT INTO platform_order_history(order_id,status,title,details,actor_user_id) VALUES(?, 'submitted','Pedido recebido','Ambiente demonstrativo criado.',?), (?, 'approved','Pedido aprovado','Crédito demonstrativo aprovado.',?)`,[order.id,buyerId,order.id,managerId]);}
    const [[delivery]]=await conn.execute(`SELECT id FROM platform_deliveries WHERE order_id=? LIMIT 1`,[order.id]);
    if(!delivery)await conn.execute(`INSERT INTO platform_deliveries(order_id,driver_id,vehicle_id,status,sequence_no,address,lat,lon,planned_at) VALUES(?,?,?,'on_route',1,'Av. Monteiro Lobato, Guarulhos - SP',-23.4543,-46.5337,NOW())`,[order.id,driver.id,vehicle.id]);

    const [[locCount]]=await conn.execute(`SELECT COUNT(*) n FROM platform_location_points WHERE device_key='A7W_DEMO_01' AND recorded_at>=UTC_TIMESTAMP()-INTERVAL 1 DAY`);
    if(!locCount.n){
      const pts=[
        [-23.4668,-46.5271,0,88,140],[-23.4662,-46.5278,18,87,135],[-23.4648,-46.5291,32,86,130],[-23.4630,-46.5305,38,85,125],[-23.4610,-46.5320,42,84,120],[-23.4593,-46.5330,35,83,115],[-23.4580,-46.5335,12,82,110],[-23.4578,-46.5336,0,82,105],[-23.4578,-46.5336,0,81,95],[-23.4578,-46.5336,0,81,85],[-23.4578,-46.5336,0,80,75],[-23.4567,-46.5337,15,80,65],[-23.4555,-46.5338,24,79,55],[-23.4549,-46.5338,19,79,45],[-23.4543,-46.5337,0,78,35],[-23.4543,-46.5337,0,78,25],[-23.4543,-46.5337,0,78,15],[-23.4543,-46.5337,0,78,0]
      ];
      for(const [lat,lon,speed,batt,mins] of pts)await conn.execute(`INSERT INTO platform_location_points(device_key,latitude,longitude,accuracy,speed_kmh,battery,bearing,source,recorded_at) VALUES('A7W_DEMO_01',?,?,?,?,?,45,'demo',UTC_TIMESTAMP()-INTERVAL ? MINUTE)`,[lat,lon,8,speed,batt,mins]);
      await conn.execute(`UPDATE platform_tracking_devices SET last_lat=-23.4543,last_lon=-46.5337,last_speed=0,battery=78,last_seen_at=UTC_TIMESTAMP() WHERE device_key='A7W_DEMO_01'`);
    }
    const [[stopCount]]=await conn.execute(`SELECT COUNT(*) n FROM platform_route_stops WHERE vehicle_id=? AND route_date=DATE(UTC_TIMESTAMP()-INTERVAL 3 HOUR)`,[vehicle.id]);
    if(!stopCount.n){const stops=[['Cliente Demo · Centro','Centro, Guarulhos - SP',-23.4543,-46.5337],['Cliente Demo · Dutra','Rod. Presidente Dutra, Guarulhos - SP',-23.4683,-46.5208],['Cliente Demo · Cumbica','Cumbica, Guarulhos - SP',-23.4379,-46.4892]];for(let i=0;i<stops.length;i++){const [n,a,lat,lon]=stops[i];await conn.execute(`INSERT INTO platform_route_stops(route_date,vehicle_id,sequence_no,name,address,latitude,longitude,source,created_by_user_id) VALUES(DATE(UTC_TIMESTAMP()-INTERVAL 3 HOUR),?,?,?,?,?,?, 'demo',?)`,[vehicle.id,i+1,n,a,lat,lon,req.session.user.id])}}
    await conn.commit();
    await audit(req,'demo.environment_created','system','demo',{emails});
    res.json({ok:true,accounts:[{role:'Gerência',email:emails.manager},{role:'Comercial',email:emails.sales},{role:'Operação',email:emails.operations},{role:'Logística',email:emails.logistics},{role:'Comprador B2B',email:emails.buyer}],device:'A7W_DEMO_01'});
  }catch(e){await conn.rollback();throw e}finally{conn.release()}
});

router.delete('/demo-environment',requireRole('admin'),async(req,res)=>{
  const conn=await pool.getConnection();try{await conn.beginTransaction();
    const [[company]]=await conn.execute(`SELECT id FROM platform_companies WHERE cnpj='00.000.000/0000-00' LIMIT 1`);
    if(company){const [orders]=await conn.execute(`SELECT id FROM platform_orders WHERE company_id=?`,[company.id]);const ids=orders.map(x=>x.id);for(const id of ids){await conn.execute(`DELETE FROM platform_order_items WHERE order_id=?`,[id]);await conn.execute(`DELETE FROM platform_order_history WHERE order_id=?`,[id]);await conn.execute(`DELETE FROM platform_deliveries WHERE order_id=?`,[id])}await conn.execute(`DELETE FROM platform_orders WHERE company_id=?`,[company.id]);await conn.execute(`DELETE FROM platform_quotes WHERE company_id=?`,[company.id]);await conn.execute(`DELETE FROM platform_users WHERE company_id=?`,[company.id]);await conn.execute(`DELETE FROM platform_companies WHERE id=?`,[company.id])}
    await conn.execute(`DELETE FROM platform_users WHERE email IN('gerencia.teste@a7w.com.br','comercial.teste@a7w.com.br','operacao.teste@a7w.com.br','logistica.teste@a7w.com.br','comprador.teste@clientea7w.com.br')`);
    const [[vehicle]]=await conn.execute(`SELECT id FROM platform_vehicles WHERE plate='DEM0A7W' LIMIT 1`);if(vehicle){await conn.execute(`DELETE FROM platform_route_stops WHERE vehicle_id=?`,[vehicle.id]);await conn.execute(`DELETE FROM platform_assignments WHERE vehicle_id=?`,[vehicle.id]);await conn.execute(`DELETE FROM platform_vehicles WHERE id=?`,[vehicle.id])}
    const [[driver]]=await conn.execute(`SELECT id FROM platform_drivers WHERE name='Anderson Entregador · Teste' LIMIT 1`);if(driver)await conn.execute(`DELETE FROM platform_drivers WHERE id=?`,[driver.id]);
    await conn.execute(`DELETE FROM platform_location_points WHERE device_key='A7W_DEMO_01'`);await conn.execute(`DELETE FROM platform_tracking_devices WHERE device_key='A7W_DEMO_01'`);await conn.execute(`DELETE FROM platform_products WHERE sku LIKE 'DEMO-%'`);
    await conn.commit();await audit(req,'demo.environment_deleted','system','demo');res.json({ok:true});
  }catch(e){await conn.rollback();throw e}finally{conn.release()}
});

module.exports=router;
