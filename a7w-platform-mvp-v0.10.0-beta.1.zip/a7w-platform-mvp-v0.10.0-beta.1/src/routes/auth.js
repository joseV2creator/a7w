const express = require('express');
const rateLimit = require('express-rate-limit');
const { pool } = require('../db');
const { normalizeEmail, validEmail, newCsrfToken, verifyPassword, roleHome, requireAuth, requireCsrf } = require('../security');
const { audit } = require('../helpers');
const router = express.Router();

const loginLimiter = rateLimit({windowMs:15*60*1000,limit:12,standardHeaders:true,legacyHeaders:false,message:{error:'TOO_MANY_ATTEMPTS'}});
router.post('/login', loginLimiter, async(req,res)=>{
  const email = normalizeEmail(req.body.email);
  const password = String(req.body.password || '');
  if(!validEmail(email) || password.length<6) return res.status(400).json({error:'INVALID_CREDENTIALS'});
  const [rows] = await pool.execute(`SELECT id,company_id,full_name,email,password_hash,role,active,driver_id FROM platform_users WHERE email=? LIMIT 1`,[email]);
  const u = rows[0];
  if(!u || !u.active || !(await verifyPassword(password,u.password_hash))) return res.status(401).json({error:'INVALID_CREDENTIALS'});
  req.session.regenerate(async err=>{
    if(err) return res.status(500).json({error:'SESSION_ERROR'});
    req.session.user={id:u.id,company_id:u.company_id,full_name:u.full_name,email:u.email,role:u.role,driver_id:u.driver_id};
    req.session.csrfToken=newCsrfToken();
    await pool.execute('UPDATE platform_users SET last_login_at=NOW() WHERE id=?',[u.id]);
    await audit(req,'auth.login','user',u.id);
    res.json({ok:true,home:roleHome(u.role),user:req.session.user,csrfToken:req.session.csrfToken});
  });
});
router.post('/logout', requireAuth, requireCsrf, async(req,res)=>{
  const uid=req.session.user.id; await audit(req,'auth.logout','user',uid);
  req.session.destroy(()=>res.json({ok:true}));
});
router.get('/me', requireAuth, (req,res)=>res.json({user:req.session.user,csrfToken:req.session.csrfToken,home:roleHome(req.session.user.role)}));
module.exports=router;
