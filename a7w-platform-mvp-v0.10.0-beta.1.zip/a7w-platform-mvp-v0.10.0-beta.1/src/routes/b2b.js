const express=require('express');
const {pool}=require('../db');
const {requireRole}=require('../security');
const {orderCode,cleanText,audit,event}=require('../helpers');
const router=express.Router();
router.get('/account',requireRole('buyer'),async(req,res)=>{const [rows]=await pool.execute(`SELECT c.id,c.cnpj,c.legal_name,c.trade_name,c.status,c.credit_status,c.credit_limit,u.full_name,u.email FROM platform_users u JOIN platform_companies c ON c.id=u.company_id WHERE u.id=? LIMIT 1`,[req.session.user.id]);if(!rows[0])return res.status(404).json({error:'NOT_FOUND'});res.json(rows[0]);});
router.get('/products',requireRole('buyer','admin','manager','sales'),async(req,res)=>{const [rows]=await pool.execute(`SELECT id,sku,name,category,description,unit,price,promo_price,negotiation_min_qty,free_shipping,offer_of_day,image_url FROM platform_products WHERE active=1 ORDER BY offer_of_day DESC,name`);res.json(rows);});
router.get('/orders',requireRole('buyer','admin','manager','operations','sales'),async(req,res)=>{
  const u=req.session.user;let where='1=1',params=[];
  if(u.role==='buyer'){where='o.company_id=?';params=[u.company_id];}
  else if(u.role==='sales'){where='o.seller_user_id=?';params=[u.id];}
  const [rows]=await pool.execute(`SELECT o.*,c.trade_name,c.legal_name FROM platform_orders o LEFT JOIN platform_companies c ON c.id=o.company_id WHERE ${where} ORDER BY o.id DESC LIMIT 200`,params);res.json(rows);
});
router.get('/orders/:id/history',requireRole('buyer','admin','manager','operations','sales','logistics'),async(req,res)=>{
  const id=Number(req.params.id);const u=req.session.user;
  const [orders]=await pool.execute(`SELECT * FROM platform_orders WHERE id=? LIMIT 1`,[id]);const o=orders[0];if(!o)return res.status(404).json({error:'NOT_FOUND'});
  if(u.role==='buyer'&&Number(o.company_id)!==Number(u.company_id))return res.status(403).json({error:'FORBIDDEN'});
  if(u.role==='sales'&&Number(o.seller_user_id)!==Number(u.id))return res.status(403).json({error:'FORBIDDEN'});
  const [rows]=await pool.execute(`SELECT status,title,details,created_at FROM platform_order_history WHERE order_id=? ORDER BY id`,[id]);res.json(rows);
});
router.post('/orders',requireRole('buyer'),async(req,res)=>{
  const companyId=req.session.user.company_id;if(!companyId)return res.status(400).json({error:'BUYER_WITHOUT_COMPANY'});
  const items=Array.isArray(req.body.items)?req.body.items:[];if(!items.length)return res.status(400).json({error:'EMPTY_CART'});
  const ids=[...new Set(items.map(x=>Number(x.product_id)).filter(Boolean))];if(!ids.length)return res.status(400).json({error:'EMPTY_CART'});
  const marks=ids.map(()=>'?').join(',');const [products]=await pool.execute(`SELECT * FROM platform_products WHERE active=1 AND id IN (${marks})`,ids);const map=new Map(products.map(p=>[Number(p.id),p]));
  let total=0,negotiation=false;const final=[];
  for(const item of items){const p=map.get(Number(item.product_id)),qty=Math.max(0,Number(item.qty||0));if(!p||qty<=0)continue;const unit=Number(p.promo_price??p.price);const line=unit*qty;total+=line;if(p.negotiation_min_qty&&qty>=Number(p.negotiation_min_qty))negotiation=true;final.push({p,qty,unit,line});}
  if(!final.length)return res.status(400).json({error:'EMPTY_CART'});
  const [companies]=await pool.execute(`SELECT assigned_sales_user_id,status FROM platform_companies WHERE id=? LIMIT 1`,[companyId]);if(!companies[0]||companies[0].status!=='approved')return res.status(403).json({error:'COMPANY_NOT_APPROVED'});
  const code=orderCode(),requestedTerms=cleanText(req.body.requested_terms,120),notes=cleanText(req.body.notes,2000),paymentMode=req.body.payment_mode==='pix'?'pix':'invoice_request';
  const conn=await pool.getConnection();try{await conn.beginTransaction();const [r]=await conn.execute(`INSERT INTO platform_orders(code,company_id,buyer_user_id,seller_user_id,status,payment_mode,requested_terms,total_amount,negotiation_requested,notes) VALUES(?,?,?,?,?,?,?,?,?,?)`,[code,companyId,req.session.user.id,companies[0].assigned_sales_user_id||null,'submitted',paymentMode,requestedTerms,total,negotiation?1:0,notes]);for(const x of final)await conn.execute(`INSERT INTO platform_order_items(order_id,product_id,product_name,sku,qty,unit_price,line_total) VALUES(?,?,?,?,?,?,?)`,[r.insertId,x.p.id,x.p.name,x.p.sku,x.qty,x.unit,x.line]);await conn.execute(`INSERT INTO platform_order_history(order_id,status,title,details,actor_user_id) VALUES(?,?,?,?,?)`,[r.insertId,'submitted','Pedido recebido','A7W recebeu sua solicitação. A análise comercial será iniciada.',req.session.user.id]);await conn.commit();await audit(req,'order.created','order',r.insertId,{code,total});await event('order.created','order',r.insertId,{code,company_id:companyId,total,payment_mode:paymentMode,requested_terms:requestedTerms});return res.json({ok:true,id:r.insertId,code,total,negotiation_requested:negotiation});}catch(e){await conn.rollback();throw e;}finally{conn.release();}
});
module.exports=router;
