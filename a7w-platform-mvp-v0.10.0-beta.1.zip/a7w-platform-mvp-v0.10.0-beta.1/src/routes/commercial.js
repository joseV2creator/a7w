const express=require('express');
const {pool}=require('../db');
const {requireRole}=require('../security');
const {quoteCode,cleanText,audit,event}=require('../helpers');
const router=express.Router();
router.use(requireRole('sales','admin','manager'));
router.get('/quotes',async(req,res)=>{
  const role=req.session.user.role;
  const params=[]; let where='1=1';
  if(role==='sales'){where='q.seller_user_id=?';params.push(req.session.user.id);}
  const [rows]=await pool.execute(`SELECT q.* FROM platform_quotes q WHERE ${where} ORDER BY q.id DESC LIMIT 200`,params);res.json(rows);
});
router.post('/quotes',async(req,res)=>{
  const seller=req.session.user.role==='sales'?req.session.user.id:Number(req.body.seller_user_id||req.session.user.id);
  const customer=cleanText(req.body.customer_name,180), amount=Number(req.body.amount||0);
  if(!customer||amount<0)return res.status(400).json({error:'INVALID_QUOTE'});
  const code=quoteCode();
  const [r]=await pool.execute(`INSERT INTO platform_quotes(code,seller_user_id,company_id,customer_name,amount,status) VALUES(?,?,?,?,?,'sent')`,[code,seller,req.body.company_id||null,customer,amount]);
  await audit(req,'quote.created','quote',r.insertId,{code});await event('quote.created','quote',r.insertId,{code,seller_user_id:seller,amount});
  res.json({ok:true,id:r.insertId,code});
});

router.put('/quotes/:id/status',async(req,res)=>{
  const id=Number(req.params.id),status=String(req.body.status||'');
  if(!['draft','sent','negotiation','approved','lost'].includes(status))return res.status(400).json({error:'INVALID_STATUS'});
  const role=req.session.user.role;const params=[status,id];let owner='';
  if(role==='sales'){owner=' AND seller_user_id=?';params.push(req.session.user.id);}
  const [r]=await pool.execute(`UPDATE platform_quotes SET status=? WHERE id=?${owner}`,params);
  if(!r.affectedRows)return res.status(404).json({error:'NOT_FOUND'});
  await audit(req,'quote.status_changed','quote',id,{status});await event('quote.status_changed','quote',id,{status});
  res.json({ok:true});
});

router.get('/sales',async(req,res)=>{
  const role=req.session.user.role, params=[];let where="o.status NOT IN('rejected','cancelled')";
  if(role==='sales'){where+=' AND o.seller_user_id=?';params.push(req.session.user.id);}
  const [rows]=await pool.execute(`SELECT o.id,o.code,o.status,o.total_amount,o.created_at,c.trade_name,c.legal_name FROM platform_orders o LEFT JOIN platform_companies c ON c.id=o.company_id WHERE ${where} ORDER BY o.id DESC LIMIT 200`,params);res.json(rows);
});
module.exports=router;
