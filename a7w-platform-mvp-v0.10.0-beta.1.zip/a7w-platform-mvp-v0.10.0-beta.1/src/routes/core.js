const express=require('express');
const {pool}=require('../db');
const {requireAuth,requireRole}=require('../security');
const router=express.Router();

router.get('/public-config',(req,res)=>res.json({mapProvider:process.env.MAP_PROVIDER||'osm',googleMapsApiKey:process.env.GOOGLE_MAPS_BROWSER_KEY||process.env.GOOGLE_MAPS_API_KEY||''}));

router.get('/map/tiles/:z/:x/:y.png',requireAuth,async(req,res)=>{
  const key=String(process.env.LOCATIONIQ_TOKEN||'').trim();
  if(!key)return res.status(503).json({error:'MAP_TILES_NOT_CONFIGURED'});
  const z=Number(req.params.z),x=Number(req.params.x),y=Number(req.params.y);
  if(!Number.isInteger(z)||!Number.isInteger(x)||!Number.isInteger(y)||z<0||z>20||x<0||y<0)return res.status(400).json({error:'INVALID_TILE'});
  try{
    const sub=['a','b','c'][Math.abs(x+y)%3];
    const url=`https://${sub}-tiles.locationiq.com/v3/streets/r/${z}/${x}/${y}.png?key=${encodeURIComponent(key)}`;
    const r=await fetch(url,{headers:{Accept:'image/png,image/*;q=0.8,*/*;q=0.5','User-Agent':'A7W-Platform/0.10.0-beta.1'}});
    if(!r.ok)return res.status(r.status).end();
    const buf=Buffer.from(await r.arrayBuffer());
    res.setHeader('Content-Type',r.headers.get('content-type')||'image/png');
    res.setHeader('Cache-Control','private, max-age=86400');
    res.send(buf);
  }catch(e){
    res.status(502).json({error:'MAP_TILE_FAILED'});
  }
});

router.get('/dashboard',requireAuth,async(req,res)=>{
  const role=req.session.user.role,uid=req.session.user.id,companyId=req.session.user.company_id;
  if(role==='sales'){
    const [[q],[o]] = await Promise.all([
      pool.execute(`SELECT COUNT(*) total,COALESCE(SUM(amount),0) amount FROM platform_quotes WHERE seller_user_id=? AND created_at>=DATE_FORMAT(CURRENT_DATE,'%Y-%m-01')`,[uid]),
      pool.execute(`SELECT COUNT(*) total,COALESCE(SUM(total_amount),0) amount FROM platform_orders WHERE seller_user_id=? AND status NOT IN('rejected','cancelled') AND created_at>=DATE_FORMAT(CURRENT_DATE,'%Y-%m-01')`,[uid])
    ]);
    return res.json({role,quotes:q[0],sales:o[0]});
  }
  if(role==='buyer'){
    const [rows]=await pool.execute(`SELECT status,COUNT(*) total FROM platform_orders WHERE company_id=? GROUP BY status`,[companyId]);
    return res.json({role,orders:rows});
  }
  const [[orders],[companies],[users]] = await Promise.all([
    pool.execute(`SELECT COUNT(*) total FROM platform_orders WHERE created_at>=DATE_FORMAT(CURRENT_DATE,'%Y-%m-01')`),
    pool.execute(`SELECT COUNT(*) total FROM platform_companies WHERE status='approved'`),
    pool.execute(`SELECT COUNT(*) total FROM platform_users WHERE active=1`)
  ]);
  res.json({role,orders:orders[0].total,companies:companies[0].total,users:users[0].total});
});
router.get('/changelog',requireRole('admin'),async(req,res)=>{
  const [rows]=await pool.execute(`SELECT version,title,summary,technical_notes,created_at FROM platform_changelog ORDER BY id DESC LIMIT 30`);res.json(rows);
});
router.get('/version',(req,res)=>res.json({version:'0.10.0-beta.1',product:'A7W Platform'}));
module.exports=router;
