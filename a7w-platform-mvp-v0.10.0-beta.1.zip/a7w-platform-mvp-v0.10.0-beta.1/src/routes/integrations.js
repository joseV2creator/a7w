const express=require('express');
const {pool}=require('../db');
const router=express.Router();
function checkSecret(req,res,next){const expected=process.env.N8N_SHARED_SECRET;if(!expected)return res.status(503).json({error:'INTEGRATION_NOT_CONFIGURED'});if(req.get('x-a7w-integration-secret')!==expected)return res.status(401).json({error:'UNAUTHORIZED'});next();}
router.get('/events',checkSecret,async(req,res)=>{const limit=Math.min(100,Math.max(1,Number(req.query.limit||25)));const [rows]=await pool.query(`SELECT id,event_type,entity_type,entity_id,payload,attempts,created_at FROM platform_integration_events WHERE status='pending' ORDER BY id LIMIT ${limit}`);res.json(rows);});
router.post('/events/:id/ack',checkSecret,async(req,res)=>{await pool.execute(`UPDATE platform_integration_events SET status='sent',sent_at=NOW(),attempts=attempts+1 WHERE id=?`,[Number(req.params.id)]);res.json({ok:true});});
router.post('/events/:id/fail',checkSecret,async(req,res)=>{await pool.execute(`UPDATE platform_integration_events SET status='failed',attempts=attempts+1 WHERE id=?`,[Number(req.params.id)]);res.json({ok:true});});
module.exports=router;
