const express=require('express');
const {pool}=require('../db');
const {requireRole}=require('../security');
const {cleanText,audit,event}=require('../helpers');
const router=express.Router();
router.use(requireRole('operations','admin','manager'));
router.get('/queue',async(req,res)=>{const [rows]=await pool.execute(`SELECT o.id,o.code,o.status,o.payment_mode,o.requested_terms,o.total_amount,o.created_at,c.trade_name,c.legal_name,c.cnpj,c.credit_status FROM platform_orders o JOIN platform_companies c ON c.id=o.company_id WHERE o.status NOT IN('delivered','rejected','cancelled') ORDER BY o.id`);res.json(rows);});
router.put('/orders/:id/status',async(req,res)=>{
  const id=Number(req.params.id),status=String(req.body.status||'');const allowed=['commercial_review','credit_review','approved','preparing','invoiced','dispatched','delivered','rejected','cancelled'];if(!allowed.includes(status))return res.status(400).json({error:'INVALID_STATUS'});
  const title=({commercial_review:'Em análise comercial',credit_review:'Em análise de crédito',approved:'Pedido aprovado',preparing:'Em preparação',invoiced:'Nota fiscal emitida',dispatched:'Saiu para entrega',delivered:'Pedido entregue',rejected:'Solicitação recusada',cancelled:'Pedido cancelado'})[status];
  await pool.execute(`UPDATE platform_orders SET status=? WHERE id=?`,[status,id]);await pool.execute(`INSERT INTO platform_order_history(order_id,status,title,details,actor_user_id) VALUES(?,?,?,?,?)`,[id,status,title,cleanText(req.body.details,500),req.session.user.id]);await audit(req,'order.status_changed','order',id,{status});await event('order.status_changed','order',id,{status,title});res.json({ok:true});
});
module.exports=router;
