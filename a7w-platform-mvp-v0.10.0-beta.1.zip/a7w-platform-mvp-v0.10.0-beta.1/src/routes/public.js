const express=require('express');
const {pool}=require('../db');
const {normalizeEmail,validEmail,hashPassword}=require('../security');
const {cleanText,event}=require('../helpers');
const router=express.Router();
function onlyDigits(v=''){return String(v).replace(/\D/g,'');}
function validCnpj(v){const c=onlyDigits(v);if(c.length!==14||/^(\d)\1+$/.test(c))return false;const calc=(base,factors)=>{let sum=0;for(let i=0;i<factors.length;i++)sum+=Number(base[i])*factors[i];const r=sum%11;return r<2?0:11-r;};const d1=calc(c,[5,4,3,2,9,8,7,6,5,4,3,2]),d2=calc(c,[6,5,4,3,2,9,8,7,6,5,4,3,2]);return d1===Number(c[12])&&d2===Number(c[13]);}
router.post('/buyer-register',async(req,res)=>{
  const email=normalizeEmail(req.body.email),cnpj=onlyDigits(req.body.cnpj),legal=cleanText(req.body.legal_name,180),trade=cleanText(req.body.trade_name,180),name=cleanText(req.body.full_name,160),password=String(req.body.password||'');
  if(!validEmail(email)||!validCnpj(cnpj)||!legal||!name||password.length<8)return res.status(400).json({error:'INVALID_REGISTRATION'});
  const [existing]=await pool.execute(`SELECT id FROM platform_users WHERE email=? LIMIT 1`,[email]);if(existing.length)return res.status(409).json({error:'EMAIL_IN_USE'});
  const conn=await pool.getConnection();try{await conn.beginTransaction();let [companies]=await conn.execute(`SELECT id,status FROM platform_companies WHERE cnpj=? LIMIT 1`,[cnpj]);let companyId;if(companies[0])companyId=companies[0].id;else{const [r]=await conn.execute(`INSERT INTO platform_companies(cnpj,legal_name,trade_name,status) VALUES(?,?,?,'pending')`,[cnpj,legal,trade||null]);companyId=r.insertId;}const hash=await hashPassword(password);const [u]=await conn.execute(`INSERT INTO platform_users(company_id,full_name,email,password_hash,role,active) VALUES(?,?,?,?, 'buyer',0)`,[companyId,name,email,hash]);await conn.commit();await event('buyer.registration_requested','company',companyId,{company_id:companyId,user_id:u.insertId,email});res.json({ok:true,status:'pending',message:'Cadastro recebido. A A7W fará a validação empresarial antes de liberar o acesso.'});}catch(e){await conn.rollback();throw e;}finally{conn.release();}
});
module.exports=router;
