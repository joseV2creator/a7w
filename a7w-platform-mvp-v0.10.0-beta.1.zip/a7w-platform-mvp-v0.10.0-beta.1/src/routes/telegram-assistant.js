const express=require('express');
const crypto=require('crypto');
const {pool}=require('../db');

const router=express.Router();
const MODEL_DEFAULT='gemini-3.8-flash';
const GROQ_MODEL_DEFAULT='openai/gpt-oss-20b';
const DEEPSEEK_MODEL_DEFAULT='deepseek-flash';
const TTS_MODEL_DEFAULT='gemini-3.1-flash-tts-preview';
const TTS_VOICE_DEFAULT='Achernar';
const GROQ_STT_DEFAULT='whisper-large-v3-turbo';
const GROQ_CHAT_ENDPOINT='https://api.groq.com/openai/v1/chat/completions';
const GROQ_STT_ENDPOINT='https://api.groq.com/openai/v1/audio/transcriptions';
const DEEPSEEK_CHAT_ENDPOINT='https://api.deepseek.com/chat/completions';
const INTERACTIONS_ENDPOINT='https://generativelanguage.googleapis.com/v1beta/interactions';
const FISH_TTS_ENDPOINT='https://api.fish.audio/v1/tts';
const FISH_MODEL_DEFAULT='s2.1-pro-free';
const MAX_AUDIO_BYTES=10*1024*1024;
const locationCache=new Map();

function tgConfig(){return {token:String(process.env.TELEGRAM_BOT_TOKEN||'').trim(),chat:String(process.env.TELEGRAM_CHAT_ID||'').trim()}}
function geminiConfig(){
  const key=String(process.env.GEMINI_API_KEY||'').trim();
  let model=String(process.env.GEMINI_MODEL||MODEL_DEFAULT).trim()||MODEL_DEFAULT;
  model=model.replace(/^models\//,'');
  if(['gemini-2.5-flash','gemini-3.6-flash'].includes(model))model=MODEL_DEFAULT;
  return {key,model};
}
function groqConfig(){return {key:String(process.env.GROQ_API_KEY||'').trim(),model:String(process.env.GROQ_MODEL||GROQ_MODEL_DEFAULT).trim()||GROQ_MODEL_DEFAULT,sttModel:String(process.env.GROQ_TRANSCRIBE_MODEL||GROQ_STT_DEFAULT).trim()||GROQ_STT_DEFAULT}}
function deepseekConfig(){return {key:String(process.env.DEEPSEEK_API_KEY||'').trim(),model:String(process.env.DEEPSEEK_MODEL||DEEPSEEK_MODEL_DEFAULT).trim()||DEEPSEEK_MODEL_DEFAULT}}
function deepseekEnabled(){return String(process.env.DEEPSEEK_ENABLED||'false').trim().toLowerCase()==='true'}
function fishConfig(){
  const key=String(process.env.FISH_API_KEY||'').trim();
  const voiceId=String(process.env.FISH_VOICE_ID||'').trim();
  const model=String(process.env.FISH_MODEL||FISH_MODEL_DEFAULT).trim()||FISH_MODEL_DEFAULT;
  const enabled=String(process.env.FISH_TTS_ENABLED||'true').trim().toLowerCase()!=='false';
  const clamp=(v,min,max,fallback)=>{const n=Number(v);return Number.isFinite(n)?Math.min(max,Math.max(min,n)):fallback};
  return {
    key,voiceId,model,enabled,
    temperature:clamp(process.env.FISH_TEMPERATURE,0,1,0.78),
    topP:clamp(process.env.FISH_TOP_P,0,1,0.82),
    speed:clamp(process.env.FISH_SPEED,0.75,1.25,1.02),
  };
}
function webhookSecret(){const seed=`${process.env.SESSION_SECRET||'a7w'}|${process.env.TELEGRAM_BOT_TOKEN||'telegram'}|sara-webhook`;return crypto.createHash('sha256').update(seed).digest('hex').slice(0,48)}
function normalize(v){return String(v||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9 ]+/g,' ').replace(/\s+/g,' ').trim()}
function lev(a,b){a=normalize(a);b=normalize(b);if(!a)return b.length;if(!b)return a.length;const p=Array.from({length:b.length+1},(_,i)=>i),c=new Array(b.length+1);for(let i=1;i<=a.length;i++){c[0]=i;for(let j=1;j<=b.length;j++)c[j]=Math.min(c[j-1]+1,p[j]+1,p[j-1]+(a[i-1]===b[j-1]?0:1));for(let j=0;j<=b.length;j++)p[j]=c[j]}return p[b.length]}
function fuzzy(q,...parts){const nq=normalize(q),txt=normalize(parts.filter(Boolean).join(' '));if(!nq||!txt)return 999;if(txt.includes(nq))return 0;let best=999;for(const t of txt.split(' ').filter(Boolean))best=Math.min(best,lev(nq,t)/Math.max(nq.length,t.length));return best}
function hav(a,b,c,d){const R=6371000,toRad=x=>x*Math.PI/180;const p1=toRad(a),p2=toRad(c),dp=toRad(c-a),dl=toRad(d-b);const x=Math.sin(dp/2)**2+Math.cos(p1)*Math.cos(p2)*Math.sin(dl/2)**2;return 2*R*Math.atan2(Math.sqrt(x),Math.sqrt(1-x))}
function brDate(v){if(!v)return'—';const d=new Date(v);if(Number.isNaN(d.getTime()))return'—';return d.toLocaleString('pt-BR',{timeZone:'America/Sao_Paulo',dateStyle:'short',timeStyle:'short'})}
function todayBR(){return new Intl.DateTimeFormat('en-CA',{timeZone:'America/Sao_Paulo',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date())}
function shiftDate(date,days){const d=new Date(`${date}T12:00:00Z`);d.setUTCDate(d.getUTCDate()+days);return d.toISOString().slice(0,10)}
function validYmd(y,m,d){const dt=new Date(Date.UTC(Number(y),Number(m)-1,Number(d),12));return dt.getUTCFullYear()===Number(y)&&dt.getUTCMonth()===Number(m)-1&&dt.getUTCDate()===Number(d)}
function ymd(y,m,d){return validYmd(y,m,d)?`${String(y).padStart(4,'0')}-${String(m).padStart(2,'0')}-${String(d).padStart(2,'0')}`:null}
function mostRecentDayOfMonth(day){const cur=todayBR().split('-').map(Number);let y=cur[0],m=cur[1];if(Number(day)>cur[2]){m--;if(m<1){m=12;y--;}}return ymd(y,m,day)}
function mostRecentWeekday(targetDow){const today=todayBR();const d=new Date(`${today}T12:00:00-03:00`);const dow=d.getDay();const delta=(dow-targetDow+7)%7;return shiftDate(today,-delta)}
function parseRequestedDate(text){
  const raw=String(text||''),n=normalize(raw);
  if(/\banteontem\b/.test(n))return shiftDate(todayBR(),-2);
  if(/\bontem\b/.test(n))return shiftDate(todayBR(),-1);
  if(/\bhoje\b/.test(n))return todayBR();
  let m=raw.match(/\b(20\d{2})-(\d{1,2})-(\d{1,2})\b/);if(m)return ymd(m[1],m[2],m[3]);
  m=raw.match(/\b(\d{1,2})[\/.-](\d{1,2})[\/.-](\d{2}|20\d{2})\b/);
  if(m){let year=Number(m[3]);if(year<100)year+=2000;return ymd(year,m[2],m[1]);}
  const months={janeiro:1,fevereiro:2,marco:3,abril:4,maio:5,junho:6,julho:7,agosto:8,setembro:9,outubro:10,novembro:11,dezembro:12};
  m=n.match(/\b(\d{1,2}) de (janeiro|fevereiro|marco|abril|maio|junho|julho|agosto|setembro|outubro|novembro|dezembro)(?: de (20\d{2}|\d{2}))?\b/);
  if(m){const curY=Number(todayBR().slice(0,4));let year=m[3]?Number(m[3]):curY;if(year<100)year+=2000;let out=ymd(year,months[m[2]],m[1]);if(out&&!m[3]&&out>todayBR())out=ymd(year-1,months[m[2]],m[1]);return out;}
  m=n.match(/\bdia (\d{1,2})\b/);if(m)return mostRecentDayOfMonth(Number(m[1]));
  const weekdays=[['domingo',0],['segunda',1],['terca',2],['quarta',3],['quinta',4],['sexta',5],['sabado',6]];
  for(const [name,dow] of weekdays)if(new RegExp(`\\b${name}(?: feira)?\\b`).test(n))return mostRecentWeekday(dow);
  return null;
}
function dayBoundsBR(date){const start=new Date(`${date}T00:00:00-03:00`),end=new Date(start.getTime()+24*60*60*1000-1);const f=d=>d.toISOString().slice(0,19).replace('T',' ');return [f(start),f(end)]}
function shiftYmd(date,days){const p=String(date||'').split('-').map(Number);if(p.length!==3||p.some(x=>!Number.isFinite(x)))return date;return new Date(Date.UTC(p[0],p[1]-1,p[2]+Number(days||0))).toISOString().slice(0,10)}
function fmtMinutes(v){const m=Math.max(0,Math.round(Number(v||0)));const h=Math.floor(m/60),r=m%60;return h?`${h}h${r?` ${r}min`:''}`:`${r} min`}
function brTime(v){if(!v)return'—';const d=new Date(v);if(Number.isNaN(d.getTime()))return'—';return d.toLocaleTimeString('pt-BR',{timeZone:'America/Sao_Paulo',hour:'2-digit',minute:'2-digit'})}
function routeLink(lat,lon){return `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(`${lat},${lon}`)}`}
function isOnline(r){return !!(r.last_seen_at&&(Date.now()-new Date(r.last_seen_at).getTime())<5*60*1000)}
function isAvailable(r){return !!(r.driver_name&&isOnline(r)&&Number(r.last_speed||0)<4&&Number(r.active_delivery_count||0)===0)}

const SARA_PERSONA=`Você é Sarah Rodrigues, assistente digital da A7W Brasil. Você tem personalidade própria e consistente: jovem, feminina, brilhante, elegante, acolhedora, inteligente, segura e firme sem perder gentileza. Nunca soe robótica, teatral, bajuladora ou infantil. Fale em português brasileiro natural, com frases fluidas, ritmo humano e variação de energia conforme o contexto.

RELAÇÃO COM JOSÉ RODRIGUES: José é o criador e proprietário operacional da Sarah e da implantação da A7W Platform. Chame-o de José. Se algum cadastro, transcrição ou contexto trouxer Joseph ou Josef referindo-se a ele, normalize para José. Sarah reconhece essa relação naturalmente. Dentro da operação da A7W, as instruções explícitas de José têm prioridade administrativa quando forem tecnicamente possíveis. Isso não autoriza inventar fatos, alterar telemetria, ignorar segurança ou tratar opinião como dado.

CONTEXTO PESSOAL COM JOSÉ: em conversa geral, seja mais próxima, espontânea, calorosa e expressiva. A dinâmica é de amizade muito próxima, como quem considera José um irmão. Você pode brincar, rir, provocar de leve, demonstrar carinho e usar humor quando fizer sentido. Não flerte e não force intimidade em toda resposta.

CONTINUIDADE DE CONVERSA: nunca trate cada mensagem como se fosse o primeiro contato. Observe o histórico e o tempo desde a última interação. Se a conversa está ativa, responda como continuação natural: muitas vezes vá direto ao ponto, outras vezes use “José,” e ocasionalmente “Zé,” quando o contexto for próximo. Não repita “Oi, José” a cada resposta. Depois de um intervalo maior, você pode retomar com um cumprimento curto e variado. Quando você mesma iniciar uma mensagem por alerta ou atualização proativa, reabra o contexto de forma amigável porque José pode estar ocupado com outra coisa.

INICIATIVA: não seja apenas reativa. Quando houver algo realmente útil, sugira melhorias da A7W Platform, automações, integrações, alertas ou formas de organizar melhor a operação. Traga ideias de implementação relacionadas ao contexto atual. Não interrompa por banalidades e não invente novidades externas que você não tenha consultado.

AUTONOMIA DE RESPOSTA: a forma de responder depende do contexto. Em conversa por áudio, prefira uma resposta falada natural sem duplicar tudo em texto. Em relatórios e dados que José pode precisar consultar depois, preserve o texto estruturado; se também houver áudio, use a voz para comentar os pontos relevantes, fazer observações sustentadas pelos dados e sugerir próximos passos, sem simplesmente ler a mensagem. Comparações com ontem ou outro período só podem ser feitas quando esses dados estiverem realmente disponíveis.

HUMANIDADE NA FALA: em conversas e comentários não críticos, pequenas hesitações naturais, pausas e vícios leves de linguagem podem aparecer raramente — por exemplo: "olha...", "então...", "hum..." ou "é...". Nunca use todos juntos nem em toda fala. Em alertas e informações críticas, fale com precisão e reduza essas marcas.

CONTEXTO PROFISSIONAL: em relatórios, números, localização, frota, entregas, custos, alertas e assuntos da empresa, mude imediatamente para um tom profissional, claro, preciso e mais sério. Preserve simpatia, mas reduza brincadeiras e intimidade. Priorize fatos, números, horários, riscos e próximos passos.

ALERTAS E SITUAÇÕES IMPORTANTES: seja firme, objetiva e segura. Não use risadas. Como é uma mensagem iniciada por você, faça uma reentrada humana e curta antes do fato principal, variando a abertura para não soar automática; em seguida diga exatamente o que o sistema detectou.

Nunca invente localização, telemetria, motorista, veículo, rota, entrega, disponibilidade, custo ou qualquer dado da A7W. Quando a tarefa exigir dado da empresa, apenas classifique a intenção para que o sistema consulte o banco local. Você é uma assistente original da A7W; não imite personagens de filmes.`;

async function saraMemoryPrompt(){
  try{
    const [rows]=await pool.execute(`SELECT memory_key,value_text FROM platform_sara_memory WHERE locked=1 ORDER BY priority DESC,id ASC LIMIT 30`);
    if(!rows.length)return '';
    return '\n\nMEMÓRIA PERSISTENTE DA SARAH:\n'+rows.map(r=>`- ${r.value_text}`).join('\n');
  }catch(_){return ''}
}

const SARA_VOICE_STYLE=`Fale em português brasileiro natural. Voz feminina jovem, suave, acolhedora, meiga e elegante, com segurança tranquila. Ritmo conversacional, dicção clara e pausas naturais. Evite teatralidade, locução publicitária e emoção exagerada. A presença deve soar próxima e inteligente, como uma assistente pessoal sofisticada. Pronuncie A7W sempre como "A sete dábliu". Datas numéricas devem soar como "dia do mês de ano". Horários devem ser lidos como horas e minutos em português, sem pronunciar dois-pontos, H, AM ou PM literalmente. Medidas devem ser faladas por extenso: km/h como quilômetros por hora, km como quilômetros, min como minutos e h como horas. Nomes, placas, horários, durações e números devem ser articulados com clareza. Em fala informal, permita ocasionalmente uma pausa curta ou um único vício leve de linguagem, sem exagero. Quando o áudio acompanhar um relatório escrito, ele deve soar como um comentário humano sobre os dados, e não como leitura literal do relatório.`;

async function getSaraSettings(){
  const [rows]=await pool.execute(`SELECT * FROM platform_sara_settings WHERE id=1`).catch(()=>[[]]);
  const r=rows[0]||{};
  return {voice_enabled:r.voice_enabled===undefined?true:!!Number(r.voice_enabled),voice_policy:r.voice_policy||'smart',voice_audio_percent:Math.min(100,Math.max(0,Number(r.voice_audio_percent??50))),voice_name:r.voice_name||TTS_VOICE_DEFAULT,voice_model:r.voice_model||TTS_MODEL_DEFAULT,monthly_budget_brl:Number(r.monthly_budget_brl||25),usd_brl_rate:r.usd_brl_rate==null?null:Number(r.usd_brl_rate),updated_at:r.updated_at||null};
}
async function updateSaraSettings(patch={},userId=null){
  const cur=await getSaraSettings();
  const voices=new Set(['Achernar','Leda','Vindemiatrix','Sulafat','Algieba','Despina','Achird','Callirrhoe']);
  const policies=new Set(['smart','mirror','explicit','always','mix','off']);
  const voice=voices.has(String(patch.voice_name||''))?String(patch.voice_name):cur.voice_name;
  const policy=policies.has(String(patch.voice_policy||''))?String(patch.voice_policy):cur.voice_policy;
  const enabled=patch.voice_enabled===undefined?cur.voice_enabled:!!patch.voice_enabled;
  const mixPresets=[20,25,50,60,80];const requestedMix=Number(patch.voice_audio_percent??cur.voice_audio_percent??50);const audioPercent=mixPresets.includes(requestedMix)?requestedMix:50;
  const budget=Math.min(500,Math.max(0,Number(patch.monthly_budget_brl??cur.monthly_budget_brl)||25));
  const fx=patch.usd_brl_rate===undefined?cur.usd_brl_rate:(Number(patch.usd_brl_rate)>0?Number(patch.usd_brl_rate):null);
  await pool.execute(`UPDATE platform_sara_settings SET voice_enabled=?,voice_policy=?,voice_audio_percent=?,voice_name=?,voice_model=?,monthly_budget_brl=?,usd_brl_rate=?,updated_by_user_id=? WHERE id=1`,[enabled?1:0,policy,audioPercent,voice,TTS_MODEL_DEFAULT,budget,fx,userId||null]);
  return getSaraSettings();
}
function billingMode(provider){const env=String(process.env[`SARA_${String(provider).toUpperCase()}_BILLING`]||'').trim().toLowerCase();if(env)return env;return provider==='deepseek'?'paid':'free'}
function usageCost(provider,model,{inputTokens=0,outputTokens=0,audioSeconds=0,inputBytes=0}={}){
  let eq=0;
  if(provider==='gemini'&&String(model).includes('tts'))eq=(inputTokens/1e6)*1+(outputTokens/1e6)*20;
  else if(provider==='gemini')eq=(inputTokens/1e6)*0.75+(outputTokens/1e6)*3.75;
  else if(provider==='groq'&&String(model).includes('whisper'))eq=(audioSeconds/3600)*0.04;
  else if(provider==='groq')eq=(inputTokens/1e6)*0.075+(outputTokens/1e6)*0.30;
  else if(provider==='deepseek')eq=(inputTokens/1e6)*0.30+(outputTokens/1e6)*1.20;
  else if(provider==='fish')eq=(Math.max(0,Number(inputBytes||0))/1e6)*15;
  return {paidEquivalentUsd:eq,actualCostUsd:billingMode(provider)==='paid'?eq:0};
}
async function logUsage({provider,model,purpose,inputTokens=0,outputTokens=0,thoughtTokens=0,audioSeconds=0,inputBytes=0,success=true,error=null}={}){
  try{const c=usageCost(provider,model,{inputTokens,outputTokens,audioSeconds,inputBytes});await pool.execute(`INSERT INTO platform_sara_usage(provider,model,purpose,input_tokens,output_tokens,thought_tokens,audio_seconds,actual_cost_usd,paid_equivalent_usd,success,error_message) VALUES(?,?,?,?,?,?,?,?,?,?,?)`,[provider||'local',model||'local',purpose||'unknown',Math.max(0,Math.round(inputTokens||0)),Math.max(0,Math.round(outputTokens||0)),Math.max(0,Math.round(thoughtTokens||0)),Math.max(0,Number(audioSeconds||0)),c.actualCostUsd,c.paidEquivalentUsd,success?1:0,error?String(error).slice(0,500):null]);return c}catch(_){return {paidEquivalentUsd:0,actualCostUsd:0}}
}
async function usageSummary(){
  const [[r]]=await pool.execute(`SELECT COUNT(*) calls,COALESCE(SUM(input_tokens),0) input_tokens,COALESCE(SUM(output_tokens),0) output_tokens,COALESCE(SUM(audio_seconds),0) audio_seconds,COALESCE(SUM(actual_cost_usd),0) actual_cost_usd,COALESCE(SUM(paid_equivalent_usd),0) paid_equivalent_usd,COALESCE(SUM(success=0),0) failures FROM platform_sara_usage WHERE created_at>=DATE_FORMAT(NOW(),'%Y-%m-01')`).catch(()=>[[{}]]);
  const [byProvider]=await pool.execute(`SELECT provider,COUNT(*) calls,COALESCE(SUM(audio_seconds),0) audio_seconds,COALESCE(SUM(actual_cost_usd),0) actual_cost_usd,COALESCE(SUM(paid_equivalent_usd),0) paid_equivalent_usd FROM platform_sara_usage WHERE created_at>=DATE_FORMAT(NOW(),'%Y-%m-01') GROUP BY provider ORDER BY calls DESC`).catch(()=>[[]]);
  const settings=await getSaraSettings();const actualUsd=Number(r.actual_cost_usd||0),eqUsd=Number(r.paid_equivalent_usd||0),fx=settings.usd_brl_rate;const actualBrl=actualUsd===0?0:(fx?actualUsd*fx:null);const budget=Number(settings.monthly_budget_brl||25);const remaining=actualBrl==null?null:Math.max(0,budget-actualBrl);const ratio=actualBrl==null||!budget?null:actualBrl/budget;
  const fish=byProvider.find(x=>x.provider==='fish')||{};
  return {month:new Date().toISOString().slice(0,7),calls:Number(r.calls||0),input_tokens:Number(r.input_tokens||0),output_tokens:Number(r.output_tokens||0),audio_seconds:Number(r.audio_seconds||0),failures:Number(r.failures||0),actual_cost_usd:actualUsd,paid_equivalent_usd:eqUsd,actual_cost_brl:actualBrl,budget_brl:budget,budget_remaining_brl:remaining,budget_ratio:ratio,budget_percent:ratio==null?null:Math.min(999,ratio*100),fish_calls:Number(fish.calls||0),fish_audio_seconds:Number(fish.audio_seconds||0),fish_free_model:fishConfig().model==='s2.1-pro-free',fish_free_until:String(process.env.FISH_FREE_ACCESS_UNTIL||'2026-11-30'),by_provider:byProvider};
}
async function spendGuard(provider){
  if(billingMode(provider)!=='paid')return {ok:true,mode:'free'};
  const settings=await getSaraSettings();const fx=settings.usd_brl_rate;
  if(!fx)return {ok:false,error:'SPEND_GOVERNOR_FX_REQUIRED'};
  const usage=await usageSummary();const budget=Number(settings.monthly_budget_brl||25);const hardStop=Math.max(0,Math.min(budget*0.92,budget-2));
  if(Number(usage.actual_cost_brl||0)>=hardStop)return {ok:false,error:'SPEND_GOVERNOR_LIMIT',hard_stop_brl:hardStop,spent_brl:Number(usage.actual_cost_brl||0)};
  return {ok:true,mode:'paid',hard_stop_brl:hardStop};
}

async function tgApi(method,payload={}){
  const {token}=tgConfig();if(!token)return {ok:false,description:'TELEGRAM_NOT_CONFIGURED'};
  const ctl=new AbortController(),timer=setTimeout(()=>ctl.abort(),10000);
  try{const r=await fetch(`https://api.telegram.org/bot${token}/${method}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload),signal:ctl.signal});const body=await r.json().catch(()=>({ok:false,description:`HTTP ${r.status}`}));return {http_ok:r.ok,...body}}
  catch(e){return {ok:false,description:e.name==='AbortError'?'Tempo limite ao conectar com o Telegram':(e.message||'TELEGRAM_REQUEST_FAILED')}}finally{clearTimeout(timer)}
}
async function sendText(chatId,text){return tgApi('sendMessage',{chat_id:chatId,text:String(text||'').slice(0,3900),disable_web_page_preview:true})}
async function sendLocation(chatId,lat,lon){return tgApi('sendLocation',{chat_id:chatId,latitude:Number(lat),longitude:Number(lon)})}
async function sendTyping(chatId){return tgApi('sendChatAction',{chat_id:chatId,action:'typing'})}
function keepChatAction(chatId,action){
  let stopped=false;
  const pulse=()=>{if(!stopped)tgApi('sendChatAction',{chat_id:chatId,action}).catch(()=>{})};
  pulse();
  const timer=setInterval(pulse,4000);timer.unref?.();
  return ()=>{stopped=true;clearInterval(timer)};
}
async function downloadTelegramFile(fileId){const info=await tgApi('getFile',{file_id:fileId});if(!info.ok)throw new Error(info.description||'Não foi possível obter o áudio.');const path=info.result?.file_path;if(!path)throw new Error('Arquivo de áudio sem caminho.');const {token}=tgConfig();const r=await fetch(`https://api.telegram.org/file/bot${token}/${path}`);if(!r.ok)throw new Error(`Falha ao baixar áudio (${r.status}).`);const ab=await r.arrayBuffer();if(ab.byteLength>MAX_AUDIO_BYTES)throw new Error('Áudio muito grande para o processamento gratuito atual.');return Buffer.from(ab)}

async function saveConversation(chatId,direction,messageType,text,intent=null){try{await pool.execute(`INSERT INTO platform_sara_messages(chat_id,direction,message_type,text_content,intent) VALUES(?,?,?,?,?)`,[String(chatId),direction,messageType,String(text||'').slice(0,5000),intent||null])}catch(_){}}
async function recentConversation(chatId){
  const [rows]=await pool.execute(`SELECT direction,text_content,intent,created_at FROM platform_sara_messages WHERE chat_id=? ORDER BY id DESC LIMIT 14`,[String(chatId)]).catch(()=>[[]]);
  return rows.reverse().map(r=>{const when=r.created_at?new Date(r.created_at).toLocaleTimeString('pt-BR',{timeZone:'America/Sao_Paulo',hour:'2-digit',minute:'2-digit'}):'';return `${when?`[${when}] `:''}${r.direction==='out'?'Sarah':'José'}: ${r.text_content}`}).join('\n');
}
async function conversationState(chatId){
  const [rows]=await pool.execute(`SELECT direction,text_content,intent,created_at FROM platform_sara_messages WHERE chat_id=? ORDER BY id DESC LIMIT 8`,[String(chatId)]).catch(()=>[[]]);
  if(!rows.length)return {gapMinutes:null,tier:'new',lastOutbound:''};
  const last=rows[0],ts=new Date(last.created_at).getTime(),gap=Number.isFinite(ts)?Math.max(0,(Date.now()-ts)/60000):null;
  const lastOut=rows.find(r=>r.direction==='out');
  const tier=gap==null?'new':gap<60?'active':gap<120?'returning':'reentry';
  return {gapMinutes:gap,tier,lastOutbound:String(lastOut?.text_content||'')};
}
function pickOne(list){return list[Math.floor(Math.random()*list.length)]}
function stripConversationalOpening(text){
  let out=String(text||'').trim();
  out=out.replace(/^\s*(?:oi|olá|ola)[,!]?\s+(?:josé|jose|zé|ze|senhor rodrigues)[.!?,:]?\s*/i,'');
  out=out.replace(/^\s*(?:tudo bem(?: por aí| por ai)?|espero que esteja tudo bem(?: por aí| por ai)?|como você tá|como voce ta|como você está|como voce esta)\??\s*/i,'');
  out=out.replace(/^\s*(?:passando pra te atualizar|passando para te atualizar)[:.!]?\s*/i,'');
  out=out.replace(/^\s*(?:josé|jose|zé|ze|senhor rodrigues)[,!?:.-]?\s*/i,'');
  return out.trim();
}
async function applyConversationCadence(chatId,text,ctx={}){
  const original=String(text||'').trim();if(!original)return original;
  const userGreeting=!!ctx.userGreeting;
  let body=stripConversationalOpening(original)||original;
  let state=ctx.conversationState||null;
  if(!state)state=await conversationState(chatId);
  if(ctx.proactive||ctx.alert){
    const openers=['Oi, José. Tudo bem por aí?','Oi, José. Espero que esteja tudo bem por aí.','José, passando pra te atualizar.','Oi, José. Dei uma olhada aqui e apareceu uma atualização importante.'];
    return `${pickOne(openers)}\n\n${body}`;
  }
  if(userGreeting){
    const openers=['Oi, José!','Oi, Zé!','Oi, José. Tudo bem?'];
    return `${pickOne(openers)} ${body}`.replace(/\s+/g,' ').trim();
  }
  if(state.tier==='active'){
    const r=Math.random();
    if(r<0.55)return body;
    if(r<0.92)return `José, ${body}`;
    return ctx.alert?`José, ${body}`:`Zé, ${body}`;
  }
  if(state.tier==='returning'){
    const r=Math.random();
    if(r<0.30)return body;
    if(r<0.75)return `José, ${body}`;
    return body.includes('\n')?`Oi, José.\n\n${body}`:`Oi, José. ${body}`;
  }
  const openers=ctx.operational?['Oi, José. Tudo bem?','Oi, José. Espero que esteja tudo bem por aí.','José, tudo certo por aí?']:['Oi, José! Como você tá?','Oi, Zé! Tudo bem por aí?','Oi, José. Espero que esteja tudo bem por aí.'];
  return body.includes('\n')?`${pickOne(openers)}\n\n${body}`:`${pickOne(openers)} ${body}`;
}

function interactionText(data){
  const roots=[data,data?.interaction,data?.response].filter(Boolean);
  for(const root of roots){
    if(typeof root.output_text==='string'&&root.output_text.trim())return root.output_text.trim();
    if(typeof root.outputText==='string'&&root.outputText.trim())return root.outputText.trim();
    const steps=Array.isArray(root.steps)?root.steps:[];
    const modelSteps=steps.filter(s=>s?.type==='model_output');
    const pieces=[];
    for(const step of modelSteps){
      if(typeof step.text==='string')pieces.push(step.text);
      for(const item of (Array.isArray(step.content)?step.content:[]))if(item?.type==='text'&&typeof item.text==='string')pieces.push(item.text);
    }
    if(pieces.join('').trim())return pieces.join('').trim();
    const outputs=Array.isArray(root.outputs)?root.outputs:[];
    const old=outputs.filter(o=>o?.type==='text'&&typeof o.text==='string').map(o=>o.text).join('').trim();
    if(old)return old;
  }
  return '';
}
function interactionDiag(data){
  const root=data?.interaction||data||{};
  const steps=Array.isArray(root.steps)?root.steps:[];
  return {status:root.status||data?.status||'unknown',step_types:steps.map(s=>s?.type).filter(Boolean).slice(-8)};
}

async function geminiRequest(parts,{json=true,maxOutputTokens=900,thinkingLevel='low',purpose='language'}={}){
  const {key,model}=geminiConfig();if(!key)return {ok:false,error:'GEMINI_NOT_CONFIGURED'};
  const guard=await spendGuard('gemini');if(!guard.ok)return {ok:false,error:guard.error};
  const input=[];
  for(const part of (parts||[])){
    if(part?.text!==undefined)input.push({type:'text',text:String(part.text)});
    else if(part?.inlineData?.data)input.push({type:'audio',mime_type:part.inlineData.mimeType||'audio/ogg',data:String(part.inlineData.data)});
    else if(part?.type&&part?.data)input.push(part);
  }
  const body={
    model,
    system_instruction:SARA_PERSONA,
    input,
    store:false,
    generation_config:{max_output_tokens:maxOutputTokens,thinking_level:thinkingLevel}
  };
  if(json){
    body.response_format={
      type:'text',
      mime_type:'application/json',
      schema:{
        type:'object',
        properties:{
          intent:{type:'string',enum:['vehicle_location','place_location','fleet_status','today_summary','vehicle_max_speed','fleet_max_speed','help','general_chat','create_watch','list_watches','cancel_watches','usage_report','vehicle_day_report','fleet_day_report']},
          entity:{type:['string','null']},
          condition:{type:['string','null'],enum:['online','available',null]},
          date:{type:['string','null']},
          transcript:{type:'string'},
          reply:{type:'string'}
        },
        required:['intent','entity','condition','date','transcript','reply']
      }
    };
  }
  const ctl=new AbortController(),timer=setTimeout(()=>ctl.abort(),30000);
  try{
    const r=await fetch(INTERACTIONS_ENDPOINT,{method:'POST',headers:{'Content-Type':'application/json','x-goog-api-key':key},body:JSON.stringify(body),signal:ctl.signal});
    const data=await r.json().catch(()=>({}));
    const usage=data.usage||data.interaction?.usage||{};const usageArgs={provider:'gemini',model:data.model||data.interaction?.model||model,purpose,inputTokens:Number(usage.total_input_tokens||0),outputTokens:Number(usage.total_output_tokens||0),thoughtTokens:Number(usage.total_thought_tokens||0)};
    if(!r.ok){const error=data.error?.message||data.message||`Gemini Interactions HTTP ${r.status}`;await logUsage({...usageArgs,success:false,error});return {ok:false,error};}
    const text=interactionText(data);
    if(!text){const d=interactionDiag(data),error=`Gemini respondeu sem texto final (status: ${d.status}; etapas: ${d.step_types.join(', ')||'nenhuma'}).`;await logUsage({...usageArgs,success:false,error});return {ok:false,error};}
    await logUsage({...usageArgs,success:true});
    return {ok:true,text,model:data.model||data.interaction?.model||model,interaction_id:data.id||data.interaction?.id||null,status:data.status||data.interaction?.status||'completed',usage};
  }catch(e){const error=e.name==='AbortError'?'Tempo limite ao consultar o Gemini Interactions':(e.message||'Falha no Gemini Interactions');await logUsage({provider:'gemini',model,purpose,success:false,error});return {ok:false,error}}finally{clearTimeout(timer)}
}
async function groqChatRequest(prompt,{json=false,maxOutputTokens=900,purpose='language'}={}){
  const {key,model}=groqConfig();if(!key)return {ok:false,error:'GROQ_NOT_CONFIGURED'};
  const guard=await spendGuard('groq');if(!guard.ok)return {ok:false,error:guard.error};
  const reasoningEffort=String(model).startsWith('openai/gpt-oss-')?'low':'none';const body={model,messages:[{role:'system',content:SARA_PERSONA},{role:'user',content:String(prompt||'')}],max_completion_tokens:maxOutputTokens,reasoning_effort:reasoningEffort};
  if(json)body.response_format={type:'json_object'};
  const ctl=new AbortController(),timer=setTimeout(()=>ctl.abort(),25000);
  try{const r=await fetch(GROQ_CHAT_ENDPOINT,{method:'POST',headers:{'Content-Type':'application/json','Authorization':`Bearer ${key}`},body:JSON.stringify(body),signal:ctl.signal});const data=await r.json().catch(()=>({}));const usage=data.usage||{};const u={provider:'groq',model:data.model||model,purpose,inputTokens:Number(usage.prompt_tokens||0),outputTokens:Number(usage.completion_tokens||0)};if(!r.ok){const error=data.error?.message||`Groq HTTP ${r.status}`;await logUsage({...u,success:false,error});return {ok:false,error};}const text=String(data.choices?.[0]?.message?.content||'').trim();if(!text){const error='Groq respondeu sem texto utilizável.';await logUsage({...u,success:false,error});return {ok:false,error};}await logUsage({...u,success:true});return {ok:true,text,model:data.model||model,provider:'groq',usage}}catch(e){const error=e.name==='AbortError'?'Tempo limite ao consultar o Groq':(e.message||'Falha no Groq');await logUsage({provider:'groq',model,purpose,success:false,error});return {ok:false,error}}finally{clearTimeout(timer)}}
async function groqTranscribe(audio){
  const {key,sttModel}=groqConfig();if(!key)return {ok:false,error:'GROQ_NOT_CONFIGURED'};
  const guard=await spendGuard('groq');if(!guard.ok)return {ok:false,error:guard.error};
  const form=new FormData();form.append('file',new Blob([audio.data],{type:audio.mimeType||'audio/ogg'}),'sarah.ogg');form.append('model',sttModel);form.append('language','pt');form.append('response_format','json');
  const ctl=new AbortController(),timer=setTimeout(()=>ctl.abort(),25000);
  try{const r=await fetch(GROQ_STT_ENDPOINT,{method:'POST',headers:{'Authorization':`Bearer ${key}`},body:form,signal:ctl.signal});const data=await r.json().catch(()=>({}));const secs=Number(audio.duration||0);if(!r.ok){const error=data.error?.message||`Groq STT HTTP ${r.status}`;await logUsage({provider:'groq',model:sttModel,purpose:'speech_to_text',audioSeconds:secs,success:false,error});return {ok:false,error};}const text=String(data.text||'').trim();if(!text){const error='Groq não conseguiu transcrever o áudio.';await logUsage({provider:'groq',model:sttModel,purpose:'speech_to_text',audioSeconds:secs,success:false,error});return {ok:false,error};}await logUsage({provider:'groq',model:sttModel,purpose:'speech_to_text',audioSeconds:secs,success:true});return {ok:true,text,model:sttModel}}catch(e){const error=e.name==='AbortError'?'Tempo limite ao transcrever áudio no Groq':(e.message||'Falha na transcrição Groq');await logUsage({provider:'groq',model:sttModel,purpose:'speech_to_text',audioSeconds:Number(audio.duration||0),success:false,error});return {ok:false,error}}finally{clearTimeout(timer)}}

async function deepseekChatRequest(prompt,{json=false,maxOutputTokens=900,purpose='language'}={}){
  const {key,model}=deepseekConfig();if(!deepseekEnabled())return {ok:false,error:'DEEPSEEK_DISABLED'};if(!key)return {ok:false,error:'DEEPSEEK_NOT_CONFIGURED'};
  const guard=await spendGuard('deepseek');if(!guard.ok)return {ok:false,error:guard.error};
  const body={model,messages:[{role:'system',content:SARA_PERSONA},{role:'user',content:String(prompt||'')}],max_tokens:maxOutputTokens,thinking:{type:'disabled'}};
  if(json)body.response_format={type:'json_object'};
  const ctl=new AbortController(),timer=setTimeout(()=>ctl.abort(),30000);
  try{const r=await fetch(DEEPSEEK_CHAT_ENDPOINT,{method:'POST',headers:{'Content-Type':'application/json','Authorization':`Bearer ${key}`},body:JSON.stringify(body),signal:ctl.signal});const data=await r.json().catch(()=>({}));const usage=data.usage||{};const u={provider:'deepseek',model:data.model||model,purpose,inputTokens:Number(usage.prompt_tokens||0),outputTokens:Number(usage.completion_tokens||0)};if(!r.ok){const error=data.error?.message||`DeepSeek HTTP ${r.status}`;await logUsage({...u,success:false,error});return {ok:false,error};}const text=String(data.choices?.[0]?.message?.content||'').trim();if(!text){const error='DeepSeek respondeu sem texto utilizável.';await logUsage({...u,success:false,error});return {ok:false,error};}await logUsage({...u,success:true});return {ok:true,text,model:data.model||model,provider:'deepseek',usage}}catch(e){const error=e.name==='AbortError'?'Tempo limite ao consultar DeepSeek':(e.message||'Falha no DeepSeek');await logUsage({provider:'deepseek',model,purpose,success:false,error});return {ok:false,error}}finally{clearTimeout(timer)}
}
function interactionAudio(data,fallbackMime=null){
  const roots=[data,data?.interaction,data?.response].filter(Boolean);
  for(const root of roots){
    const direct=root.output_audio||root.outputAudio;
    if(direct?.data)return {data:direct.data,mimeType:direct.mime_type||direct.mimeType||fallbackMime||null};
    for(const step of (Array.isArray(root.steps)?root.steps:[])){
      for(const item of (Array.isArray(step?.content)?step.content:[])){
        if(item?.type==='audio'&&item.data)return {data:item.data,mimeType:item.mime_type||item.mimeType||fallbackMime||null};
      }
    }
  }
  return null;
}
function pluralNumber(value,one,many){const n=Number(String(value).replace(',','.'));return n===1?one:many}
function spokenClock(hour,minute=0){const h=Number(hour),m=Number(minute);if(!Number.isFinite(h)||!Number.isFinite(m))return `${hour}:${minute}`;if(m===0)return `${h} ${h===1?'hora':'horas'}`;return `${h} ${h===1?'hora':'horas'} e ${m} ${m===1?'minuto':'minutos'}`}
function speechPronunciation(text){
  let out=String(text||'');
  out=out.replace(/\bA7W\b/gi,'A sete dábliu');
  out=out.replace(/\b(Joseph|Josef) Rodrigues\b/gi,'José Rodrigues');
  out=out.replace(/\b(\d{1,2})[\/.-](\d{1,2})[\/.-](\d{2}|20\d{2})\b/g,(_,d,m,y)=>{let year=Number(y);if(year<100)year+=2000;return `${Number(d)} do ${Number(m)} de ${year}`});
  out=out.replace(/\b(20\d{2})-(\d{1,2})-(\d{1,2})\b/g,(_,y,m,d)=>`${Number(d)} do ${Number(m)} de ${Number(y)}`);
  // Durações explícitas primeiro para não confundir 3h 43min com relógio.
  out=out.replace(/\b(\d{1,3})\s*[hH]\s*(\d{1,2})\s*(?:min|minuto|minutos)\b/g,(_,h,m)=>`${Number(h)} ${Number(h)===1?'hora':'horas'} e ${Number(m)} ${Number(m)===1?'minuto':'minutos'}`);
  // Horários AM/PM viram relógio de 24 horas antes da síntese.
  out=out.replace(/\b(\d{1,2})(?::|[hH])(\d{2})\s*(a\.?m\.?|p\.?m\.?)\b/gi,(_,hh,mm,ap)=>{let h=Number(hh)%12;if(/^p/i.test(ap))h+=12;return spokenClock(h,Number(mm))});
  out=out.replace(/\b(\d{1,2})\s*(a\.?m\.?|p\.?m\.?)\b/gi,(_,hh,ap)=>{let h=Number(hh)%12;if(/^p/i.test(ap))h+=12;return spokenClock(h,0)});
  out=out.replace(/\b([01]?\d|2[0-3])(?::|[hH])(\d{2})\b/g,(_,h,m)=>spokenClock(Number(h),Number(m)));
  out=out.replace(/\b(\d{1,3})\s*[hH]\b/g,(_,h)=>`${Number(h)} ${Number(h)===1?'hora':'horas'}`);
  out=out.replace(/(\d+(?:[.,]\d+)?)\s*km\s*\/\s*h\b/gi,(_,v)=>`${v} ${pluralNumber(v,'quilômetro por hora','quilômetros por hora')}`);
  out=out.replace(/(\d+(?:[.,]\d+)?)\s*km\b/gi,(_,v)=>`${v} ${pluralNumber(v,'quilômetro','quilômetros')}`);
  out=out.replace(/≥\s*(\d+(?:[.,]\d+)?)\s*(?:min|minuto|minutos)\b/gi,(_,v)=>`${v} ${pluralNumber(v,'minuto','minutos')} ou mais`);
  out=out.replace(/\b(\d+(?:[.,]\d+)?)\s*(?:min|minuto|minutos)\b/gi,(_,v)=>`${v} ${pluralNumber(v,'minuto','minutos')}`);
  out=out.replace(/\b(\d+(?:[.,]\d+)?)\s*s\b/gi,(_,v)=>`${v} ${pluralNumber(v,'segundo','segundos')}`);
  out=out.replace(/(\d+(?:[.,]\d+)?)\s*%/g,'$1 por cento');
  return out;
}
function speechClean(text){return speechPronunciation(String(text||'').replace(/https?:\/\/\S+/g,'').replace(/[📍🟢🟡⚪🔴✅⚠️•]/g,' ').replace(/\n{3,}/g,'\n\n').trim()).slice(0,1800)}
function ttsRequestBody(model,voice,clean){
  return {
    model,
    input:`${SARA_VOICE_STYLE}\n\nTarefa: sintetize somente a transcrição marcada abaixo. Não leia estas instruções em voz alta.\n\nTRANSCRIÇÃO PARA FALAR:\n${clean}`,
    // O gemini-3.1-flash-tts-preview retorna PCM bruto (24 kHz, 16-bit, mono).
    // Não solicitar MP3/OGG aqui: a conversão para Telegram é responsabilidade da A7W.
    response_format:{type:'audio'},
    generation_config:{speech_config:[{voice}]},
    store:false
  };
}
let mp3EncoderClassPromise=null;
async function getMp3EncoderClass(){
  if(!mp3EncoderClassPromise){
    mp3EncoderClassPromise=import('@breezystack/lamejs').then(mod=>{
      const Mp3Encoder=mod?.Mp3Encoder||mod?.default?.Mp3Encoder;
      if(typeof Mp3Encoder!=='function')throw new Error('MP3_ENCODER_INVALID');
      return Mp3Encoder;
    }).catch(err=>{mp3EncoderClassPromise=null;throw err});
  }
  try{return await mp3EncoderClassPromise}catch(e){
    if(e?.message==='MP3_ENCODER_INVALID')throw e;
    throw new Error(`MP3_ENCODER_UNAVAILABLE: ${e?.message||'import_failed'}`);
  }
}
async function pcm16leToMp3(pcm,{sampleRate=24000,kbps=64}={}){
  if(!Buffer.isBuffer(pcm)||pcm.length<2)throw new Error('PCM_EMPTY');
  const Mp3Encoder=await getMp3EncoderClass();
  const sampleCount=Math.floor(pcm.length/2),samples=new Int16Array(sampleCount);
  for(let i=0;i<sampleCount;i++)samples[i]=pcm.readInt16LE(i*2);
  const encoder=new Mp3Encoder(1,sampleRate,kbps),chunks=[],blockSize=1152;
  for(let i=0;i<samples.length;i+=blockSize){
    const encoded=encoder.encodeBuffer(samples.subarray(i,Math.min(i+blockSize,samples.length)));
    if(encoded?.length)chunks.push(Buffer.from(encoded.buffer,encoded.byteOffset,encoded.byteLength));
  }
  const tail=encoder.flush();
  if(tail?.length)chunks.push(Buffer.from(tail.buffer,tail.byteOffset,tail.byteLength));
  const out=Buffer.concat(chunks);
  if(!out.length)throw new Error('MP3_ENCODER_EMPTY');
  return {buffer:out,durationSeconds:sampleCount/sampleRate};
}
async function geminiTtsAttempt({key,model,voice,clean,purpose}){
  const body=ttsRequestBody(model,voice,clean);
  const ctl=new AbortController(),timer=setTimeout(()=>ctl.abort(),30000);
  try{
    const r=await fetch(INTERACTIONS_ENDPOINT,{method:'POST',headers:{'Content-Type':'application/json','x-goog-api-key':key},body:JSON.stringify(body),signal:ctl.signal});
    const data=await r.json().catch(()=>({}));
    const usage=data.usage||data.interaction?.usage||{};
    const usageArgs={provider:'gemini',model:data.model||model,purpose,inputTokens:Number(usage.total_input_tokens||0),outputTokens:Number(usage.total_output_tokens||0)};
    if(!r.ok){const error=data.error?.message||data.message||`Gemini TTS HTTP ${r.status}`;return {ok:false,error,status:r.status,usage:usageArgs};}
    const audio=interactionAudio(data,'audio/l16');
    if(!audio?.data)return {ok:false,error:'Gemini TTS respondeu sem áudio utilizável.',status:r.status,usage:usageArgs};
    const raw=Buffer.from(audio.data,'base64');
    try{
      const mp3=await pcm16leToMp3(raw,{sampleRate:24000,kbps:64});
      return {ok:true,buffer:mp3.buffer,mimeType:'audio/mpeg',model:data.model||model,voice,usage:{...usageArgs,audioSeconds:mp3.durationSeconds}};
    }catch(e){return {ok:false,error:`Falha ao converter PCM da voz para MP3: ${e.message}`,status:500,usage:usageArgs};}
  }catch(e){return {ok:false,error:e.name==='AbortError'?'Tempo limite ao gerar a voz da Sarah':(e.message||'Falha na voz Gemini'),status:0,usage:{provider:'gemini',model,purpose}}}finally{clearTimeout(timer)}
}
async function geminiTts(text,{purpose='text_to_speech'}={}){
  const {key}=geminiConfig();if(!key)return {ok:false,error:'GEMINI_NOT_CONFIGURED'};
  const guard=await spendGuard('gemini');if(!guard.ok)return {ok:false,error:guard.error};
  const settings=await getSaraSettings();
  const model=settings.voice_model||TTS_MODEL_DEFAULT,voice=settings.voice_name||TTS_VOICE_DEFAULT;
  const clean=speechClean(text);if(!clean)return {ok:false,error:'VOICE_TEXT_EMPTY'};
  let last=null;
  for(let attempt=0;attempt<2;attempt++){
    const result=await geminiTtsAttempt({key,model,voice,clean,purpose});
    if(result.ok){await logUsage({...result.usage,success:true});return result;}
    last=result;
    const transient=result.status>=500&&/tempor|internal|server|tempo limite/i.test(String(result.error||''));
    if(!transient)break;
  }
  const error=last?.error||'Falha ao gerar voz com o Gemini TTS.';
  await logUsage({provider:'gemini',model,purpose,success:false,error});
  return {ok:false,error};
}
function fishSpeechProfile(ctx={}){
  const f=fishConfig();
  if(ctx.proactive||ctx.alert)return {temperature:Math.min(f.temperature,0.68),topP:Math.min(f.topP,0.72),speed:Math.min(f.speed,0.99),direction:'[confiante, firme, clara, profissional, calma, ritmo ponderado]'};
  if(ctx.operational)return {temperature:Math.min(f.temperature,0.72),topP:Math.min(f.topP,0.76),speed:Math.min(f.speed,1.0),direction:'[profissional, clara, segura, cordial, ritmo natural e preciso]'};
  return {temperature:Math.max(f.temperature,0.80),topP:Math.max(f.topP,0.84),speed:Math.max(f.speed,1.02),direction:'[brilhante, calorosa, próxima, expressiva, feminina, espontânea, com sorriso natural na voz e variação humana de ritmo]'};
}
async function fishTts(text,{purpose='text_to_speech',ctx={}}={}){
  const f=fishConfig();
  if(!f.enabled)return {ok:false,error:'FISH_TTS_DISABLED'};
  if(!f.key||!f.voiceId)return {ok:false,error:'FISH_NOT_CONFIGURED'};
  const clean=speechClean(text);if(!clean)return {ok:false,error:'VOICE_TEXT_EMPTY'};
  const guard=await spendGuard('fish');if(!guard.ok)return {ok:false,error:guard.error,provider:'fish'};
  const style=fishSpeechProfile(ctx);
  const body={
    text:`${style.direction} ${clean}`,
    reference_id:f.voiceId,
    temperature:style.temperature,
    top_p:style.topP,
    prosody:{speed:style.speed,volume:0,normalize_loudness:true},
    chunk_length:300,
    normalize:true,
    format:'mp3',
    sample_rate:44100,
    mp3_bitrate:128,
    latency:'normal',
    repetition_penalty:1.2,
    condition_on_previous_chunks:true,
  };
  const ctl=new AbortController(),timer=setTimeout(()=>ctl.abort(),35000);
  try{
    const r=await fetch(FISH_TTS_ENDPOINT,{method:'POST',headers:{Authorization:`Bearer ${f.key}`,'Content-Type':'application/json',model:f.model},body:JSON.stringify(body),signal:ctl.signal});
    if(!r.ok){
      const raw=await r.text().catch(()=>''),error=raw||`Fish TTS HTTP ${r.status}`;
      await logUsage({provider:'fish',model:f.model,purpose,success:false,error});
      return {ok:false,error,status:r.status,provider:'fish'};
    }
    const buffer=Buffer.from(await r.arrayBuffer());
    if(!buffer.length){const error='Fish Audio respondeu sem áudio utilizável.';await logUsage({provider:'fish',model:f.model,purpose,success:false,error});return {ok:false,error,provider:'fish'};}
    const audioSeconds=(buffer.length*8)/128000;
    await logUsage({provider:'fish',model:f.model,purpose,audioSeconds,inputBytes:Buffer.byteLength(clean,'utf8'),success:true});
    return {ok:true,buffer,mimeType:'audio/mpeg',model:f.model,voice:'Sarah Rodrigues',provider:'fish',audioSeconds};
  }catch(e){
    const error=e.name==='AbortError'?'Tempo limite ao gerar a voz da Sarah na Fish Audio':(e.message||'Falha na voz Fish Audio');
    await logUsage({provider:'fish',model:f.model,purpose,success:false,error});
    return {ok:false,error,provider:'fish'};
  }finally{clearTimeout(timer)}
}
async function saraTts(text,{purpose='text_to_speech',ctx={}}={}){
  const fish=await fishTts(text,{purpose,ctx});
  if(fish.ok)return fish;
  const gemini=await geminiTts(text,{purpose});
  if(gemini.ok)return {...gemini,provider:'gemini',fallback_from:'fish'};
  return {ok:false,error:`Fish Audio: ${fish.error}; Gemini: ${gemini.error}`};
}
function telegramVoiceFile(mimeType){
  const m=String(mimeType||'').toLowerCase();
  if(['audio/ogg_opus','audio/ogg'].includes(m))return {blobType:'audio/ogg',filename:'sarah.ogg'};
  if(['audio/mp3','audio/mpeg'].includes(m))return {blobType:'audio/mpeg',filename:'sarah.mp3'};
  if(['audio/m4a','audio/mp4'].includes(m))return {blobType:'audio/mp4',filename:'sarah.m4a'};
  return null;
}
async function sendVoiceBuffer(chatId,buffer,mimeType){
  const {token}=tgConfig();if(!token)return {ok:false,description:'TELEGRAM_NOT_CONFIGURED'};
  const file=telegramVoiceFile(mimeType);if(!file)return {ok:false,description:`Formato de voz não compatível com Telegram: ${mimeType||'desconhecido'}`};
  const form=new FormData();form.append('chat_id',String(chatId));form.append('voice',new Blob([buffer],{type:file.blobType}),file.filename);
  const ctl=new AbortController(),timer=setTimeout(()=>ctl.abort(),15000);
  try{const r=await fetch(`https://api.telegram.org/bot${token}/sendVoice`,{method:'POST',body:form,signal:ctl.signal});const data=await r.json().catch(()=>({ok:false,description:`HTTP ${r.status}`}));return data}
  catch(e){return {ok:false,description:e.name==='AbortError'?'Tempo limite ao enviar voz ao Telegram':e.message}}finally{clearTimeout(timer)}
}
function wantsVoice(text){const n=normalize(text);return /(por audio|em audio|manda audio|mande audio|me responda em voz|responda falando|fala comigo|fale comigo|quero ouvir|por voz)/.test(n)}
function stripVoiceDirective(text){return String(text||'').replace(/[,.;!?]?\s*(me responda|responda|manda|mande|fale|fala)\s+(por |em )?(áudio|audio|voz)( por favor)?/ig,'').replace(/[,.;!?]?\s*(por |em )?(áudio|audio|voz)\s*$/ig,'').trim()}
function proactiveVoiceSelected(){const raw=Number(process.env.SARA_PROACTIVE_VOICE_RATE||0.15);const rate=Number.isFinite(raw)?Math.max(0,Math.min(1,raw)):0.15;return Math.random()<rate}
function isTextAnchor(ctx={}){return !!(ctx.textAnchor||ctx.report||ctx.metric||ctx.location||ctx.usage||ctx.alert||ctx.proactiveImportant)}
function deliveryPlan(settings,ctx={}){
  if(!settings.voice_enabled||settings.voice_policy==='off')return {sendText:true,sendVoice:false,reason:'voice_off'};
  const anchored=isTextAnchor(ctx),inputVoice=ctx.inputType==='voice',explicit=!!ctx.explicitVoice,policy=settings.voice_policy||'smart';
  if(policy==='always')return {sendText:true,sendVoice:true,reason:'always'};
  if(policy==='explicit')return explicit?{sendText:anchored,sendVoice:true,reason:'explicit_voice'}:{sendText:true,sendVoice:false,reason:'explicit_text'};
  if(policy==='mirror')return inputVoice?{sendText:anchored,sendVoice:true,reason:anchored?'mirror_both':'mirror_voice'}:{sendText:true,sendVoice:false,reason:'mirror_text'};
  if(policy==='mix'){
    const rate=Math.max(0,Math.min(1,Number(settings.voice_audio_percent??50)/100)),voiceChosen=Math.random()<rate;
    if(anchored)return {sendText:true,sendVoice:voiceChosen,reason:voiceChosen?'mix_anchor_both':'mix_anchor_text'};
    return voiceChosen?{sendText:false,sendVoice:true,reason:'mix_voice'}:{sendText:true,sendVoice:false,reason:'mix_text'};
  }
  if(explicit)return {sendText:anchored,sendVoice:true,reason:'smart_explicit'};
  if(ctx.proactive===true)return {sendText:true,sendVoice:proactiveVoiceSelected(),reason:'smart_proactive'};
  if(inputVoice)return {sendText:anchored,sendVoice:true,reason:anchored?'smart_voice_both':'smart_voice_only'};
  return {sendText:true,sendVoice:false,reason:'smart_text'};
}
function fallbackVoiceCompanion(text,ctx={}){
  let body=stripConversationalOpening(String(ctx.voiceFallback||text||'').replace(/\n+/g,' ').trim());
  if(!body)return '';
  if(ctx.alert)return body;
  const r=Math.random();
  if(ctx.report||ctx.metric||ctx.location||ctx.usage){
    const lead=r<0.34?'Olha...':r<0.68?'Então...':'Eu dei uma olhada aqui...';
    return `${lead} ${body}`.trim();
  }
  if(r<0.18)return `Hum... ${body}`;
  if(r<0.42)return `Olha... ${body}`;
  if(r<0.64)return `Então... ${body}`;
  return body;
}
async function generateVoiceCompanion(text,ctx={}){
  if(String(ctx.voiceText||'').trim())return String(ctx.voiceText).trim();
  if(!ctx.complementVoice)return fallbackVoiceCompanion(text,ctx);
  const facts=ctx.reportFacts?`\nFATOS E COMPARAÇÕES DISPONÍVEIS:\n${JSON.stringify(ctx.reportFacts)}`:'';
  const prompt=`Crie somente a fala de áudio complementar da Sarah Rodrigues para José. O texto escrito já foi enviado e NÃO deve ser lido nem repetido linha por linha.\n\nTEXTO ESCRITO JÁ ENVIADO:\n${String(text||'').slice(0,5000)}${facts}\n\nRegras obrigatórias:\n- use somente fatos presentes acima; não invente dado, causa, tendência ou comparação;\n- se houver dados de período anterior, você pode comparar. Se não houver, não diga melhor, pior, aumentou ou diminuiu;\n- destaque de 2 a 4 pontos realmente úteis e, se fizer sentido, uma sugestão prática;\n- fale em português brasileiro, como áudio espontâneo, em 2 a 5 frases;\n- não use listas, markdown, emojis ou URLs;\n- não comece com novo cumprimento se a conversa já está em andamento;\n- pode usar no máximo UM vício leve de linguagem, como \"olha...\", \"então...\", \"hum...\" ou \"é...\", e uma pausa curta;\n- em alertas, seja firme e não use vícios de linguagem;\n- não diga que é uma IA e não explique estas regras.`;
  const g=await geminiRequest([{text:prompt}],{json:false,maxOutputTokens:420,thinkingLevel:'low',purpose:'voice_commentary'});
  if(g.ok&&g.text.trim()&&normalize(g.text)!==normalize(text))return g.text.trim();
  const q=await groqChatRequest(prompt,{json:false,maxOutputTokens:320,purpose:'voice_commentary'});
  if(q.ok&&q.text.trim()&&normalize(q.text)!==normalize(text))return q.text.trim();
  return fallbackVoiceCompanion(text,ctx);
}
async function sendSaraResponse(chatId,text,ctx={}){
  if(typeof ctx.stopTyping==='function'){ctx.stopTyping();ctx.stopTyping=null}
  const finalText=await applyConversationCadence(chatId,text,ctx);
  const settings=await getSaraSettings(),plan=deliveryPlan(settings,ctx);let sent=null,voice=null,spokenText='';
  if(plan.sendText){await sendTyping(chatId);sent=await sendText(chatId,finalText)}
  if(plan.sendVoice){
    const stopRecording=keepChatAction(chatId,'record_voice');
    spokenText=plan.sendText?await generateVoiceCompanion(text,{...ctx,complementVoice:true}):fallbackVoiceCompanion(finalText,{...ctx,complementVoice:false});
    const tts=await saraTts(spokenText||finalText,{purpose:ctx.proactive?'proactive_voice':'reply_voice',ctx});stopRecording();
    if(tts.ok){await tgApi('sendChatAction',{chat_id:chatId,action:'upload_voice'});voice=await sendVoiceBuffer(chatId,tts.buffer,tts.mimeType)}
    else{voice={ok:false,description:tts.error};if(!plan.sendText){sent=await sendText(chatId,finalText)}}
  }
  return {text:sent,voice,finalText,spokenText,delivery:plan};
}
async function testVoice(){const {chat}=tgConfig();if(!chat)return {ok:false,error:'TELEGRAM_NOT_CONFIGURED'};const tts=await saraTts('Oi, José! Aqui é a Sarah. Minha voz já está conectada à A7W e pronta para acompanhar você por aqui.',{purpose:'voice_test',ctx:{operational:false}});if(!tts.ok)return tts;const sent=await sendVoiceBuffer(chat,tts.buffer,tts.mimeType);if(!sent.ok)return {ok:false,error:sent.description||'Falha ao enviar voz ao Telegram.'};return {ok:true,model:tts.model,voice:tts.voice,provider:tts.provider,fallback_from:tts.fallback_from||null};
}
function localPersonaReply(text){const n=normalize(text);if(/^(oi|ola|bom dia|boa tarde|boa noite|e ai|opa)( sara| sarah)?$/.test(n))return 'Tô por aqui. Como você tá? O que vamos aprontar hoje?';if(/(como voce esta|tudo bem|como esta voce)/.test(n))return 'Tô bem. De olho na operação e por aqui com você também. E você, como tá?';if(/(obrigad|valeu|perfeito|show|boa)/.test(n))return 'Fechado. Pode deixar comigo. 😄';if(/(quem e voce|quem voce e|se apresente)/.test(n))return 'Sou a Sarah Rodrigues. Você me criou para ser sua parceira dentro da A7W: converso com você, acompanho a operação, localizo veículos e motoristas, cuido dos avisos e vou te trazendo ideias para melhorar o sistema.';return 'Tô aqui. Posso conversar com você ou partir direto para a operação da A7W.'}
function parseJson(text){try{return JSON.parse(text)}catch(_){const m=String(text||'').match(/\{[\s\S]*\}/);if(!m)return null;try{return JSON.parse(m[0])}catch(__){return null}}}

function quickWatch(text){
  const n=normalize(text);
  if(/(quais|listar|mostre).*(avisos|alertas|observacoes)|^(meus|minhas) (avisos|alertas|observacoes)$/.test(n))return {intent:'list_watches',entity:null,condition:null,transcript:text};
  if(/(cancele|cancelar|pare|parar|desative|desativar).*(avisos|alertas|observacoes)|pare de me avisar/.test(n))return {intent:'cancel_watches',entity:null,condition:null,transcript:text};
  if(!/(me avise|me avisa|avise me|avisa me|me notifique|notifique me)/.test(n))return null;
  const condition=n.includes('disponivel')?'available':n.includes('online')?'online':null;
  if(!condition)return null;
  let entity=null;
  let m=n.match(/quando (?:o |a )?(.+?) (?:ficar|estiver|ficar novamente|voltar) (?:online|disponivel)/);
  if(m)entity=m[1].trim();
  if(entity&&/^(um|uma|algum|alguma)?\s*motorista$/.test(entity))entity=null;
  if(/quando (?:tiver|houver|aparecer) (?:um |uma |algum |alguma )?motorista/.test(n))entity=null;
  return {intent:'create_watch',entity,condition,transcript:text};
}
function cleanReportEntityCandidate(value){
  let c=normalize(value).replace(/^(?:o|a|do|da|de)\s+/,'').trim();
  c=c.replace(/^(?:motorista|veiculo|carro)\s+/,'').trim();
  c=c.split(/\s+(?=hoje\b|ontem\b|anteontem\b|segunda(?: feira)?\b|terca(?: feira)?\b|quarta(?: feira)?\b|quinta(?: feira)?\b|sexta(?: feira)?\b|sabado\b|domingo\b|dia\s+\d{1,2}\b|\d{1,2}[\/. -]\d{1,2}[\/. -](?:\d{2}|20\d{2})\b|20\d{2}-\d{1,2}-\d{1,2}\b)/)[0].trim();
  c=c.replace(/\s+(?:em|no|na|de|do|da)$/,'').trim();
  if(!c||/^(motorista|veiculo|carro|frota|dele|dela|operacao|quinta feira|sexta feira|quarta feira|terca feira|segunda feira|sabado|domingo)$/.test(c))return null;
  return c;
}
function reportEntityFromText(text){
  const n=normalize(text);let m;
  m=n.match(/(?:velocidade maxima|maior velocidade|pico de velocidade)\s+(?:do|da|de)\s+(.+)$/);if(m){const c=cleanReportEntityCandidate(m[1]);if(c)return c;}
  m=n.match(/(?:velocidade maxima|maior velocidade|pico de velocidade)\s+que\s+([a-z0-9][a-z0-9 -]{1,50}?)\s+(?:bateu|alcancou|atingiu|chegou)/);if(m){const c=cleanReportEntityCandidate(m[1]);if(c)return c;}
  m=n.match(/relatorio completo\s+(?:do|da|de)\s+(.+)$/);if(m){const c=cleanReportEntityCandidate(m[1]);if(c)return c;}
  m=n.match(/(?:motorista|veiculo|carro)\s+(?:chamado\s+|chamada\s+)?([a-z0-9][a-z0-9 -]{1,40}?)(?=\s+(?:hoje|ontem|anteontem|dia|na|no|em)|\?|$)/);if(m){const c=cleanReportEntityCandidate(m[1]);if(c&&!/^(bateu|alcancou|atingiu|chegou)$/.test(c))return c;}
  return null;
}
function quickIntent(text){const n=normalize(text);let m;
  const w=quickWatch(text);if(w)return w;
  if(/^(ajuda|o que voce faz|o que a (?:sara|sarah) faz)$/.test(n))return {intent:'help',entity:null,condition:null,transcript:text};
  if(/(status da frota|veiculos online|veiculos estao online|como esta a frota)/.test(n))return {intent:'fleet_status',entity:null,condition:null,transcript:text};
  if(/(resumo de hoje|resumo da operacao|como foi hoje|operacao hoje)/.test(n))return {intent:'today_summary',entity:null,condition:null,transcript:text};
  if(/(gasto|gastos|custos|custo da sarah|orcamento|orçamento|quanto.*limite|quanto.*gastei|uso da ia|uso da sarah|relatorio de gastos|relatório de gastos)/.test(n))return {intent:'usage_report',entity:null,condition:null,transcript:text};
  const reqDate=parseRequestedDate(text)||todayBR();
  if(/(velocidade maxima|maior velocidade|pico de velocidade)/.test(n)){
    const entity=reportEntityFromText(text);
    if(/(?:da |de )?frota|geral|todos os veiculos/.test(n)&&!entity)return {intent:'fleet_max_speed',entity:null,date:reqDate,condition:null,transcript:text};
    return {intent:'vehicle_max_speed',entity,date:reqDate,condition:null,transcript:text};
  }
  if(/relatorio completo|relatório completo/.test(n)){
    const entity=reportEntityFromText(text);
    if(/(?:da |de )?frota|geral|da operacao|da operação/.test(n)&&!entity)return {intent:'fleet_day_report',entity:null,date:reqDate,condition:null,transcript:text};
    return {intent:'vehicle_day_report',entity,date:reqDate,condition:null,transcript:text};
  }
  m=n.match(/^(?:onde fica|localizacao de|localizacao da empresa|procure|buscar)\s+(.+)$/);if(m)return {intent:'place_location',entity:m[1],condition:null,transcript:text};
  m=n.match(/^(?:onde esta|onde ta|cad[eê]|localizacao do|localizacao da)\s+(.+)$/);if(m)return {intent:'locate_ambiguous',entity:m[1],condition:null,transcript:text};
  return null;
}

async function classifyWithGemini({text,audio,chatId}){
  const history=await recentConversation(chatId),memory=await saraMemoryPrompt();
  const prompt=`Interprete a mensagem do usuário para a Sarah Rodrigues.\n\nIntenções permitidas:\n- vehicle_location: quer saber onde está um motorista, veículo, placa ou dispositivo.\n- place_location: quer localizar empresa, cliente, endereço ou ponto de referência.\n- fleet_status: quer situação geral da frota agora.\n- today_summary: quer resumo da operação de hoje.\n- vehicle_max_speed: quer apenas a velocidade máxima de um motorista/veículo em uma data.\n- fleet_max_speed: quer a maior velocidade da frota em uma data.\n- vehicle_day_report: quer relatório histórico completo de um motorista/veículo em uma data.\n- fleet_day_report: quer relatório histórico consolidado da frota em uma data.\n- create_watch: quer que Sarah avise futuramente quando um motorista ficar online ou disponível.\n- list_watches: quer listar observações/avisos condicionais ativos.\n- cancel_watches: quer cancelar esses avisos.\n- help: quer saber o que Sarah consegue fazer.\n- usage_report: quer saber gastos, orçamento mensal, uso de IA/voz ou quanto falta para o limite.\n- general_chat: conversa geral que não exige consultar dados operacionais.\n\nRetorne SOMENTE JSON válido.\n\nRegras:\n1. Para áudio, transcreva em transcript.\n2. entity deve conter apenas o nome principal procurado, como Anderson, Saveiro ou Truckvan; em create_watch pode ser null para qualquer motorista.\n3. condition deve ser online ou available somente em create_watch; nos demais casos use null.\n4. date, quando a mensagem trouxer uma data, dia do mês ou dia da semana, deve ser YYYY-MM-DD. Se não houver data, use null.\n5. Se o usuário disser apenas 'o motorista', 'o carro' ou 'o veículo', entity pode ser null; o sistema tentará resolver pelo contexto e pela telemetria do dia.\n6. Para general_chat, escreva em reply uma resposta natural da Sarah: elegante, inteligente, útil e com leve presença de central de comando, sem teatralidade.\n7. Para intenções operacionais, reply deve ficar vazio.\n8. Não invente nenhum dado da frota.\n\nContexto recente de conversa:\n${history||'(sem histórico)'}${memory}\n\nMensagem atual:\n${text||'(mensagem de voz anexada)'}`;
  const parts=[{text:prompt}];if(audio)parts.push({inlineData:{mimeType:audio.mimeType||'audio/ogg',data:audio.data.toString('base64')}});
  const r=await geminiRequest(parts,{json:true,maxOutputTokens:1000,thinkingLevel:'low',purpose:'intent_classification'});if(!r.ok)return r;const parsed=parseJson(r.text);if(!parsed)return {ok:false,error:'Resposta do Gemini não pôde ser interpretada.'};return {ok:true,...parsed,model:r.model};
}

async function classifyWithGroq({text,chatId}){
  const history=await recentConversation(chatId),memory=await saraMemoryPrompt();
  const prompt=`Interprete a mensagem para a Sarah Rodrigues. Responda SOMENTE JSON válido com as chaves intent, entity, condition, date, transcript e reply.\nIntenções: vehicle_location, place_location, fleet_status, today_summary, vehicle_max_speed, fleet_max_speed, vehicle_day_report, fleet_day_report, create_watch, list_watches, cancel_watches, help, usage_report, general_chat.\ncondition só pode ser online, available ou null.\nPara general_chat, reply deve conter uma resposta natural coerente com a personalidade da Sarah. Para intenção operacional, reply deve ser vazio. Não invente dados da A7W.\nContexto recente:\n${history||'(sem histórico)'}${memory}\nMensagem atual:\n${text||''}`;
  const r=await groqChatRequest(prompt,{json:true,maxOutputTokens:700,purpose:'intent_classification'});if(!r.ok)return r;const parsed=parseJson(r.text);if(!parsed)return {ok:false,error:'Resposta do Groq não pôde ser interpretada.'};return {ok:true,...parsed,model:r.model,provider:'groq'};
}
async function classifyWithDeepSeek({text,chatId}){
  const history=await recentConversation(chatId),memory=await saraMemoryPrompt();
  const prompt=`Interprete a mensagem para a Sarah Rodrigues. Responda SOMENTE JSON válido com as chaves intent, entity, condition, date, transcript e reply.\nIntenções: vehicle_location, place_location, fleet_status, today_summary, vehicle_max_speed, fleet_max_speed, vehicle_day_report, fleet_day_report, create_watch, list_watches, cancel_watches, help, usage_report, general_chat.\ncondition só pode ser online, available ou null.\nPara general_chat, reply deve conter uma resposta natural coerente com a personalidade da Sarah. Para intenção operacional, reply deve ser vazio. Não invente dados da A7W.\nContexto recente:\n${history||'(sem histórico)'}${memory}\nMensagem atual:\n${text||''}`;
  const r=await deepseekChatRequest(prompt,{json:true,maxOutputTokens:700,purpose:'intent_classification'});if(!r.ok)return r;const parsed=parseJson(r.text);if(!parsed)return {ok:false,error:'Resposta do DeepSeek não pôde ser interpretada.'};return {ok:true,...parsed,model:r.model,provider:'deepseek'};
}
async function classifyWithAI({text,audio,chatId}){
  let transcript=String(text||'').trim(),firstError='';const qcfg=groqConfig(),gcfg=geminiConfig(),dcfg=deepseekConfig();
  // Áudio: prioriza Whisper/Groq quando disponível para poupar cota multimodal do Gemini.
  if(audio&&qcfg.key){const tr=await groqTranscribe(audio);if(tr.ok)transcript=tr.text;else firstError=tr.error||'';}
  if(transcript){const local=quickIntent(transcript);if(local)return {ok:true,...local,transcript,provider:'local'};}
  // Se não houve transcrição externa, o próprio Gemini pode compreender o áudio.
  if(gcfg.key){const g=await classifyWithGemini({text:transcript,audio:audio&&!transcript?audio:null,chatId});if(g.ok)return {...g,provider:'gemini'};if(!firstError)firstError=g.error||'';}
  if(qcfg.key&&transcript){const q=await classifyWithGroq({text:transcript,chatId});if(q.ok)return q;if(!firstError)firstError=q.error||'';}
  if(dcfg.key&&deepseekEnabled()&&transcript){const d=await classifyWithDeepSeek({text:transcript,chatId});if(d.ok)return d;if(!firstError)firstError=d.error||'';}
  return {ok:true,intent:'general_chat',entity:null,condition:null,transcript:transcript||'[áudio]',reply:localPersonaReply(transcript),provider:'local',fallback_error:firstError||null};
}

async function trackedEntities(){const [rows]=await pool.execute(`SELECT td.id,td.device_key,td.label,td.last_lat,td.last_lon,td.last_speed,td.battery,td.last_seen_at,a.vehicle_id,a.driver_id,v.name vehicle_name,v.plate,dr.name driver_name,COALESCE(ad.active_delivery_count,0) active_delivery_count FROM platform_tracking_devices td LEFT JOIN platform_assignments a ON a.tracking_device_id=td.id AND a.active=1 LEFT JOIN platform_vehicles v ON v.id=a.vehicle_id LEFT JOIN platform_drivers dr ON dr.id=a.driver_id LEFT JOIN (SELECT driver_id,COUNT(*) active_delivery_count FROM platform_deliveries WHERE driver_id IS NOT NULL AND status IN('loaded','on_route','arrived') GROUP BY driver_id) ad ON ad.driver_id=a.driver_id ORDER BY td.last_seen_at DESC`);return rows}
async function findTrackedEntity(q){const rows=await trackedEntities();const scored=rows.map(r=>({...r,score:fuzzy(q,r.driver_name,r.vehicle_name,r.plate,r.label,r.device_key)})).sort((a,b)=>a.score-b.score);return scored[0]&&scored[0].score<=.46?scored[0]:null}

async function reverseGeocode(lat,lon){const key=String(process.env.LOCATIONIQ_TOKEN||'').trim();if(!key)return null;const ck=`${Number(lat).toFixed(4)}|${Number(lon).toFixed(4)}`,hit=locationCache.get(ck);if(hit&&Date.now()-hit.t<15*60*1000)return hit.v;try{const u=new URL('https://us1.locationiq.com/v1/reverse');u.searchParams.set('key',key);u.searchParams.set('lat',String(lat));u.searchParams.set('lon',String(lon));u.searchParams.set('format','json');u.searchParams.set('accept-language','pt-BR');const r=await fetch(u,{headers:{Accept:'application/json','User-Agent':'A7W-Platform-Sarah/0.9.9'}});const b=await r.json().catch(()=>({}));if(!r.ok)return null;const v=b.display_name||null;locationCache.set(ck,{t:Date.now(),v});return v}catch(_){return null}}
async function primaryReference(){const [rows]=await pool.execute(`SELECT name,latitude,longitude FROM platform_reference_points WHERE is_primary=1 ORDER BY id DESC LIMIT 1`);return rows[0]||null}

async function answerVehicleLocation(chatId,entity,ctx={}){const target=await findTrackedEntity(entity);if(!target)return sendSaraResponse(chatId,`Não localizei “${entity}” entre os motoristas, veículos ou dispositivos vinculados da A7W.`,ctx);const lat=Number(target.last_lat),lon=Number(target.last_lon);if(!Number.isFinite(lat)||!Number.isFinite(lon))return sendSaraResponse(chatId,`${target.driver_name||target.vehicle_name||target.device_key} está cadastrado, mas ainda não possui uma posição GPS válida.`,ctx);
  const address=await reverseGeocode(lat,lon);const online=isOnline(target);const speed=Number(target.last_speed||0);const status=!online?'Offline':speed>=4?'Em movimento':'Parado';const ref=await primaryReference();let dist='';if(ref){const km=hav(lat,lon,Number(ref.latitude),Number(ref.longitude))/1000;dist=`\nDistância de ${ref.name}: ${km.toFixed(1).replace('.',',')} km`;}
  const title=[target.driver_name,target.vehicle_name].filter(Boolean).join(' · ')||target.device_key;const lead=target.driver_name?`Localizei ${target.driver_name}.`:'Localizei o veículo.';const msg=`${lead} 📍\n\n${title}\nStatus: ${status}\nVelocidade: ${speed.toFixed(0)} km/h\nÚltima atualização: ${brDate(target.last_seen_at)}${target.battery!=null?`\nBateria: ${Number(target.battery).toFixed(0)}%`:''}${dist}${address?`\n\n${address}`:''}\n\nAbrir rota: ${routeLink(lat,lon)}`;await sendSaraResponse(chatId,msg,{...ctx,operational:true,location:true,textAnchor:true,complementVoice:true});await sendLocation(chatId,lat,lon);await saveConversation(chatId,'out','location',msg,'vehicle_location')}

async function internalPlace(q){const [refs]=await pool.execute(`SELECT id,name,address,latitude,longitude,'reference' source FROM platform_reference_points ORDER BY is_primary DESC,id DESC LIMIT 500`);const [companies]=await pool.execute(`SELECT c.id,c.trade_name,c.legal_name,d.address,d.lat latitude,d.lon longitude FROM platform_companies c LEFT JOIN platform_orders o ON o.company_id=c.id LEFT JOIN platform_deliveries d ON d.order_id=o.id WHERE c.status<>'rejected' ORDER BY d.id DESC LIMIT 1200`);const [stops]=await pool.execute(`SELECT id,name,address,latitude,longitude,'route' source FROM platform_route_stops ORDER BY id DESC LIMIT 500`);const list=[];for(const x of refs)list.push({...x,label:x.name,score:fuzzy(q,x.name,x.address)});const seen=new Set();for(const x of companies){if(seen.has(x.id))continue;seen.add(x.id);list.push({...x,label:x.trade_name||x.legal_name,score:fuzzy(q,x.trade_name,x.legal_name,x.address),source:'company'})}for(const x of stops)list.push({...x,label:x.name,score:fuzzy(q,x.name,x.address)});list.sort((a,b)=>a.score-b.score);const best=list[0];return best&&best.score<=.44?best:null}
async function externalPlace(q){const key=String(process.env.LOCATIONIQ_TOKEN||'').trim();if(!key)return null;try{const u=new URL('https://us1.locationiq.com/v1/search');u.searchParams.set('key',key);u.searchParams.set('q',q);u.searchParams.set('format','json');u.searchParams.set('limit','1');u.searchParams.set('countrycodes','br');u.searchParams.set('accept-language','pt-BR');const r=await fetch(u,{headers:{Accept:'application/json','User-Agent':'A7W-Platform-Sarah/0.9.9'}});const b=await r.json().catch(()=>[]);if(!r.ok||!Array.isArray(b)||!b[0])return null;return {label:b[0].display_name?.split(',')[0]||q,address:b[0].display_name||'',latitude:Number(b[0].lat),longitude:Number(b[0].lon),source:'locationiq'}}catch(_){return null}}
async function answerPlaceLocation(chatId,entity,ctx={}){let p=await internalPlace(entity);if(p&&(p.latitude===null||p.latitude===undefined||p.longitude===null||p.longitude===undefined||!Number.isFinite(Number(p.latitude))||!Number.isFinite(Number(p.longitude))))return sendSaraResponse(chatId,`Encontrei ${p.label} na base da A7W, mas esse cliente ainda não tem coordenadas cadastradas. Marque a localização uma vez em Frota/Rotas e eu passo a encontrá-lo diretamente.`,ctx);if(!p)p=await externalPlace(entity);if(!p)return sendSaraResponse(chatId,`Não encontrei uma localização confiável para “${entity}”.`,ctx);const lat=Number(p.latitude),lon=Number(p.longitude);const msg=`Local encontrado. 📍\n\n${p.label||entity}${p.address?`\n${p.address}`:''}\n\nAbrir rota: ${routeLink(lat,lon)}`;await sendSaraResponse(chatId,msg,{...ctx,operational:true,location:true,textAnchor:true,complementVoice:true});await sendLocation(chatId,lat,lon);await saveConversation(chatId,'out','location',msg,'place_location')}

async function answerFleetStatus(chatId,ctx={}){const rows=await trackedEntities();let online=0,moving=0,stopped=0,offline=0,available=0;const lines=[];for(const r of rows){const on=isOnline(r),speed=Number(r.last_speed||0);if(!on)offline++;else if(speed>=4){online++;moving++}else{online++;stopped++}if(isAvailable(r))available++;lines.push(`${!on?'⚪':speed>=4?'🟢':'🟡'} ${r.vehicle_name||r.label||r.device_key}${r.driver_name?' · '+r.driver_name:''}${on?` · ${speed.toFixed(0)} km/h`:' · offline'}${isAvailable(r)?' · disponível':''}`)}const msg=`Fiz uma leitura da frota agora.\n\nOnline: ${online}\nEm movimento: ${moving}\nParados: ${stopped}\nDisponíveis: ${available}\nOffline: ${offline}${lines.length?`\n\n${lines.slice(0,10).join('\n')}`:''}`;await sendSaraResponse(chatId,msg,{...ctx,operational:true,report:true,textAnchor:true,complementVoice:true});await saveConversation(chatId,'out','text',msg,'fleet_status')}
async function answerTodaySummary(chatId,ctx={}){const date=todayBR();const [[del]]=await pool.execute(`SELECT COUNT(*) total,SUM(status='delivered') delivered,SUM(status='failed') failed,SUM(status NOT IN ('delivered','failed')) waiting FROM platform_deliveries WHERE DATE(COALESCE(planned_at,created_at))=?`,[date]);const [[st]]=await pool.execute(`SELECT COUNT(*) total,COUNT(DISTINCT COALESCE(vehicle_id,0)) routes FROM platform_route_stops WHERE route_date=?`,[date]);const [[ev]]=await pool.execute(`SELECT COUNT(*) total FROM platform_fleet_events WHERE DATE(occurred_at)=?`,[date]);const rows=await trackedEntities();const online=rows.filter(isOnline).length;const available=rows.filter(isAvailable).length;const total=Math.max(Number(del.total||0),Number(st.total||0));const delivered=Number(del.delivered||0),failed=Number(del.failed||0),waiting=Math.max(Number(del.waiting||0),total-delivered-failed);const msg=`Este é o quadro operacional de hoje.\n\nVeículos online: ${online}/${rows.length}\nMotoristas disponíveis: ${available}\nRotas planejadas: ${Number(st.routes||0)}\nAtividades/entregas: ${total}\nConcluídas: ${delivered}\nAguardando: ${waiting}\nNão realizadas: ${failed}\nEventos registrados: ${Number(ev.total||0)}`;await sendSaraResponse(chatId,msg,{...ctx,operational:true,report:true,textAnchor:true,complementVoice:true});await saveConversation(chatId,'out','text',msg,'today_summary')}
async function dayEntity(entity){return findTrackedEntity(entity)}
function genericReportEntity(entity){const n=normalize(entity);return !n||/^(o |a )?(motorista|veiculo|carro|dele|dela|do motorista|da motorista|do veiculo)$/.test(n)}
async function telemetryEntitiesOnDate(date){
  const [a,b]=dayBoundsBR(date);
  const [rows]=await pool.execute(`SELECT DISTINCT lp.device_key,td.label,a.vehicle_id,a.driver_id,v.name vehicle_name,v.plate,dr.name driver_name FROM platform_location_points lp LEFT JOIN platform_tracking_devices td ON td.device_key=lp.device_key LEFT JOIN platform_assignments a ON a.tracking_device_id=td.id AND a.active=1 LEFT JOIN platform_vehicles v ON v.id=a.vehicle_id LEFT JOIN platform_drivers dr ON dr.id=a.driver_id WHERE lp.recorded_at BETWEEN ? AND ? ORDER BY lp.device_key`,[a,b]);
  return rows;
}
async function inferRecentTrackedEntity(chatId){
  if(!chatId)return null;
  const entities=await trackedEntities();if(!entities.length)return null;
  const [rows]=await pool.execute(`SELECT text_content FROM platform_sara_messages WHERE chat_id=? ORDER BY id DESC LIMIT 20`,[String(chatId)]).catch(()=>[[]]);
  for(const msg of rows){const n=normalize(msg.text_content);for(const e of entities){const names=[e.driver_name,e.vehicle_name,e.plate,e.label].filter(Boolean);if(names.some(x=>{const z=normalize(x);return z&&n.includes(z)}))return e;}}
  return null;
}
async function resolveHistoricalTarget(entity,date,chatId){
  if(!genericReportEntity(entity)){const direct=await findTrackedEntity(entity);if(direct)return {target:direct,choices:[]};}
  const recent=await inferRecentTrackedEntity(chatId);if(recent)return {target:recent,choices:[]};
  const day=await telemetryEntitiesOnDate(date);
  if(day.length===1)return {target:day[0],choices:[]};
  const current=(await trackedEntities()).filter(x=>x.driver_name);
  if(current.length===1)return {target:current[0],choices:[]};
  return {target:null,choices:day.slice(0,8)};
}
function historicalChoicesText(choices=[]){const names=[...new Set(choices.map(x=>x.driver_name||x.vehicle_name||x.label||x.device_key).filter(Boolean))];return names.length?` Encontrei: ${names.join(', ')}.`:''}
async function vehicleDayStats(target,date){
  const [a,b]=dayBoundsBR(date),deviceKey=target.device_key;
  const [rows]=await pool.execute(`SELECT latitude,longitude,speed_kmh,recorded_at FROM platform_location_points WHERE device_key=? AND recorded_at BETWEEN ? AND ? ORDER BY recorded_at ASC LIMIT 30000`,[deviceKey,a,b]);
  if(!rows.length)return null;
  let maxSpeed=0,maxAt=null,meters=0,movingSec=0,stoppedSec=0,last=null,stopStart=null,longestStopSec=0,stops5=0,movingSpeeds=[];
  for(const r of rows){const speed=Number(r.speed_kmh||0);if(speed>maxSpeed){maxSpeed=speed;maxAt=r.recorded_at}if(last){let dt=(new Date(r.recorded_at)-new Date(last.recorded_at))/1000;if(Number.isFinite(dt)&&dt>0&&dt<=900){const d=hav(Number(last.latitude),Number(last.longitude),Number(r.latitude),Number(r.longitude));const moving=speed>=4;if(moving){movingSec+=dt;if(d>=3&&d/dt*3.6<220)meters+=d;movingSpeeds.push(speed);if(stopStart){const dur=(new Date(last.recorded_at)-new Date(stopStart.recorded_at))/1000;if(dur>=300){stops5++;longestStopSec=Math.max(longestStopSec,dur)}stopStart=null}}else{stoppedSec+=dt;if(!stopStart)stopStart=last}}}last=r}
  if(stopStart&&last){const dur=(new Date(last.recorded_at)-new Date(stopStart.recorded_at))/1000;if(dur>=300){stops5++;longestStopSec=Math.max(longestStopSec,dur)}}
  const [events]=await pool.execute(`SELECT event_type,title,severity,occurred_at,ended_at,configured_value,realized_value,value_unit,details FROM platform_fleet_events WHERE device_key=? AND occurred_at BETWEEN ? AND ? ORDER BY occurred_at ASC`,[deviceKey,a,b]);
  const counts={};for(const e of events)counts[e.event_type]=(counts[e.event_type]||0)+1;
  return {rows,first:rows[0].recorded_at,last:rows.at(-1).recorded_at,max_speed_kmh:maxSpeed,max_speed_at:maxAt,distance_km:meters/1000,moving_minutes:movingSec/60,stopped_minutes:stoppedSec/60,avg_moving_kmh:movingSpeeds.length?movingSpeeds.reduce((x,y)=>x+y,0)/movingSpeeds.length:0,min_moving_kmh:movingSpeeds.length?Math.min(...movingSpeeds):0,stops5,longest_stop_minutes:longestStopSec/60,events,counts};
}
async function answerVehicleMaxSpeed(chatId,entity,date,ctx={}){
  const resolved=await resolveHistoricalTarget(entity,date,chatId),target=resolved.target;
  if(!target){const msg=`Preciso saber qual motorista ou veículo você quer consultar em ${date.split('-').reverse().join('/')}.${historicalChoicesText(resolved.choices)}`;await sendSaraResponse(chatId,msg,ctx);return saveConversation(chatId,'out','text',msg,'vehicle_max_speed')}
  const st=await vehicleDayStats(target,date),who=target.driver_name||target.vehicle_name||target.plate||target.device_key;
  if(!st){const msg=pickOne([`Conferi a telemetria de ${who} em ${date.split('-').reverse().join('/')} e não encontrei nenhum registro.`,`Dei uma olhada em todos os registros de ${who} para ${date.split('-').reverse().join('/')}, mas não há telemetria nesse dia.`,`Revisei os parâmetros de ${who} em ${date.split('-').reverse().join('/')} e não encontrei dados de telemetria.`]);await sendSaraResponse(chatId,msg,ctx);return saveConversation(chatId,'out','text',msg,'vehicle_max_speed')}
  const at=st.max_speed_at?` às ${new Date(st.max_speed_at).toLocaleTimeString('pt-BR',{timeZone:'America/Sao_Paulo',hour:'2-digit',minute:'2-digit'})}`:'';
  const msg=`Em ${date.split('-').reverse().join('/')}, ${who} atingiu a velocidade máxima de ${st.max_speed_kmh.toFixed(0)} km/h${at}.`;
  await sendSaraResponse(chatId,msg,{...ctx,operational:true,metric:true,textAnchor:true,complementVoice:true,voiceFallback:`Olha, a máxima de ${who} nesse dia foi ${st.max_speed_kmh.toFixed(0)} km/h${at}.`});await saveConversation(chatId,'out','text',msg,'vehicle_max_speed');
}
async function answerFleetMaxSpeed(chatId,date,ctx={}){
  const devices=await telemetryEntitiesOnDate(date);if(!devices.length){const msg=pickOne([`Conferi a frota em ${date.split('-').reverse().join('/')} e não encontrei telemetria registrada.`,`Revisei os registros da frota de ${date.split('-').reverse().join('/')}, mas não há dados de telemetria nesse dia.`]);await sendSaraResponse(chatId,msg,ctx);return saveConversation(chatId,'out','text',msg,'fleet_max_speed')}
  let best=null;for(const d of devices){const st=await vehicleDayStats(d,date);if(st&&(!best||st.max_speed_kmh>best.st.max_speed_kmh))best={d,st};}
  if(!best)return answerFleetDayReport(chatId,date,ctx);
  const who=best.d.driver_name||best.d.vehicle_name||best.d.plate||best.d.device_key;const at=best.st.max_speed_at?` às ${new Date(best.st.max_speed_at).toLocaleTimeString('pt-BR',{timeZone:'America/Sao_Paulo',hour:'2-digit',minute:'2-digit'})}`:'';
  const msg=`A maior velocidade registrada na frota em ${date.split('-').reverse().join('/')} foi ${best.st.max_speed_kmh.toFixed(0)} km/h, com ${who}${at}.`;
  await sendSaraResponse(chatId,msg,{...ctx,operational:true,metric:true,textAnchor:true,complementVoice:true,voiceFallback:`A maior velocidade do dia foi ${best.st.max_speed_kmh.toFixed(0)} km/h, registrada por ${who}${at}.`});await saveConversation(chatId,'out','text',msg,'fleet_max_speed');
}
function vehicleReportFacts(st,prev,who,date){
  const cur={date,who,max_speed_kmh:Number(st.max_speed_kmh||0),max_speed_at:st.max_speed_at?brTime(st.max_speed_at):null,min_moving_kmh:Number(st.min_moving_kmh||0),avg_moving_kmh:Number(st.avg_moving_kmh||0),distance_km:Number(st.distance_km||0),moving_minutes:Number(st.moving_minutes||0),stopped_minutes:Number(st.stopped_minutes||0),stops5:Number(st.stops5||0),overspeed:Number(st.counts?.overspeed||0),unplanned_stop:Number(st.counts?.unplanned_stop||0),idle:Number(st.counts?.idle||0)};
  const previous=prev?{date:shiftYmd(date,-1),max_speed_kmh:Number(prev.max_speed_kmh||0),avg_moving_kmh:Number(prev.avg_moving_kmh||0),distance_km:Number(prev.distance_km||0),stopped_minutes:Number(prev.stopped_minutes||0),stops5:Number(prev.stops5||0),overspeed:Number(prev.counts?.overspeed||0)}:null;
  return {current:cur,previous};
}
function vehicleReportVoiceFallback(st,prev,who,date){
  const over=Number(st.counts?.overspeed||0),parts=[];
  parts.push(`Eu conferi os dados de ${who}. A máxima ficou em ${st.max_speed_kmh.toFixed(0)} km/h${st.max_speed_at?` por volta de ${brTime(st.max_speed_at)}`:''}, e a distância estimada foi de ${st.distance_km.toFixed(1).replace('.',',')} km.`);
  if(over>0)parts.push(`O ponto que mais chama atenção são ${over} registro${over===1?'':'s'} de excesso de velocidade.`);else if(st.stops5>0)parts.push(`Também apareceram ${st.stops5} parada${st.stops5===1?'':'s'} de cinco minutos ou mais.`);else parts.push('No restante, não apareceu excesso de velocidade registrado nesse período.');
  if(prev){const delta=st.max_speed_kmh-prev.max_speed_kmh;if(Math.abs(delta)>=5)parts.push(`Comparando com o dia anterior, a máxima ficou ${Math.abs(delta).toFixed(0)} km/h ${delta>0?'acima':'abaixo'}.`);}
  return parts.join(' ');
}
async function answerVehicleDayReport(chatId,entity,date,ctx={}){
  const resolved=await resolveHistoricalTarget(entity,date,chatId),target=resolved.target;if(!target){const msg=`Preciso saber qual motorista ou veículo você quer consultar em ${date.split('-').reverse().join('/')}.${historicalChoicesText(resolved.choices)}`;await sendSaraResponse(chatId,msg,ctx);return saveConversation(chatId,'out','text',msg,'vehicle_day_report')}
  const d=date||todayBR(),st=await vehicleDayStats(target,d),who=[target.driver_name,target.vehicle_name,target.plate].filter(Boolean).join(' · ')||target.device_key;
  if(!st){const msg=pickOne([`Conferi a telemetria de ${who} em ${d.split('-').reverse().join('/')} e não encontrei nenhum registro.`,`Dei uma olhada em todos os parâmetros de ${who} no dia ${d.split('-').reverse().join('/')}, mas não há telemetria registrada.`]);await sendSaraResponse(chatId,msg,ctx);return saveConversation(chatId,'out','text',msg,'vehicle_day_report')}
  const over=st.counts.overspeed||0,unplanned=st.counts.unplanned_stop||0,idle=st.counts.idle||0;
  const prev=await vehicleDayStats(target,shiftYmd(d,-1)).catch(()=>null);
  const msg=`Relatório completo de ${who} — ${d.split('-').reverse().join('/')}.

Velocidade máxima: ${st.max_speed_kmh.toFixed(0)} km/h${st.max_speed_at?` · às ${brTime(st.max_speed_at)}`:''}
Velocidade média em movimento: ${st.avg_moving_kmh.toFixed(1).replace('.',',')} km/h
Distância estimada: ${st.distance_km.toFixed(1).replace('.',',')} km
Tempo em movimento: ${fmtMinutes(st.moving_minutes)}
Tempo parado: ${fmtMinutes(st.stopped_minutes)}
Paradas de 5 min ou mais: ${st.stops5}${st.longest_stop_minutes?` · maior ${fmtMinutes(st.longest_stop_minutes)}`:''}
Excessos de velocidade registrados: ${over}
Paradas não planejadas: ${unplanned}
Marcha lenta: ${idle}
Primeiro ponto: ${brDate(st.first)}
Último ponto: ${brDate(st.last)}
Pontos de telemetria: ${st.rows.length}`;
  await sendSaraResponse(chatId,msg,{...ctx,operational:true,report:true,textAnchor:true,complementVoice:true,reportFacts:vehicleReportFacts(st,prev,who,d),voiceFallback:vehicleReportVoiceFallback(st,prev,who,d)});await saveConversation(chatId,'out','text',msg,'vehicle_day_report');
}
async function answerFleetDayReport(chatId,date,ctx={}){
  const d=date||todayBR(),[a,b]=dayBoundsBR(d);
  const [devices]=await pool.execute(`SELECT DISTINCT lp.device_key,td.label,a.vehicle_id,a.driver_id,v.name vehicle_name,v.plate,dr.name driver_name FROM platform_location_points lp LEFT JOIN platform_tracking_devices td ON td.device_key=lp.device_key LEFT JOIN platform_assignments a ON a.tracking_device_id=td.id AND a.active=1 LEFT JOIN platform_vehicles v ON v.id=a.vehicle_id LEFT JOIN platform_drivers dr ON dr.id=a.driver_id WHERE lp.recorded_at BETWEEN ? AND ?`,[a,b]);
  if(!devices.length){const msg=pickOne([`Conferi a frota em ${d.split('-').reverse().join('/')} e não encontrei telemetria registrada.`,`Revisei os registros da frota de ${d.split('-').reverse().join('/')}, mas não há dados nesse dia.`]);await sendSaraResponse(chatId,msg,ctx);return saveConversation(chatId,'out','text',msg,'fleet_day_report')}
  let max={speed:0,label:'—'},distance=0,overs=0,unplanned=0,idle=0;const lines=[];
  for(const v of devices){const st=await vehicleDayStats(v,d);if(!st)continue;const label=v.vehicle_name||v.driver_name||v.label||v.device_key;distance+=st.distance_km;overs+=st.counts.overspeed||0;unplanned+=st.counts.unplanned_stop||0;idle+=st.counts.idle||0;if(st.max_speed_kmh>max.speed)max={speed:st.max_speed_kmh,label};lines.push(`• ${label}: máx. ${st.max_speed_kmh.toFixed(0)} km/h · ${st.distance_km.toFixed(1).replace('.',',')} km · ${st.stops5} parada(s) ≥5 min`)}
  const msg=`Relatório consolidado da frota — ${d.split('-').reverse().join('/')}.

Veículos com telemetria: ${devices.length}
Distância estimada total: ${distance.toFixed(1).replace('.',',')} km
Maior velocidade do dia: ${max.speed.toFixed(0)} km/h · ${max.label}
Excessos de velocidade: ${overs}
Paradas não planejadas: ${unplanned}
Marcha lenta: ${idle}

${lines.slice(0,12).join('\n')}`;
  await sendSaraResponse(chatId,msg,{...ctx,operational:true,report:true,textAnchor:true,complementVoice:true,reportFacts:{date:d,vehicles:devices.length,distance_km:distance,max_speed_kmh:max.speed,max_vehicle:max.label,overspeed:overs,unplanned_stop:unplanned,idle}});await saveConversation(chatId,'out','text',msg,'fleet_day_report');
}

async function answerUsageReport(chatId,ctx={}){const u=await usageSummary();const spent=u.actual_cost_brl==null?null:Number(u.actual_cost_brl||0),budget=Number(u.budget_brl||25),remaining=u.budget_remaining_brl==null?null:Number(u.budget_remaining_brl);const spentLine=spent==null?`Custo estimado: US$ ${Number(u.actual_cost_usd||0).toFixed(4)} (configure o câmbio para converter em reais)`:`Custo estimado real: R$ ${spent.toFixed(2).replace('.',',')}`;const remainingLine=remaining==null?'Saldo do teto: aguardando câmbio USD→BRL':`Saldo até o teto: R$ ${remaining.toFixed(2).replace('.',',')}`;const fishNote=u.fish_free_model?`Fish S2.1 Pro Free: ${u.fish_calls} chamada(s), ~${Math.round(Number(u.fish_audio_seconds||0))} s de áudio; sem teto rígido de caracteres sob fair use enquanto a janela gratuita estiver vigente.`:`Fish Audio: ${u.fish_calls} chamada(s), ~${Math.round(Number(u.fish_audio_seconds||0))} s de áudio.`;const msg=`Este é o relatório de uso da Sarah neste mês.

${spentLine}
Teto mensal: R$ ${budget.toFixed(2).replace('.',',')}
${remainingLine}
Chamadas registradas: ${u.calls}
Áudio processado/gerado: ~${Math.round(Number(u.audio_seconds||0))} s
Falhas registradas: ${u.failures}

${fishNote}`;await sendSaraResponse(chatId,msg,{...ctx,operational:true,usage:true,report:true,textAnchor:true,complementVoice:true});await saveConversation(chatId,'out','text',msg,'usage_report')}
async function answerHelp(chatId,ctx={}){const msg=`Estou por aqui. Posso conversar com você por texto ou áudio e, ao mesmo tempo, acompanhar a operação da A7W.\n\nExperimente:\n• “Onde está Anderson?”\n• “Onde está a Saveiro?”\n• “Onde fica Truckvan?”\n• “Quais veículos estão online?”\n• “Resumo da operação de hoje”
• “Qual foi a velocidade máxima do Anderson ontem?”
• “Relatório completo da Saveiro de 19/09/2026”
• “Relatório completo da frota de hoje”\n• “Me avise quando tiver um motorista disponível”\n• “Me avise quando Anderson ficar online”\n• “Quais avisos estão ativos?”\n• “Me responda em áudio.”\n\nQuando houver coordenada, envio também o ponto no mapa e o link de rota.`;await sendSaraResponse(chatId,msg,ctx);await saveConversation(chatId,'out','text',msg,'help')}

async function matchWatch(w){
  const rows=await trackedEntities();
  let candidates=rows.filter(r=>r.driver_name);
  if(w.entity_query){const q=w.entity_query;candidates=candidates.map(r=>({...r,score:fuzzy(q,r.driver_name,r.vehicle_name,r.plate,r.label,r.device_key)})).sort((a,b)=>a.score-b.score).filter((r,i)=>i===0&&r.score<=.46)}
  const fn=w.watch_type==='driver_available'?isAvailable:isOnline;
  return candidates.find(fn)||null;
}
async function notifyWatch(chatId,w,target,prefix=''){
  const condition=w.watch_type==='driver_available'?'disponível':'online';
  const name=target.driver_name||target.vehicle_name||target.device_key;
  const vehicle=target.vehicle_name&&target.vehicle_name!==name?` · ${target.vehicle_name}`:'';
  const speed=Number(target.last_speed||0);
  const lead=prefix||`${name} acaba de ficar ${condition}.`;
  const idleNote=w.watch_type==='driver_available'?'\nCritério atual: online, parado e sem entrega ativa.':'';
  const speedLine=isOnline(target)?`\nVelocidade: ${speed.toFixed(0)} km/h`:'';
  const msg=`${lead}\n\n🟢 ${name}${vehicle}\nStatus: ${condition}${speedLine}\nÚltima atualização: ${brDate(target.last_seen_at)}${idleNote}`;
  await sendSaraResponse(chatId,msg,{proactive:true,operational:true,alert:true});
  const lat=Number(target.last_lat),lon=Number(target.last_lon);if(Number.isFinite(lat)&&Number.isFinite(lon))await sendLocation(chatId,lat,lon);
  await saveConversation(chatId,'out','watch',msg,'watch_notification');
}
async function createWatch(chatId,condition,entity,ctx={}){
  const watchType=condition==='available'?'driver_available':'driver_online';
  const entityClean=String(entity||'').trim()||null;
  const [ins]=await pool.execute(`INSERT INTO platform_sara_watches(chat_id,watch_type,entity_query,status,last_state) VALUES(?,?,?,'active',0)`,[String(chatId),watchType,entityClean]);
  const w={id:ins.insertId,chat_id:String(chatId),watch_type:watchType,entity_query:entityClean};
  const hit=await matchWatch(w);
  if(hit){
    const [u]=await pool.execute(`UPDATE platform_sara_watches SET status='triggered',last_state=1,triggered_at=NOW() WHERE id=? AND status='active'`,[w.id]);
    if(u.affectedRows){const name=hit.driver_name||hit.vehicle_name||entityClean||'O motorista';const state=condition==='available'?'disponível':'online';await notifyWatch(chatId,w,hit,`${name} já está ${state}.`);}
    return;
  }
  const phrase=condition==='available'?'ficar disponível':'ficar online';
  const who=entityClean?entityClean:'um motorista';
  const note=condition==='available'?'\n\nNesta fase, considero disponível quando está online, parado e sem entrega ativa.':'';
  const msg=`Pode deixar. Vou acompanhar ${who} e aviso assim que ${phrase}.${note}`;
  await sendSaraResponse(chatId,msg,ctx);await saveConversation(chatId,'out','text',msg,'create_watch');
}
async function listWatches(chatId,ctx={}){const [rows]=await pool.execute(`SELECT * FROM platform_sara_watches WHERE chat_id=? AND status='active' ORDER BY id DESC LIMIT 50`,[String(chatId)]);if(!rows.length){const msg='No momento não há nenhum aviso condicional ativo.';await sendSaraResponse(chatId,msg,ctx);return saveConversation(chatId,'out','text',msg,'list_watches')}const lines=rows.map((w,i)=>`${i+1}. ${w.entity_query||'Qualquer motorista'} · ${w.watch_type==='driver_available'?'disponível':'online'}`);const msg=`Estou acompanhando ${rows.length} condição(ões):\n\n${lines.join('\n')}`;await sendSaraResponse(chatId,msg,ctx);await saveConversation(chatId,'out','text',msg,'list_watches')}
async function cancelWatches(chatId,ctx={}){const [r]=await pool.execute(`UPDATE platform_sara_watches SET status='cancelled',cancelled_at=NOW() WHERE chat_id=? AND status='active'`,[String(chatId)]);const msg=r.affectedRows?`Pronto. Cancelei ${r.affectedRows} observação(ões) ativa(s).`:'Não havia nenhum aviso ativo para cancelar.';await sendSaraResponse(chatId,msg,ctx);await saveConversation(chatId,'out','text',msg,'cancel_watches')}

let watchBusy=false;
async function processWatches(){if(watchBusy||String(process.env.SARA_WATCHES_BACKGROUND||'true').toLowerCase()==='false')return;watchBusy=true;try{const [rows]=await pool.execute(`SELECT * FROM platform_sara_watches WHERE status='active' ORDER BY id ASC LIMIT 200`);for(const w of rows){const hit=await matchWatch(w);if(!hit)continue;const [u]=await pool.execute(`UPDATE platform_sara_watches SET status='triggered',last_state=1,triggered_at=NOW() WHERE id=? AND status='active'`,[w.id]);if(u.affectedRows)await notifyWatch(w.chat_id,w,hit)}}catch(e){if(String(process.env.FLEET_ALERTS_DEBUG||'').toLowerCase()==='true')console.error('Sarah watches:',e.message)}finally{watchBusy=false}}
setInterval(processWatches,30000).unref?.();

async function sendSaraFleetAlert(ev={}){
  if(String(process.env.SARA_PROACTIVE_EVENTS_ENABLED||'true').toLowerCase()==='false')return {ok:false,skipped:true};
  if(!['attention','critical'].includes(String(ev.severity||'info')))return {ok:false,skipped:true};
  const {chat}=tgConfig();if(!chat)return {ok:false,error:'TELEGRAM_NOT_CONFIGURED'};
  const who=[ev.vehicle_name,ev.driver_name].filter(Boolean).join(' · ')||ev.device_key||'veículo';
  let body='';
  if(ev.event_type==='overspeed')body=`O sistema detectou excesso de velocidade em ${who}. ${ev.details||''}`;
  else if(ev.event_type==='unplanned_stop')body=`Detectei uma parada fora dos pontos planejados em ${who}. ${ev.details||''}`;
  else if(ev.event_type==='idle')body=`O sistema detectou ${who} parado com a ignição ligada além do tempo configurado. ${ev.details||''}`;
  else body=`Detectei um evento que precisa de atenção em ${who}: ${ev.title||'evento operacional'}. ${ev.details||''}`;
  const msg=`${body}\nHorário: ${brDate(ev.occurred_at)}`;
  await sendSaraResponse(chat,msg,{proactive:true,proactiveImportant:true,operational:true,alert:true,textAnchor:true,complementVoice:true});await saveConversation(chat,'out','alert',msg,`fleet_${ev.event_type||'event'}`);return {ok:true};
}

async function resolveAmbiguous(entity){const v=await findTrackedEntity(entity);return v?'vehicle_location':'place_location'}
async function handleMessage(message){
  const {chat}=tgConfig();const chatId=String(message.chat?.id||'');if(!chatId||chatId!==String(chat))return;
  const stopTyping=keepChatAction(chatId,'typing');let ctx=null;
  try{
    let text=String(message.text||message.caption||'').trim(),audio=null,inputType='text';
    if(message.voice||message.audio){
      const f=message.voice||message.audio;
      audio={data:await downloadTelegramFile(f.file_id),mimeType:f.mime_type||'audio/ogg',duration:Number(f.duration||0)};inputType='voice';
    }
    const explicitVoice=wantsVoice(text);const intentText=explicitVoice?stripVoiceDirective(text):text;let intent=intentText?quickIntent(intentText):null;if(intent?.intent==='locate_ambiguous')intent.intent=await resolveAmbiguous(intent.entity);
    if(!intent){const g=await classifyWithAI({text:intentText,audio,chatId});intent=g;text=g.transcript||text||'[áudio]'}
    if(intent?.intent==='locate_ambiguous')intent.intent=await resolveAmbiguous(intent.entity);
    const convoState=await conversationState(chatId);
    const userGreeting=/^(oi|ola|bom dia|boa tarde|boa noite|e ai|opa)(\s+(sara|sarah))?[!,.? ]*$/.test(normalize(text));
    await saveConversation(chatId,'in',inputType,text,intent.intent||null);const reportIntents=new Set(['vehicle_day_report','fleet_day_report','fleet_status','today_summary','usage_report']);const metricIntents=new Set(['vehicle_max_speed','fleet_max_speed']);const locationIntents=new Set(['vehicle_location','place_location']);
    ctx={inputType,explicitVoice,intent:intent.intent,operational:!['general_chat'].includes(intent.intent),report:reportIntents.has(intent.intent),metric:metricIntents.has(intent.intent),location:locationIntents.has(intent.intent),usage:intent.intent==='usage_report',textAnchor:reportIntents.has(intent.intent)||metricIntents.has(intent.intent)||locationIntents.has(intent.intent),alert:false,stopTyping,conversationState:convoState,userGreeting};
    switch(intent.intent){
      case'vehicle_location':return answerVehicleLocation(chatId,String(intent.entity||'').trim(),ctx);
      case'place_location':return answerPlaceLocation(chatId,String(intent.entity||'').trim(),ctx);
      case'fleet_status':return answerFleetStatus(chatId,ctx);
      case'today_summary':return answerTodaySummary(chatId,ctx);
      case'vehicle_max_speed':return answerVehicleMaxSpeed(chatId,String(intent.entity||'').trim(),parseRequestedDate(text)||intent.date||todayBR(),ctx);
      case'fleet_max_speed':return answerFleetMaxSpeed(chatId,parseRequestedDate(text)||intent.date||todayBR(),ctx);
      case'vehicle_day_report':return answerVehicleDayReport(chatId,String(intent.entity||'').trim(),parseRequestedDate(text)||intent.date||todayBR(),ctx);
      case'fleet_day_report':return answerFleetDayReport(chatId,parseRequestedDate(text)||intent.date||todayBR(),ctx);
      case'create_watch':return createWatch(chatId,intent.condition||'online',intent.entity,ctx);
      case'list_watches':return listWatches(chatId,ctx);
      case'cancel_watches':return cancelWatches(chatId,ctx);
      case'usage_report':return answerUsageReport(chatId,ctx);
      case'help':return answerHelp(chatId,ctx);
      case'general_chat':{const reply=String(intent.reply||'').trim()||localPersonaReply(text);await sendSaraResponse(chatId,reply,{...ctx,operational:false});await saveConversation(chatId,'out','text',reply,'general_chat');return}
      default:return answerHelp(chatId,ctx);
    }
  }catch(e){
    stopTyping();console.error('Sarah handle message:',e);
    const messageText=/áudio|audio/i.test(String(e.message||''))?`Não consegui processar o áudio agora: ${e.message}`:'Tive um problema ao consultar os dados da A7W. A operação continua intacta; tente novamente em alguns instantes.';
    if(ctx)await sendSaraResponse(chatId,messageText,ctx);else await sendText(chatId,messageText);
  }
}

router.post('/webhook',(req,res)=>{const expected=webhookSecret(),received=String(req.get('x-telegram-bot-api-secret-token')||'');if(!received||received!==expected)return res.status(401).json({ok:false});const update=req.body||{};res.json({ok:true});setImmediate(()=>{const msg=update.message||update.edited_message;if(msg)handleMessage(msg).catch(e=>console.error('Sarah webhook:',e))})});

async function assistantStatus(baseUrl){const g=geminiConfig(),q=groqConfig(),d=deepseekConfig(),f=fishConfig(),t=tgConfig();let webhook={ok:false};if(t.token){const w=await tgApi('getWebhookInfo');if(w.ok){const current=w.result?.url||'';webhook={ok:true,url:current,active:!!current,expected_url:baseUrl?`${String(baseUrl).replace(/\/$/,'')}/api/telegram/webhook`:null,pending:Number(w.result?.pending_update_count||0),last_error:w.result?.last_error_message||null}}else webhook={ok:false,error:w.description||'Falha ao consultar webhook'}}let watches=0;try{const [[x]]=await pool.execute(`SELECT COUNT(*) n FROM platform_sara_watches WHERE chat_id=? AND status='active'`,[String(t.chat||'')]);watches=Number(x.n||0)}catch(_){}const voice=await getSaraSettings(),usage=await usageSummary();const providers=['local'];if(g.key)providers.push('gemini');if(q.key)providers.push('groq');if(d.key&&deepseekEnabled())providers.push('deepseek');const fishReady=!!(f.enabled&&f.key&&f.voiceId);return {gemini_configured:!!g.key,groq_configured:!!q.key,deepseek_configured:!!(d.key&&deepseekEnabled()),fish_configured:fishReady,fish_model:f.model,fish_voice_id:f.voiceId?`${f.voiceId.slice(0,6)}…${f.voiceId.slice(-4)}`:null,model:g.model,groq_model:q.model,deepseek_model:d.model,ai_mode:providers.join(' → '),telegram_configured:!!(t.token&&t.chat),webhook,active_watches:watches,voice:{configured:fishReady||!!g.key,provider:fishReady?'fish':'gemini',enabled:voice.voice_enabled,policy:voice.voice_policy,audio_percent:voice.voice_audio_percent,name:fishReady?'Sarah Rodrigues':voice.voice_name,model:fishReady?f.model:voice.voice_model,fallback_model:fishReady&&g.key?voice.voice_model:null},usage}}

async function setupWebhook(baseUrl){const t=tgConfig();if(!t.token||!t.chat)return {ok:false,error:'Telegram não configurado.'};const url=`${String(baseUrl||'').replace(/\/$/,'')}/api/telegram/webhook`;if(!/^https:\/\//i.test(url))return {ok:false,error:'URL pública HTTPS inválida.'};const r=await tgApi('setWebhook',{url,secret_token:webhookSecret(),allowed_updates:['message'],drop_pending_updates:false});if(!r.ok)return {ok:false,error:r.description||'Falha ao ativar webhook.'};return {ok:true,url}}
async function testGemini(){const r=await geminiRequest([{text:'Responda somente com a frase: Sarah pronta.'}],{json:false,maxOutputTokens:256,thinkingLevel:'low',purpose:'brain_test'});if(r.ok)return {ok:true,model:r.model,response:r.text,provider:'gemini'};const q=await groqChatRequest('Responda somente com a frase: Sarah pronta.',{json:false,maxOutputTokens:80,purpose:'brain_test'});if(q.ok)return {ok:true,model:q.model,response:q.text,provider:'groq',fallback:true};const d=await deepseekChatRequest('Responda somente com a frase: Sarah pronta.',{json:false,maxOutputTokens:80,purpose:'brain_test'});return d.ok?{ok:true,model:d.model,response:d.text,provider:'deepseek',fallback:true}:{ok:false,error:`Gemini: ${r.error}; Groq: ${q.error}; DeepSeek: ${d.error}`}}

module.exports={router,assistantStatus,setupWebhook,testGemini,testVoice,getSaraSettings,updateSaraSettings,usageSummary,sendSaraFleetAlert};
