const express=require('express');
const crypto=require('crypto');
const {pool}=require('../db');
const router=express.Router();

function clean(v,max=180){return String(v??'').trim().slice(0,max)}
function num(v){if(v===undefined||v===null||v==='')return null;const n=Number(v);return Number.isFinite(n)?n:null}
function safeEq(a,b){a=Buffer.from(String(a||''));b=Buffer.from(String(b||''));if(a.length!==b.length)return false;return crypto.timingSafeEqual(a,b)}
function auth(req,res,next){
  const expected=String(process.env.TRACKING_DEVICE_TOKEN||'').trim();
  if(!expected)return res.status(503).json({ok:false,error:'TRACKING_NOT_CONFIGURED'});
  const token=req.get('x-device-token')||req.query.token||req.body?.token;
  if(!safeEq(token,expected))return res.status(401).json({ok:false,error:'INVALID_DEVICE_TOKEN'});
  next();
}
function toMysqlDate(v){
  if(v===undefined||v===null||v==='')return new Date().toISOString().slice(0,19).replace('T',' ');
  let d;
  if(/^\d+$/.test(String(v))){let n=Number(v);if(n<1e12)n*=1000;d=new Date(n)}else d=new Date(String(v));
  if(Number.isNaN(d.getTime()))d=new Date();
  return d.toISOString().slice(0,19).replace('T',' ');
}
function speedKmh(v){
  const n=num(v);if(n===null)return null;
  const unit=String(process.env.OSMAND_SPEED_UNIT||'knots').toLowerCase();
  if(unit==='kmh'||unit==='kph')return n;
  if(unit==='mps'||unit==='ms')return n*3.6;
  if(unit==='mph')return n*1.609344;
  return n*1.852; // Traccar Client / OsmAnd default: knots
}
async function save(payload,source='osmand'){
  const deviceKey=clean(payload.device_key||payload.device_id||payload.deviceid||payload.id,160);
  let lat=num(payload.latitude??payload.lat),lon=num(payload.longitude??payload.lon??payload.lng);
  if((lat===null||lon===null)&&payload.location){const [a,b]=String(payload.location).split(',');lat=lat??num(a);lon=lon??num(b)}
  if(!deviceKey)throw new Error('device_id/id obrigatorio');
  if(lat===null||lon===null||lat<-90||lat>90||lon<-180||lon>180)throw new Error('latitude/longitude invalidas');
  const accuracy=num(payload.accuracy),battery=num(payload.battery??payload.batt),altitude=num(payload.altitude??payload.alt),bearing=num(payload.bearing??payload.heading),speed=speedKmh(payload.speed);
  const ignitionRaw=payload.ignition??payload.attributes?.ignition;
  const ignition=ignitionRaw===undefined||ignitionRaw===null||ignitionRaw===''?null:(String(ignitionRaw).toLowerCase()==='true'||Number(ignitionRaw)===1?1:0);
  const fuelLevel=num(payload.fuel_level??payload.fuel??payload.attributes?.fuel);
  const odometerKm=num(payload.odometer_km??payload.odometer??payload.attributes?.totalDistance);
  const recordedAt=toMysqlDate(payload.recorded_at??payload.timestamp??payload.time);
  const [r]=await pool.execute(`INSERT INTO platform_location_points(device_key,latitude,longitude,accuracy,speed_kmh,battery,altitude,bearing,ignition,fuel_level,odometer_km,source,recorded_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)`,[deviceKey,lat,lon,accuracy,speed,battery,altitude,bearing,ignition,fuelLevel,odometerKm,source,recordedAt]);
  await pool.execute(`INSERT INTO platform_tracking_devices(device_key,label,last_lat,last_lon,last_speed,battery,last_seen_at) VALUES(?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE last_lat=VALUES(last_lat),last_lon=VALUES(last_lon),last_speed=VALUES(last_speed),battery=VALUES(battery),last_seen_at=VALUES(last_seen_at)`,[deviceKey,deviceKey,lat,lon,speed,battery,recordedAt]);
  return {id:r.insertId,device_key:deviceKey,latitude:lat,longitude:lon,speed_kmh:speed,battery,recorded_at:recordedAt};
}
async function handler(req,res){try{const payload={...req.query,...(req.body||{})};const saved=await save(payload,'osmand');if(String(process.env.TRACKING_INGEST_DEBUG||'').toLowerCase()==='true')console.log(`Tracking ingest OK: device=${saved.device_key}`);res.json({ok:true,saved})}catch(e){console.error('Tracking ingest:',e.message);res.status(400).json({ok:false,error:e.message})}}
router.get('/osmand',auth,handler);
router.post('/osmand',auth,handler);
router.post('/location',auth,async(req,res)=>{try{const saved=await save(req.body||{},'json');if(String(process.env.TRACKING_INGEST_DEBUG||'').toLowerCase()==='true')console.log(`Tracking ingest OK: device=${saved.device_key}`);res.json({ok:true,saved})}catch(e){console.error('Tracking ingest:',e.message);res.status(400).json({ok:false,error:e.message})}});
module.exports=router;
