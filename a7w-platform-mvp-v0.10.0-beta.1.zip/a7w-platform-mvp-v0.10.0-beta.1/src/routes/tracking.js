const express=require('express');
const {pool}=require('../db');
const {requireRole}=require('../security');
const {audit,cleanText}=require('../helpers');
const {assistantStatus,setupWebhook,testGemini,testVoice,getSaraSettings,updateSaraSettings,usageSummary,sendSaraFleetAlert}=require('./telegram-assistant');
const router=express.Router();
router.use(requireRole('admin','manager'));

const cache=new Map();
function clamp(n,a,b){return Math.min(Math.max(n,a),b)}
function validDate(v){return /^\d{4}-\d{2}-\d{2}$/.test(String(v||''))}
function hav(a,b,c,d){const R=6371000,toRad=x=>x*Math.PI/180;const p1=toRad(a),p2=toRad(c),dp=toRad(c-a),dl=toRad(d-b);const x=Math.sin(dp/2)**2+Math.cos(p1)*Math.cos(p2)*Math.sin(dl/2)**2;return 2*R*Math.atan2(Math.sqrt(x),Math.sqrt(1-x))}
function sqlRange(date){const start=new Date(`${date}T00:00:00-03:00`),end=new Date(start.getTime()+24*60*60*1000-1000);const f=d=>d.toISOString().slice(0,19).replace('T',' ');return [f(start),f(end)]}
function median(nums){if(!nums.length)return 0;const a=[...nums].sort((x,y)=>x-y),m=Math.floor(a.length/2);return a.length%2?a[m]:(a[m-1]+a[m])/2}

function normText(v){return String(v||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9 ]+/g,' ').replace(/\s+/g,' ').trim()}
function levenshtein(a,b){a=normText(a);b=normText(b);if(!a)return b.length;if(!b)return a.length;const prev=Array.from({length:b.length+1},(_,i)=>i),cur=new Array(b.length+1);for(let i=1;i<=a.length;i++){cur[0]=i;for(let j=1;j<=b.length;j++)cur[j]=Math.min(cur[j-1]+1,prev[j]+1,prev[j-1]+(a[i-1]===b[j-1]?0:1));for(let j=0;j<=b.length;j++)prev[j]=cur[j]}return prev[b.length]}
function fuzzyScore(q,...parts){const nq=normText(q),text=normText(parts.filter(Boolean).join(' '));if(!nq||!text)return 999;if(text.includes(nq))return 0;const tokens=text.split(' ').filter(Boolean);let best=999;for(const t of tokens){const d=levenshtein(nq,t);best=Math.min(best,d/Math.max(nq.length,t.length))}return best}
async function fleetSettings(){const [rows]=await pool.execute(`SELECT * FROM platform_fleet_settings WHERE id=1`);return rows[0]||{speed_limit_kmh:80,overspeed_min_seconds:120,stop_alert_minutes:8,delivery_radius_m:150,fuel_efficiency_km_l:10,idle_alert_minutes:5}}
const TELEGRAM_DISPLAY_NAME='Sarah Rodrigues';
function telegramConfig(){return {token:String(process.env.TELEGRAM_BOT_TOKEN||'').trim(),chat:String(process.env.TELEGRAM_CHAT_ID||'').trim()}}
async function saveTelegramStatus(patch={}){
  const current={status:'unknown',external_name:null,external_username:null,last_attempt_at:null,last_success_at:null,last_failure_at:null,last_error:null,last_message_preview:null,last_message_event_type:null};
  const [[row]] = await pool.execute(`SELECT * FROM platform_integration_status WHERE integration_key='telegram' LIMIT 1`).catch(()=>[[null]]);
  Object.assign(current,row||{},patch);
  await pool.execute(`INSERT INTO platform_integration_status(integration_key,status,external_name,external_username,last_attempt_at,last_success_at,last_failure_at,last_error,last_message_preview,last_message_event_type)
    VALUES('telegram',?,?,?,?,?,?,?,?,?)
    ON DUPLICATE KEY UPDATE status=VALUES(status),external_name=VALUES(external_name),external_username=VALUES(external_username),last_attempt_at=VALUES(last_attempt_at),last_success_at=VALUES(last_success_at),last_failure_at=VALUES(last_failure_at),last_error=VALUES(last_error),last_message_preview=VALUES(last_message_preview),last_message_event_type=VALUES(last_message_event_type)`,[
      current.status,current.external_name,current.external_username,current.last_attempt_at,current.last_success_at,current.last_failure_at,current.last_error,current.last_message_preview,current.last_message_event_type
    ]);
}
async function telegramApi(method,payload){
  const {token}=telegramConfig();if(!token)return {ok:false,description:'TELEGRAM_NOT_CONFIGURED'};
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),8000);
  try{
    const r=await fetch(`https://api.telegram.org/bot${token}/${method}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload||{}),signal:controller.signal});
    const body=await r.json().catch(()=>({ok:false,description:`HTTP ${r.status}`}));
    return {http_ok:r.ok,...body};
  }catch(e){return {ok:false,description:e.name==='AbortError'?'Tempo limite ao conectar com o Telegram':(e.message||'TELEGRAM_REQUEST_FAILED')}}finally{clearTimeout(timer)}
}
async function telegramProbe(){
  const {token,chat}=telegramConfig();
  if(!token||!chat){await saveTelegramStatus({status:'not_configured',last_error:null});return {configured:false,connected:false,status:'not_configured',display_name:TELEGRAM_DISPLAY_NAME}}
  const now=mysqlTime(new Date());
  const me=await telegramApi('getMe');
  if(!me.ok){await saveTelegramStatus({status:'error',last_attempt_at:now,last_failure_at:now,last_error:String(me.description||'Falha ao consultar o bot').slice(0,500)});return {configured:true,connected:false,status:'error',error:me.description||'Falha ao consultar o bot',display_name:TELEGRAM_DISPLAY_NAME}}
  const currentName=await telegramApi('getMyName',{});
  const botName=currentName.ok?currentName.result?.name:(me.result?.first_name||TELEGRAM_DISPLAY_NAME);
  const chatInfo=await telegramApi('getChat',{chat_id:chat});
  if(!chatInfo.ok){await saveTelegramStatus({status:'error',external_name:botName||TELEGRAM_DISPLAY_NAME,external_username:me.result?.username||null,last_attempt_at:now,last_failure_at:now,last_error:String(chatInfo.description||'Chat não acessível').slice(0,500)});return {configured:true,connected:false,status:'error',error:chatInfo.description||'Chat não acessível',display_name:TELEGRAM_DISPLAY_NAME,bot_name:botName||null,bot_username:me.result?.username||null}}
  await saveTelegramStatus({status:'connected',external_name:botName||TELEGRAM_DISPLAY_NAME,external_username:me.result?.username||null,last_attempt_at:now,last_error:null});
  return {configured:true,connected:true,status:'connected',display_name:TELEGRAM_DISPLAY_NAME,bot_name:botName||null,bot_username:me.result?.username||null,chat_type:chatInfo.result?.type||null};
}
async function telegramNotify(text,eventType='fleet_event'){
  const {token,chat}=telegramConfig();
  const now=mysqlTime(new Date());
  if(!token||!chat){await saveTelegramStatus({status:'not_configured',last_attempt_at:now,last_error:null});return {ok:false,error:'NOT_CONFIGURED'}}
  await saveTelegramStatus({last_attempt_at:now});
  const body=await telegramApi('sendMessage',{chat_id:chat,text,disable_web_page_preview:true});
  if(body.ok){await saveTelegramStatus({status:'connected',last_success_at:now,last_error:null,last_message_preview:String(text||'').replace(/\s+/g,' ').slice(0,300),last_message_event_type:eventType});return {ok:true,message_id:body.result?.message_id||null}}
  const err=String(body.description||'Falha ao enviar Telegram').slice(0,500);
  await saveTelegramStatus({status:'error',last_failure_at:now,last_error:err});return {ok:false,error:err};
}
function mysqlTime(v){const d=new Date(v);return Number.isNaN(d.getTime())?null:d.toISOString().slice(0,19).replace('T',' ')}
function telemetry(rows){
  if(!rows.length)return {distance_km:0,moving_minutes:0,stopped_minutes:0,gap_minutes:0,avg_moving_kmh:0,max_speed_kmh:0,points:0,stops:[]};
  let meters=0,moving=0,stopped=0,gap=0,max=0;const movingSpeeds=[],stops=[];let stopStart=null,stopPts=[];
  for(let i=0;i<rows.length;i++){
    const r=rows[i],speed=Number(r.speed_kmh||0);if(speed>=0&&speed<=220&&speed>max)max=speed;
    if(i===0)continue;const p=rows[i-1];let dt=(new Date(r.recorded_at)-new Date(p.recorded_at))/1000;if(!Number.isFinite(dt)||dt<=0)continue;
    const d=hav(Number(p.latitude),Number(p.longitude),Number(r.latitude),Number(r.longitude));
    const calcKmh=dt?d/dt*3.6:0;const movingNow=(speed>=4||calcKmh>=5)&&calcKmh<220;
    if(dt>900){gap+=dt; if(stopStart){const end=p;const dur=(new Date(end.recorded_at)-new Date(stopStart.recorded_at))/1000;if(dur>=300){stops.push({lat:median(stopPts.map(x=>Number(x.latitude))),lon:median(stopPts.map(x=>Number(x.longitude))),start:stopStart.recorded_at,end:end.recorded_at,duration_seconds:Math.round(dur)})}stopStart=null;stopPts=[]}continue}
    if(movingNow&&d>=3&&calcKmh<220&&(!p.accuracy||Number(p.accuracy)<150)&&(!r.accuracy||Number(r.accuracy)<150))meters+=d;
    if(movingNow){moving+=dt;movingSpeeds.push(speed||calcKmh);if(stopStart){const end=p;const dur=(new Date(end.recorded_at)-new Date(stopStart.recorded_at))/1000;if(dur>=300)stops.push({lat:median(stopPts.map(x=>Number(x.latitude))),lon:median(stopPts.map(x=>Number(x.longitude))),start:stopStart.recorded_at,end:end.recorded_at,duration_seconds:Math.round(dur)});stopStart=null;stopPts=[]}}
    else{stopped+=dt;if(!stopStart)stopStart=p;stopPts.push(p,r)}
  }
  if(stopStart){const end=rows[rows.length-1],dur=(new Date(end.recorded_at)-new Date(stopStart.recorded_at))/1000;if(dur>=300)stops.push({lat:median(stopPts.map(x=>Number(x.latitude))),lon:median(stopPts.map(x=>Number(x.longitude))),start:stopStart.recorded_at,end:end.recorded_at,duration_seconds:Math.round(dur)})}
  return {distance_km:Number((meters/1000).toFixed(2)),moving_minutes:Math.round(moving/60),stopped_minutes:Math.round(stopped/60),gap_minutes:Math.round(gap/60),avg_moving_kmh:Number((movingSpeeds.reduce((a,b)=>a+b,0)/(movingSpeeds.length||1)).toFixed(1)),max_speed_kmh:Number(max.toFixed(1)),points:rows.length,stops};
}

router.get('/diagnostics',async(req,res)=>{
  const [[d]]=await pool.execute(`SELECT COUNT(*) total, MAX(last_seen_at) last_seen FROM platform_tracking_devices`);
  const [[p]]=await pool.execute(`SELECT COUNT(*) total, MAX(recorded_at) last_recorded FROM platform_location_points`);
  const [last]=await pool.execute(`SELECT device_key,last_lat,last_lon,last_speed,battery,last_seen_at FROM platform_tracking_devices ORDER BY last_seen_at DESC,id DESC LIMIT 1`);
  res.json({ok:true,version:'0.9.5',tracking_token_configured:!!String(process.env.TRACKING_DEVICE_TOKEN||'').trim(),device_count:Number(d.total||0),point_count:Number(p.total||0),last_seen:d.last_seen||null,last_recorded:p.last_recorded||null,last_device:last[0]||null});
});

router.get('/devices',async(req,res)=>{
  const [rows]=await pool.execute(`SELECT td.id,td.device_key,td.label,td.last_lat,td.last_lon,td.last_speed,td.battery,td.last_seen_at,(SELECT lp.bearing FROM platform_location_points lp WHERE lp.device_key=td.device_key ORDER BY lp.recorded_at DESC,lp.id DESC LIMIT 1) last_bearing,a.vehicle_id,a.driver_id,v.name vehicle_name,v.plate,dr.name driver_name,dr.phone driver_phone FROM platform_tracking_devices td LEFT JOIN platform_assignments a ON a.tracking_device_id=td.id AND a.active=1 LEFT JOIN platform_vehicles v ON v.id=a.vehicle_id LEFT JOIN platform_drivers dr ON dr.id=a.driver_id ORDER BY COALESCE(v.name,td.label,td.device_key)`);
  res.json(rows.map(r=>({...r,online:r.last_seen_at?(Date.now()-new Date(r.last_seen_at).getTime())<5*60*1000:false})));
});
router.get('/history',async(req,res)=>{
  const key=cleanText(req.query.device_id,160);if(!key)return res.status(400).json({error:'DEVICE_REQUIRED'});const date=String(req.query.date||'');let q,params;
  if(validDate(date)){const [a,b]=sqlRange(date);q=`SELECT id,device_key,latitude,longitude,accuracy,speed_kmh,battery,altitude,bearing,ignition,fuel_level,odometer_km,recorded_at FROM platform_location_points WHERE device_key=? AND recorded_at BETWEEN ? AND ? ORDER BY recorded_at ASC LIMIT 20000`;params=[key,a,b]}
  else{const hours=clamp(parseInt(req.query.hours,10)||12,1,168);q=`SELECT id,device_key,latitude,longitude,accuracy,speed_kmh,battery,altitude,bearing,ignition,fuel_level,odometer_km,recorded_at FROM platform_location_points WHERE device_key=? AND recorded_at>=UTC_TIMESTAMP()-INTERVAL ${hours} HOUR ORDER BY recorded_at ASC LIMIT 10000`;params=[key]}
  const [rows]=await pool.execute(q,params);res.json(rows);
});
router.get('/metrics',async(req,res)=>{
  const key=cleanText(req.query.device_id,160),date=String(req.query.date||'');if(!key||!validDate(date))return res.status(400).json({error:'DEVICE_DATE_REQUIRED'});const [a,b]=sqlRange(date);const [rows]=await pool.execute(`SELECT latitude,longitude,accuracy,speed_kmh,bearing,battery,ignition,fuel_level,odometer_km,recorded_at FROM platform_location_points WHERE device_key=? AND recorded_at BETWEEN ? AND ? ORDER BY recorded_at ASC LIMIT 20000`,[key,a,b]);const t=telemetry(rows);const last=rows.at(-1)||null;res.json({...t,last});
});
router.get('/vehicles',async(req,res)=>{const [rows]=await pool.execute(`SELECT v.id,v.name,v.plate,a.driver_id,a.tracking_device_id,dr.name driver_name,dr.phone driver_phone,td.device_key,td.last_seen_at FROM platform_vehicles v LEFT JOIN platform_assignments a ON a.vehicle_id=v.id AND a.active=1 LEFT JOIN platform_drivers dr ON dr.id=a.driver_id LEFT JOIN platform_tracking_devices td ON td.id=a.tracking_device_id WHERE v.active=1 ORDER BY v.name`);res.json(rows)});
router.get('/fleet',async(req,res)=>{const [vehicles,drivers,devices,refs]=await Promise.all([
  pool.execute(`SELECT v.id,v.name,v.plate,v.active,a.driver_id,a.tracking_device_id,dr.name driver_name,td.device_key,td.last_seen_at FROM platform_vehicles v LEFT JOIN platform_assignments a ON a.vehicle_id=v.id AND a.active=1 LEFT JOIN platform_drivers dr ON dr.id=a.driver_id LEFT JOIN platform_tracking_devices td ON td.id=a.tracking_device_id ORDER BY v.active DESC,v.name`),
  pool.execute(`SELECT d.id,d.name,d.phone,d.active,a.vehicle_id,a.tracking_device_id,v.name vehicle_name,td.device_key FROM platform_drivers d LEFT JOIN platform_assignments a ON a.driver_id=d.id AND a.active=1 LEFT JOIN platform_vehicles v ON v.id=a.vehicle_id LEFT JOIN platform_tracking_devices td ON td.id=a.tracking_device_id ORDER BY d.active DESC,d.name`),
  pool.execute(`SELECT td.id,td.device_key,td.label,td.last_lat,td.last_lon,td.last_speed,td.battery,td.last_seen_at,a.vehicle_id,a.driver_id,v.name vehicle_name,dr.name driver_name FROM platform_tracking_devices td LEFT JOIN platform_assignments a ON a.tracking_device_id=td.id AND a.active=1 LEFT JOIN platform_vehicles v ON v.id=a.vehicle_id LEFT JOIN platform_drivers dr ON dr.id=a.driver_id ORDER BY td.last_seen_at DESC,td.device_key`),
  pool.execute(`SELECT * FROM platform_reference_points ORDER BY is_primary DESC,name`)
]);res.json({vehicles:vehicles[0],drivers:drivers[0],devices:devices[0],references:refs[0]})});
router.post('/drivers',async(req,res)=>{const name=cleanText(req.body.name,160),phone=cleanText(req.body.phone,30);if(!name)return res.status(400).json({error:'INVALID_DRIVER'});const [r]=await pool.execute(`INSERT INTO platform_drivers(name,phone,active) VALUES(?,?,1)`,[name,phone||null]);await audit(req,'driver.created','driver',r.insertId,{name});res.json({ok:true,id:r.insertId})});
router.post('/vehicles',async(req,res)=>{const name=cleanText(req.body.name,120),plate=cleanText(req.body.plate,20).toUpperCase();if(!name)return res.status(400).json({error:'INVALID_VEHICLE'});const [r]=await pool.execute(`INSERT INTO platform_vehicles(name,plate,active) VALUES(?,?,1)`,[name,plate||null]);await audit(req,'vehicle.created','vehicle',r.insertId,{name,plate});res.json({ok:true,id:r.insertId})});
router.post('/assignments',async(req,res)=>{const vehicle=Number(req.body.vehicle_id||0),driver=Number(req.body.driver_id||0),device=Number(req.body.tracking_device_id||0);if(!vehicle||!driver||!device)return res.status(400).json({error:'INVALID_ASSIGNMENT'});const conn=await pool.getConnection();try{await conn.beginTransaction();await conn.execute(`UPDATE platform_assignments SET active=0 WHERE active=1 AND (vehicle_id=? OR driver_id=? OR tracking_device_id=?)`,[vehicle,driver,device]);const [r]=await conn.execute(`INSERT INTO platform_assignments(driver_id,vehicle_id,tracking_device_id,active) VALUES(?,?,?,1)`,[driver,vehicle,device]);await conn.commit();await audit(req,'fleet.assigned','assignment',r.insertId,{vehicle,driver,device});res.json({ok:true,id:r.insertId})}catch(e){await conn.rollback();throw e}finally{conn.release()}});
router.get('/references',async(req,res)=>{const [rows]=await pool.execute(`SELECT * FROM platform_reference_points ORDER BY is_primary DESC,name`);res.json(rows)});
router.post('/references',async(req,res)=>{const name=cleanText(req.body.name,160),address=cleanText(req.body.address,320),lat=Number(req.body.latitude),lon=Number(req.body.longitude),type=['company','warehouse','client','maintenance','fuel','reference'].includes(req.body.type)?req.body.type:'reference',primary=!!req.body.is_primary;if(!name||!Number.isFinite(lat)||!Number.isFinite(lon))return res.status(400).json({error:'INVALID_REFERENCE'});const conn=await pool.getConnection();try{await conn.beginTransaction();if(primary)await conn.execute(`UPDATE platform_reference_points SET is_primary=0`);const [r]=await conn.execute(`INSERT INTO platform_reference_points(name,address,latitude,longitude,type,is_primary,created_by_user_id) VALUES(?,?,?,?,?,?,?)`,[name,address||null,lat,lon,type,primary?1:0,req.session.user.id]);await conn.commit();await audit(req,'reference.created','reference',r.insertId,{name,type,primary});res.json({ok:true,id:r.insertId})}catch(e){await conn.rollback();throw e}finally{conn.release()}});
router.delete('/references/:id',async(req,res)=>{const id=Number(req.params.id);await pool.execute(`DELETE FROM platform_reference_points WHERE id=?`,[id]);await audit(req,'reference.deleted','reference',id);res.json({ok:true})});

router.get('/route-stops',async(req,res)=>{
  const vehicle=Number(req.query.vehicle_id||0),date=String(req.query.date||'');
  if(!validDate(date))return res.status(400).json({error:'DATE_REQUIRED'});
  let rows;
  if(vehicle){[rows]=await pool.execute(`SELECT * FROM platform_route_stops WHERE vehicle_id=? AND route_date=? ORDER BY sequence_no,id`,[vehicle,date])}
  else{[rows]=await pool.execute(`SELECT * FROM platform_route_stops WHERE vehicle_id IS NULL AND route_date=? AND created_by_user_id=? ORDER BY sequence_no,id`,[date,req.session.user.id])}
  res.json(rows);
});
router.post('/route-stops',async(req,res)=>{
  const vehicle=Number(req.body.vehicle_id||0)||null,date=String(req.body.route_date||''),name=cleanText(req.body.name,180),address=cleanText(req.body.address,320),lat=Number(req.body.latitude),lon=Number(req.body.longitude);
  if(!validDate(date)||!name||!Number.isFinite(lat)||!Number.isFinite(lon))return res.status(400).json({error:'INVALID_ROUTE_STOP'});
  let mx;
  if(vehicle)[[mx]]=await pool.execute(`SELECT COALESCE(MAX(sequence_no),0) n FROM platform_route_stops WHERE vehicle_id=? AND route_date=?`,[vehicle,date]);
  else [[mx]]=await pool.execute(`SELECT COALESCE(MAX(sequence_no),0) n FROM platform_route_stops WHERE vehicle_id IS NULL AND route_date=? AND created_by_user_id=?`,[date,req.session.user.id]);
  const [r]=await pool.execute(`INSERT INTO platform_route_stops(route_date,vehicle_id,sequence_no,name,address,latitude,longitude,source,external_id,created_by_user_id) VALUES(?,?,?,?,?,?,?,?,?,?)`,[date,vehicle,Number(mx.n)+1,name,address||null,lat,lon,cleanText(req.body.source,40)||'search',cleanText(req.body.external_id,180)||null,req.session.user.id]);
  await audit(req,'route_stop.created','route_stop',r.insertId,{vehicle,date,name});res.json({ok:true,id:r.insertId,draft:!vehicle});
});
router.post('/route-stops/assign',async(req,res)=>{
  const vehicle=Number(req.body.vehicle_id||0),date=String(req.body.route_date||'');
  if(!vehicle||!validDate(date))return res.status(400).json({error:'VEHICLE_DATE_REQUIRED'});
  const [[mx]]=await pool.execute(`SELECT COALESCE(MAX(sequence_no),0) n FROM platform_route_stops WHERE vehicle_id=? AND route_date=?`,[vehicle,date]);
  const [drafts]=await pool.execute(`SELECT id FROM platform_route_stops WHERE vehicle_id IS NULL AND route_date=? AND created_by_user_id=? ORDER BY sequence_no,id`,[date,req.session.user.id]);
  for(let i=0;i<drafts.length;i++)await pool.execute(`UPDATE platform_route_stops SET vehicle_id=?,sequence_no=? WHERE id=?`,[vehicle,Number(mx.n)+i+1,drafts[i].id]);
  await audit(req,'route.assigned','route',String(vehicle),{date,stops:drafts.length});res.json({ok:true,assigned:drafts.length});
});
router.delete('/route-stops/:id',async(req,res)=>{const id=Number(req.params.id);await pool.execute(`DELETE FROM platform_route_stops WHERE id=?`,[id]);await audit(req,'route_stop.deleted','route_stop',id);res.json({ok:true})});
router.put('/route-stops/order',async(req,res)=>{const ids=Array.isArray(req.body.ids)?req.body.ids.map(Number).filter(Boolean):[];if(!ids.length)return res.status(400).json({error:'INVALID_ORDER'});const conn=await pool.getConnection();try{await conn.beginTransaction();for(let i=0;i<ids.length;i++)await conn.execute(`UPDATE platform_route_stops SET sequence_no=? WHERE id=?`,[i+1,ids[i]]);await conn.commit();res.json({ok:true})}catch(e){await conn.rollback();throw e}finally{conn.release()}});


router.post('/route-shape',async(req,res)=>{
  const points=Array.isArray(req.body.points)?req.body.points.map(p=>({lat:Number(p.lat),lon:Number(p.lon)})).filter(p=>Number.isFinite(p.lat)&&Number.isFinite(p.lon)):[];
  if(points.length<2)return res.status(400).json({error:'ROUTE_POINTS_REQUIRED'});
  if(points.length>25)return res.status(400).json({error:'ROUTE_POINT_LIMIT',message:'A prévia viária atual aceita até 25 paradas por cálculo.'});
  const key=String(process.env.LOCATIONIQ_TOKEN||'').trim();
  if(!key)return res.status(503).json({error:'ROUTING_NOT_CONFIGURED'});
  const ck='route:'+points.map(p=>`${p.lat.toFixed(5)},${p.lon.toFixed(5)}`).join('|'),hit=cache.get(ck);
  if(hit&&Date.now()-hit.t<10*60*1000)return res.json(hit.data);
  try{
    const coords=points.map(p=>`${p.lon},${p.lat}`).join(';');
    const u=new URL(`https://us1.locationiq.com/v1/directions/driving/${coords}`);
    u.searchParams.set('key',key);u.searchParams.set('overview','full');u.searchParams.set('geometries','geojson');u.searchParams.set('steps','false');u.searchParams.set('alternatives','false');
    const r=await fetch(u,{headers:{Accept:'application/json','User-Agent':'A7W-Platform/0.9.5'}});const b=await r.json().catch(()=>({}));
    if(!r.ok||!Array.isArray(b.routes)||!b.routes[0])throw new Error(b.message||b.error||'Roteirização indisponível');
    const route=b.routes[0],geometry=(route.geometry?.coordinates||[]).map(c=>[Number(c[1]),Number(c[0])]).filter(c=>Number.isFinite(c[0])&&Number.isFinite(c[1]));
    const data={provider:'locationiq',geometry,distance_m:Number(route.distance||0),duration_s:Number(route.duration||0)};cache.set(ck,{t:Date.now(),data});res.json(data)
  }catch(e){res.status(502).json({error:'ROUTING_FAILED',message:e.message})}
});

async function googlePlaces(q){const key=String(process.env.GOOGLE_MAPS_SERVER_KEY||'').trim();if(!key)return null;const r=await fetch('https://places.googleapis.com/v1/places:searchText',{method:'POST',headers:{'Content-Type':'application/json','X-Goog-Api-Key':key,'X-Goog-FieldMask':'places.id,places.displayName,places.formattedAddress,places.location'},body:JSON.stringify({textQuery:q,languageCode:'pt-BR',regionCode:'BR',pageSize:6})});const b=await r.json().catch(()=>({}));if(!r.ok)throw new Error(b.error?.message||'Google Places indisponível');return (b.places||[]).map(p=>({id:p.id,name:p.displayName?.text||q,address:p.formattedAddress||'',lat:Number(p.location?.latitude),lon:Number(p.location?.longitude),source:'google'})).filter(x=>Number.isFinite(x.lat)&&Number.isFinite(x.lon))}
async function locationIq(q){const key=String(process.env.LOCATIONIQ_TOKEN||'').trim();if(!key)return null;const u=new URL('https://us1.locationiq.com/v1/search');u.searchParams.set('key',key);u.searchParams.set('q',q);u.searchParams.set('format','json');u.searchParams.set('limit','6');u.searchParams.set('countrycodes','br');u.searchParams.set('accept-language','pt-BR');const r=await fetch(u,{headers:{Accept:'application/json'}});const b=await r.json().catch(()=>[]);if(!r.ok)throw new Error(b.error||'LocationIQ indisponível');return (Array.isArray(b)?b:[]).map(x=>({id:String(x.place_id||''),name:x.display_name?.split(',')[0]||q,address:x.display_name||'',lat:Number(x.lat),lon:Number(x.lon),source:'locationiq'})).filter(x=>Number.isFinite(x.lat)&&Number.isFinite(x.lon))}
async function nominatim(q){const u=new URL('https://nominatim.openstreetmap.org/search');u.searchParams.set('q',q);u.searchParams.set('format','jsonv2');u.searchParams.set('limit','6');u.searchParams.set('countrycodes','br');u.searchParams.set('addressdetails','1');const r=await fetch(u,{headers:{Accept:'application/json','Accept-Language':'pt-BR','User-Agent':'A7W-Platform/0.7 beta.a7w.com.br'}});const b=await r.json().catch(()=>[]);if(!r.ok)throw new Error('Busca OSM indisponível');return (Array.isArray(b)?b:[]).map(x=>({id:String(x.place_id||''),name:x.name||x.display_name?.split(',')[0]||q,address:x.display_name||'',lat:Number(x.lat),lon:Number(x.lon),source:'osm'})).filter(x=>Number.isFinite(x.lat)&&Number.isFinite(x.lon))}
router.get('/search',async(req,res)=>{const q=cleanText(req.query.q,180);if(q.length<3)return res.status(400).json({error:'SEARCH_TOO_SHORT'});const ck=normText(q),hit=cache.get(ck);if(hit&&Date.now()-hit.t<5*60*1000)return res.json(hit.data);try{
  const [allRefs]=await pool.execute(`SELECT id,name,address,latitude,longitude,is_primary,type FROM platform_reference_points ORDER BY is_primary DESC,name LIMIT 300`);
  const refs=allRefs.map(x=>({...x,score:fuzzyScore(q,x.name,x.address)})).filter(x=>x.score<=0.46||normText(x.name).includes(ck)||normText(x.address).includes(ck)).sort((a,b)=>Number(b.is_primary)-Number(a.is_primary)||a.score-b.score).slice(0,5).map(x=>({id:`reference:${x.id}`,name:x.name,address:x.address||'Ponto A7W',lat:Number(x.latitude),lon:Number(x.longitude),source:'a7w'}));
  const [companies]=await pool.execute(`SELECT c.id,c.trade_name,c.legal_name,d.address,d.lat,d.lon,d.id delivery_id FROM platform_companies c LEFT JOIN platform_orders o ON o.company_id=c.id LEFT JOIN platform_deliveries d ON d.order_id=o.id WHERE c.status<>'rejected' ORDER BY d.id DESC LIMIT 1200`);
  const byCompany=new Map();for(const x of companies){if(!byCompany.has(x.id)||(!Number.isFinite(Number(byCompany.get(x.id).lat))&&Number.isFinite(Number(x.lat))))byCompany.set(x.id,x)}
  const companyMatches=[...byCompany.values()].map(x=>({...x,score:fuzzyScore(q,x.trade_name,x.legal_name,x.address)})).filter(x=>x.score<=0.46||normText(x.trade_name).includes(ck)||normText(x.legal_name).includes(ck)||normText(x.address).includes(ck)).sort((a,b)=>a.score-b.score).slice(0,5).map(x=>{const lat=Number(x.lat),lon=Number(x.lon),ok=Number.isFinite(lat)&&Number.isFinite(lon);return {id:`company:${x.id}`,name:x.trade_name||x.legal_name,address:x.address||'Cliente A7W · localização ainda não cadastrada',lat:ok?lat:null,lon:ok?lon:null,source:ok?'a7w_client':'a7w_company_pending',missing_location:!ok}});
  const [savedStops]=await pool.execute(`SELECT id,name,address,latitude,longitude,created_at FROM platform_route_stops ORDER BY id DESC LIMIT 400`);
  const saved=savedStops.map(x=>({...x,score:fuzzyScore(q,x.name,x.address)})).filter(x=>x.score<=0.40||normText(x.name).includes(ck)||normText(x.address).includes(ck)).sort((a,b)=>a.score-b.score).slice(0,4).map(x=>({id:`saved:${x.id}`,name:x.name,address:x.address||'Destino já utilizado',lat:Number(x.latitude),lon:Number(x.longitude),source:'a7w_client'}));
  const external=await googlePlaces(q)||await locationIq(q)||await nominatim(q)||[];
  const seen=new Set(),data=[];for(const x of [...refs,...companyMatches,...saved,...external]){const coord=Number.isFinite(Number(x.lat))&&Number.isFinite(Number(x.lon))?`${Number(x.lat).toFixed(4)}|${Number(x.lon).toFixed(4)}`:'pending';const k=`${normText(x.name)}|${coord}`;if(seen.has(k))continue;seen.add(k);data.push(x);if(data.length>=12)break}
  cache.set(ck,{t:Date.now(),data});res.json(data)
}catch(e){res.status(502).json({error:'SEARCH_FAILED',message:e.message})}});


router.get('/operations-summary',async(req,res)=>{const date=String(req.query.date||'');if(!validDate(date))return res.status(400).json({error:'INVALID_DATE'});const [[d]]=await pool.execute(`SELECT COUNT(*) activities,SUM(status='delivered') completed,SUM(status='failed') failed,SUM(status NOT IN ('delivered','failed')) waiting,COUNT(DISTINCT CASE WHEN vehicle_id IS NOT NULL THEN vehicle_id END) delivery_routes FROM platform_deliveries WHERE DATE(COALESCE(planned_at,created_at))=?`,[date]);const [[p]]=await pool.execute(`SELECT COUNT(*) planned_stops,COUNT(DISTINCT COALESCE(vehicle_id,0)) planned_routes FROM platform_route_stops WHERE route_date=?`,[date]);const [routes]=await pool.execute(`SELECT v.id vehicle_id,v.name vehicle_name,v.plate,dr.name driver_name,COUNT(d.id) activities,SUM(d.status='delivered') completed,SUM(d.status='failed') failed,SUM(d.status NOT IN ('delivered','failed')) waiting FROM platform_deliveries d LEFT JOIN platform_vehicles v ON v.id=d.vehicle_id LEFT JOIN platform_drivers dr ON dr.id=d.driver_id WHERE DATE(COALESCE(d.planned_at,d.created_at))=? GROUP BY v.id,v.name,v.plate,dr.name ORDER BY v.name`,[date]);const [planned]=await pool.execute(`SELECT v.id vehicle_id,v.name vehicle_name,v.plate,dr.name driver_name,COUNT(rs.id) planned_stops FROM platform_route_stops rs JOIN platform_vehicles v ON v.id=rs.vehicle_id LEFT JOIN platform_assignments a ON a.vehicle_id=v.id AND a.active=1 LEFT JOIN platform_drivers dr ON dr.id=a.driver_id WHERE rs.route_date=? GROUP BY v.id,v.name,v.plate,dr.name ORDER BY v.name`,[date]);res.json({date,routes:Math.max(Number(d.delivery_routes||0),Number(p.planned_routes||0)),activities:Math.max(Number(d.activities||0),Number(p.planned_stops||0)),completed:Number(d.completed||0),failed:Number(d.failed||0),waiting:Number(d.waiting||0),route_rows:routes.length?routes:planned.map(x=>({...x,activities:Number(x.planned_stops||0),completed:0,failed:0,waiting:Number(x.planned_stops||0)}))})});

router.get('/report-summary',async(req,res)=>{const start=String(req.query.start||''),end=String(req.query.end||'');if(!validDate(start)||!validDate(end))return res.status(400).json({error:'INVALID_PERIOD'});const [a]=sqlRange(start),[,b]=sqlRange(end);const [devices]=await pool.execute(`SELECT DISTINCT device_key FROM platform_location_points WHERE recorded_at BETWEEN ? AND ?`,[a,b]);let km=0,moving=0,stopped=0,max=0,points=0,stops=0;for(const d of devices){const [rows]=await pool.execute(`SELECT latitude,longitude,accuracy,speed_kmh,bearing,battery,ignition,fuel_level,odometer_km,recorded_at FROM platform_location_points WHERE device_key=? AND recorded_at BETWEEN ? AND ? ORDER BY recorded_at ASC LIMIT 100000`,[d.device_key,a,b]);const t=telemetry(rows);km+=t.distance_km;moving+=t.moving_minutes;stopped+=t.stopped_minutes;max=Math.max(max,t.max_speed_kmh);points+=t.points;stops+=t.stops.length}const [[del]]=await pool.execute(`SELECT COUNT(*) total,SUM(status='delivered') delivered,SUM(status='failed') failed FROM platform_deliveries WHERE created_at BETWEEN ? AND ?`,[a,b]);const fs=await fleetSettings();res.json({start,end,devices:devices.length,distance_km:Number(km.toFixed(1)),fuel_estimate_l:Number((km/Math.max(1,Number(fs.fuel_efficiency_km_l||10))).toFixed(1)),moving_minutes:moving,stopped_minutes:stopped,max_speed_kmh:Number(max.toFixed(1)),points,stops,deliveries:Number(del.total||0),delivered:Number(del.delivered||0),failed:Number(del.failed||0)})});

async function deviceContext(deviceKey){
  const [rows]=await pool.execute(`SELECT td.id tracking_device_id,td.device_key,a.vehicle_id,a.driver_id,v.name vehicle_name,v.plate,dr.name driver_name
    FROM platform_tracking_devices td
    LEFT JOIN platform_assignments a ON a.tracking_device_id=td.id AND a.active=1
    LEFT JOIN platform_vehicles v ON v.id=a.vehicle_id
    LEFT JOIN platform_drivers dr ON dr.id=a.driver_id
    WHERE td.device_key=? LIMIT 1`,[deviceKey]);
  return rows[0]||{device_key:deviceKey};
}
function classifyStop(stop,planned,refs,radius){
  let nearest=null;
  for(const x of planned){
    const d=hav(stop.lat,stop.lon,Number(x.latitude),Number(x.longitude));
    if(d<=radius&&(!nearest||d<nearest.d))nearest={kind:'delivery_stop',name:x.name,d};
  }
  for(const x of refs){
    const d=hav(stop.lat,stop.lon,Number(x.latitude),Number(x.longitude));
    if(d<=radius&&(!nearest||d<nearest.d))nearest={kind:'reference_stop',name:x.name,d};
  }
  if(nearest)return nearest;
  const mins=stop.duration_seconds/60;
  if(mins<=3)return {kind:'traffic_stop',name:'Trânsito provável',d:null};
  return {kind:'unplanned_stop',name:'Parada não planejada',d:null};
}
function stopSegments(rows,minSeconds=60){
  const out=[];let start=null,pts=[];
  function close(end){
    if(!start||!end)return;
    const dur=(new Date(end.recorded_at)-new Date(start.recorded_at))/1000;
    if(dur>=minSeconds&&pts.length){
      out.push({start:start.recorded_at,end:end.recorded_at,duration_seconds:Math.round(dur),
        lat:median(pts.map(x=>Number(x.latitude))),lon:median(pts.map(x=>Number(x.longitude)))});
    }
    start=null;pts=[];
  }
  for(let i=0;i<rows.length;i++){
    const r=rows[i],speed=Number(r.speed_kmh||0);
    const prev=i?rows[i-1]:null;
    let moving=speed>=4;
    if(prev){
      const dt=(new Date(r.recorded_at)-new Date(prev.recorded_at))/1000;
      const d=dt>0?hav(Number(prev.latitude),Number(prev.longitude),Number(r.latitude),Number(r.longitude)):0;
      const calc=dt>0?d/dt*3.6:0;
      moving=moving||calc>=5;
      if(dt>900){close(prev);continue}
    }
    if(!moving){if(!start)start=r;pts.push(r)}
    else if(start)close(prev||r);
  }
  if(start)close(rows.at(-1));
  return out;
}
async function insertFleetEvent(ev){
  const [r]=await pool.execute(`INSERT IGNORE INTO platform_fleet_events(event_key,device_key,vehicle_id,driver_id,event_type,title,severity,occurred_at,ended_at,configured_value,realized_value,value_unit,latitude,longitude,details,metadata)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,[
    ev.event_key,ev.device_key,ev.vehicle_id||null,ev.driver_id||null,ev.event_type,ev.title,ev.severity||'info',
    ev.occurred_at,ev.ended_at||null,ev.configured_value??null,ev.realized_value??null,ev.value_unit||null,
    ev.latitude??null,ev.longitude??null,ev.details||null,JSON.stringify(ev.metadata||{})
  ]);
  if(r.affectedRows){
    const who=ev.vehicle_name||ev.device_key;
    const msg=`Sarah Rodrigues · A7W\n${ev.title}\n${who}${ev.driver_name?' · '+ev.driver_name:''}\n${ev.details||''}`;
    const proactive=await sendSaraFleetAlert(ev).catch(()=>({ok:false}));
    if(!proactive?.ok&&!proactive?.skipped)await telegramNotify(msg,ev.event_type);
  }
  return r.affectedRows>0;
}
async function evaluateDeviceDay(deviceKey,date){
  if(!deviceKey||!validDate(date))return {created:0};
  const settings=await fleetSettings(),ctx=await deviceContext(deviceKey),[a,b]=sqlRange(date);
  const [rows]=await pool.execute(`SELECT latitude,longitude,accuracy,speed_kmh,bearing,battery,ignition,fuel_level,odometer_km,recorded_at
    FROM platform_location_points WHERE device_key=? AND recorded_at BETWEEN ? AND ? ORDER BY recorded_at ASC LIMIT 30000`,[deviceKey,a,b]);
  if(!rows.length)return {created:0};
  const planned=ctx.vehicle_id?(await pool.execute(`SELECT name,address,latitude,longitude FROM platform_route_stops WHERE vehicle_id=? AND route_date=?`,[ctx.vehicle_id,date]))[0]:[];
  const refs=(await pool.execute(`SELECT name,latitude,longitude FROM platform_reference_points`))[0];
  let created=0;

  // Excesso de velocidade: só dispara depois da duração mínima configurada.
  let overStart=null,overMax=0,overLast=null;
  async function closeOver(endRow){
    if(!overStart)return;
    const end=endRow||overLast||overStart,seconds=(new Date(end.recorded_at)-new Date(overStart.recorded_at))/1000;
    if(seconds>=Number(settings.overspeed_min_seconds||120)){
      const ev={event_key:`overspeed:${deviceKey}:${mysqlTime(overStart.recorded_at)}`,device_key:deviceKey,vehicle_id:ctx.vehicle_id,driver_id:ctx.driver_id,event_type:'overspeed',
        title:'Excesso de velocidade',severity:'attention',occurred_at:mysqlTime(overStart.recorded_at),ended_at:mysqlTime(end.recorded_at),
        configured_value:Number(settings.speed_limit_kmh),realized_value:Number(overMax.toFixed(1)),value_unit:'km/h',
        latitude:Number(overStart.latitude),longitude:Number(overStart.longitude),
        details:`Limite ${Number(settings.speed_limit_kmh).toFixed(0)} km/h por ${Math.round(seconds/60)} min; pico ${overMax.toFixed(0)} km/h.`,
        vehicle_name:ctx.vehicle_name,driver_name:ctx.driver_name,metadata:{duration_seconds:Math.round(seconds)}};
      if(await insertFleetEvent(ev))created++;
    }
    overStart=null;overMax=0;overLast=null;
  }
  for(const r of rows){
    const speed=Number(r.speed_kmh||0);
    if(speed>Number(settings.speed_limit_kmh||80)){if(!overStart)overStart=r;overMax=Math.max(overMax,speed);overLast=r}
    else if(overStart)await closeOver(r);
  }
  if(overStart)await closeOver(overLast);

  // Paradas: identifica entrega/local conhecido por proximidade. "Trânsito" é apenas inferência.
  const segments=stopSegments(rows,60);
  for(const stop of segments){
    const c=classifyStop(stop,planned,refs,Number(settings.delivery_radius_m||150));
    const mins=stop.duration_seconds/60;
    const threshold=Number(settings.stop_alert_minutes||8);
    if(c.kind==='traffic_stop' || c.kind==='delivery_stop' || c.kind==='reference_stop' || mins>=threshold){
      const label={delivery_stop:'Parada de entrega provável',reference_stop:'Parada em local conhecido',traffic_stop:'Parada em trânsito provável',unplanned_stop:'Parada não planejada'}[c.kind];
      const severity=c.kind==='unplanned_stop'&&mins>=threshold?'attention':'info';
      const ev={event_key:`${c.kind}:${deviceKey}:${mysqlTime(stop.start)}`,device_key:deviceKey,vehicle_id:ctx.vehicle_id,driver_id:ctx.driver_id,event_type:c.kind,title:label,severity,
        occurred_at:mysqlTime(stop.start),ended_at:mysqlTime(stop.end),configured_value:c.kind==='unplanned_stop'?threshold:null,realized_value:Number(mins.toFixed(1)),value_unit:'min',
        latitude:stop.lat,longitude:stop.lon,details:c.name?`${c.name} · ${mins.toFixed(0)} min`:`${mins.toFixed(0)} min`,
        vehicle_name:ctx.vehicle_name,driver_name:ctx.driver_name,metadata:{classification:c.kind,near:c.name||null,distance_m:c.d?Math.round(c.d):null,heuristic:c.kind==='traffic_stop'}};
      if(await insertFleetEvent(ev))created++;
    }
  }

  // Marcha lenta exige ignição real. Só é avaliada se o dispositivo reportar ignition.
  let idleStart=null,idleLast=null;
  async function closeIdle(end){
    if(!idleStart)return;
    const seconds=(new Date((end||idleLast).recorded_at)-new Date(idleStart.recorded_at))/1000;
    if(seconds>=Number(settings.idle_alert_minutes||5)*60){
      const ev={event_key:`idle:${deviceKey}:${mysqlTime(idleStart.recorded_at)}`,device_key:deviceKey,vehicle_id:ctx.vehicle_id,driver_id:ctx.driver_id,event_type:'idle',
        title:'Marcha lenta',severity:'attention',occurred_at:mysqlTime(idleStart.recorded_at),ended_at:mysqlTime((end||idleLast).recorded_at),
        configured_value:Number(settings.idle_alert_minutes||5),realized_value:Number((seconds/60).toFixed(1)),value_unit:'min',
        latitude:Number(idleStart.latitude),longitude:Number(idleStart.longitude),details:`Ignição ligada com veículo parado por ${Math.round(seconds/60)} min.`,
        vehicle_name:ctx.vehicle_name,driver_name:ctx.driver_name};
      if(await insertFleetEvent(ev))created++;
    }
    idleStart=null;idleLast=null;
  }
  for(const r of rows){
    const isIdle=Number(r.ignition)===1&&Number(r.speed_kmh||0)<4;
    if(isIdle){if(!idleStart)idleStart=r;idleLast=r}else if(idleStart)await closeIdle(r);
  }
  if(idleStart)await closeIdle(idleLast);
  return {created};
}


router.get('/telegram/status',async(req,res)=>{
  const probe=String(req.query.refresh||'1')!=='0'?await telegramProbe():null;
  const [[row]]=await pool.execute(`SELECT status,external_name,external_username,last_attempt_at,last_success_at,last_failure_at,last_error,last_message_preview,last_message_event_type,updated_at FROM platform_integration_status WHERE integration_key='telegram' LIMIT 1`);
  const cfg=telegramConfig();
  res.json({configured:!!(cfg.token&&cfg.chat),display_name:TELEGRAM_DISPLAY_NAME,...(row||{}),...(probe||{})});
});
router.post('/telegram/test',async(req,res)=>{
  const result=await telegramNotify(`✅ Sarah Rodrigues · A7W Control\nIntegração com Telegram funcionando.\nA7W Platform v0.9.6 conectada com sucesso.`,'test');
  if(!result.ok)return res.status(result.error==='NOT_CONFIGURED'?400:502).json(result);
  await audit(req,'telegram.test.sent','integration','telegram',{});res.json(result);
});
router.post('/telegram/set-name',async(req,res)=>{
  const cfg=telegramConfig();if(!cfg.token)return res.status(400).json({error:'TELEGRAM_NOT_CONFIGURED',message:'Token do Telegram não está disponível no processo da aplicação.'});
  const result=await telegramApi('setMyName',{name:TELEGRAM_DISPLAY_NAME});
  if(!result.ok){const msg=result.description||'Falha ao alterar nome';await saveTelegramStatus({status:'error',last_failure_at:mysqlTime(new Date()),last_error:String(msg).slice(0,500)});return res.status(502).json({error:'TELEGRAM_SET_NAME_FAILED',message:msg})}
  const verify=await telegramApi('getMyName',{});const applied=verify.ok?verify.result?.name:TELEGRAM_DISPLAY_NAME;
  await audit(req,'telegram.name.updated','integration','telegram',{name:TELEGRAM_DISPLAY_NAME,applied});
  const probe=await telegramProbe();res.json({ok:true,name:applied||TELEGRAM_DISPLAY_NAME,...probe});
});


router.get('/sara/status',async(req,res)=>{
  const base=String(process.env.APP_BASE_URL||`${req.protocol}://${req.get('host')}`).replace(/\/$/,'');
  res.json(await assistantStatus(base));
});
router.post('/sara/gemini/test',async(req,res)=>{
  const r=await testGemini();if(!r.ok)return res.status(r.error==='GEMINI_NOT_CONFIGURED'?400:502).json(r);res.json(r);
});
router.post('/sara/webhook/setup',async(req,res)=>{
  const base=String(process.env.APP_BASE_URL||`${req.protocol}://${req.get('host')}`).replace(/\/$/,'');
  const r=await setupWebhook(base);if(!r.ok)return res.status(502).json(r);await audit(req,'sara.webhook.enabled','integration','telegram',{url:r.url});res.json(r);
});

router.get('/sara/settings',async(req,res)=>res.json(await getSaraSettings()));
router.put('/sara/settings',async(req,res)=>{
  const r=await updateSaraSettings(req.body||{},req.session.user.id);await audit(req,'sara.settings.updated','sara','voice',{voice_policy:r.voice_policy,voice_name:r.voice_name,voice_enabled:r.voice_enabled,monthly_budget_brl:r.monthly_budget_brl});res.json(r);
});
router.post('/sara/voice/test',async(req,res)=>{const r=await testVoice();if(!r.ok)return res.status(/NOT_CONFIGURED/.test(String(r.error||''))?400:502).json(r);await audit(req,'sara.voice.test','integration',`${r.provider||'tts'}_tts`,{voice:r.voice,model:r.model,provider:r.provider,fallback_from:r.fallback_from||null});res.json(r)});
router.get('/sara/usage',async(req,res)=>res.json(await usageSummary()));

router.get('/settings',async(req,res)=>res.json(await fleetSettings()));
router.put('/settings',async(req,res)=>{
  const speed=clamp(Number(req.body.speed_limit_kmh)||80,20,180),over=clamp(parseInt(req.body.overspeed_min_seconds,10)||120,10,3600),
    stop=clamp(parseInt(req.body.stop_alert_minutes,10)||8,1,240),radius=clamp(parseInt(req.body.delivery_radius_m,10)||150,30,2000),
    fuel=clamp(Number(req.body.fuel_efficiency_km_l)||10,1,100),idle=clamp(parseInt(req.body.idle_alert_minutes,10)||5,1,240);
  await pool.execute(`UPDATE platform_fleet_settings SET speed_limit_kmh=?,overspeed_min_seconds=?,stop_alert_minutes=?,delivery_radius_m=?,fuel_efficiency_km_l=?,idle_alert_minutes=?,updated_by_user_id=? WHERE id=1`,[speed,over,stop,radius,fuel,idle,req.session.user.id]);
  await audit(req,'fleet.settings.updated','fleet_settings','1',{speed,over,stop,radius,fuel,idle});res.json({ok:true});
});
router.post('/events/evaluate',async(req,res)=>{
  const key=cleanText(req.body.device_id,160),date=String(req.body.date||'');
  if(!key||!validDate(date))return res.status(400).json({error:'DEVICE_DATE_REQUIRED'});
  const r=await evaluateDeviceDay(key,date);res.json({ok:true,...r});
});
router.get('/events',async(req,res)=>{
  const key=cleanText(req.query.device_id,160),start=String(req.query.start||''),end=String(req.query.end||start),type=cleanText(req.query.type,60);
  if(!validDate(start)||!validDate(end))return res.status(400).json({error:'INVALID_PERIOD'});
  const days=Math.floor((new Date(end+'T12:00:00Z')-new Date(start+'T12:00:00Z'))/86400000)+1;
  if(days<1||days>31)return res.status(400).json({error:'PERIOD_TOO_LARGE'});
  const devices=key?[{device_key:key}]:(await pool.execute(`SELECT device_key FROM platform_tracking_devices ORDER BY device_key`))[0];
  for(const d of devices){
    for(let i=0;i<days;i++){const dt=new Date(start+'T12:00:00Z');dt.setUTCDate(dt.getUTCDate()+i);await evaluateDeviceDay(d.device_key,dt.toISOString().slice(0,10))}
  }
  const [a]=sqlRange(start),[,b]=sqlRange(end),params=[a,b];let where=`e.occurred_at BETWEEN ? AND ?`;
  if(key){where+=` AND e.device_key=?`;params.push(key)}
  if(type){where+=` AND e.event_type=?`;params.push(type)}
  const [rows]=await pool.execute(`SELECT e.*,v.name vehicle_name,v.plate,dr.name driver_name FROM platform_fleet_events e
    LEFT JOIN platform_vehicles v ON v.id=e.vehicle_id LEFT JOIN platform_drivers dr ON dr.id=e.driver_id
    WHERE ${where} ORDER BY e.occurred_at DESC,e.id DESC LIMIT 5000`,params);
  res.json(rows);
});
router.get('/route-progress',async(req,res)=>{
  const key=cleanText(req.query.device_id,160),date=String(req.query.date||'');if(!key||!validDate(date))return res.status(400).json({error:'DEVICE_DATE_REQUIRED'});
  const settings=await fleetSettings(),ctx=await deviceContext(key);if(!ctx.vehicle_id)return res.json({total:0,reached:0,percent:0,next:null,eta_minutes:null});
  const [stops]=await pool.execute(`SELECT * FROM platform_route_stops WHERE vehicle_id=? AND route_date=? ORDER BY sequence_no,id`,[ctx.vehicle_id,date]);
  const [a,b]=sqlRange(date);const [rows]=await pool.execute(`SELECT latitude,longitude,speed_kmh,recorded_at FROM platform_location_points WHERE device_key=? AND recorded_at BETWEEN ? AND ? ORDER BY recorded_at ASC LIMIT 30000`,[key,a,b]);
  const radius=Number(settings.delivery_radius_m||150);let reached=0,next=null;
  for(const st of stops){const hit=rows.some(r=>hav(Number(r.latitude),Number(r.longitude),Number(st.latitude),Number(st.longitude))<=radius);if(hit)reached++;else if(!next)next=st}
  const last=rows.at(-1);let eta=null,distance_km=null;if(next&&last){distance_km=hav(Number(last.latitude),Number(last.longitude),Number(next.latitude),Number(next.longitude))/1000;const speed=Number(last.speed_kmh||0);if(speed>=5)eta=Math.max(1,Math.round(distance_km/speed*60))}
  res.json({total:stops.length,reached,percent:stops.length?Math.round(reached/stops.length*100):0,next:next?{id:next.id,name:next.name,address:next.address,distance_km:Number(distance_km?.toFixed(1)||0)}:null,eta_minutes:eta,method:'proximity'});
});

function todayBrazil(){return new Intl.DateTimeFormat('en-CA',{timeZone:'America/Sao_Paulo',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date())}
let backgroundBusy=false;
setInterval(async()=>{
  if(backgroundBusy||String(process.env.FLEET_ALERTS_BACKGROUND||'true').toLowerCase()==='false')return;
  backgroundBusy=true;
  try{
    const [devices]=await pool.execute(`SELECT device_key FROM platform_tracking_devices WHERE last_seen_at>=UTC_TIMESTAMP()-INTERVAL 1 DAY`);
    const date=todayBrazil();
    for(const d of devices)await evaluateDeviceDay(d.device_key,date);
  }catch(e){if(String(process.env.FLEET_ALERTS_DEBUG||'').toLowerCase()==='true')console.error('Fleet alerts background:',e.message)}
  finally{backgroundBusy=false}
},60000).unref?.();


module.exports=router;
