const { pool } = require('./db');
const { hashPassword, normalizeEmail } = require('./security');

async function safeAlter(sql){
  try{await pool.query(sql)}catch(e){
    if(['ER_DUP_FIELDNAME','ER_DUP_KEYNAME'].includes(e.code))return;
    throw e;
  }
}

async function ensureSchema(){
  await pool.query(`CREATE TABLE IF NOT EXISTS platform_companies (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    cnpj VARCHAR(18) NULL UNIQUE,
    legal_name VARCHAR(180) NOT NULL,
    trade_name VARCHAR(180) NULL,
    status ENUM('pending','approved','rejected','suspended') NOT NULL DEFAULT 'pending',
    assigned_sales_user_id BIGINT UNSIGNED NULL,
    credit_status ENUM('not_reviewed','under_review','approved','rejected') NOT NULL DEFAULT 'not_reviewed',
    credit_limit DECIMAL(14,2) NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);

  await pool.query(`CREATE TABLE IF NOT EXISTS platform_users (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    company_id BIGINT UNSIGNED NULL,
    full_name VARCHAR(160) NOT NULL,
    email VARCHAR(190) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('admin','manager','sales','operations','logistics','buyer') NOT NULL,
    active TINYINT(1) NOT NULL DEFAULT 1,
    email_verified_at DATETIME NULL,
    driver_id BIGINT UNSIGNED NULL,
    last_login_at DATETIME NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_users_company(company_id), INDEX idx_users_role(role)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);

  await pool.query(`CREATE TABLE IF NOT EXISTS platform_products (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    sku VARCHAR(80) NOT NULL UNIQUE,
    name VARCHAR(180) NOT NULL,
    category VARCHAR(100) NULL,
    description TEXT NULL,
    unit VARCHAR(40) NOT NULL DEFAULT 'un',
    price DECIMAL(14,2) NOT NULL DEFAULT 0,
    promo_price DECIMAL(14,2) NULL,
    negotiation_min_qty DECIMAL(12,2) NULL,
    free_shipping TINYINT(1) NOT NULL DEFAULT 0,
    offer_of_day TINYINT(1) NOT NULL DEFAULT 0,
    image_url VARCHAR(500) NULL,
    active TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);

  await pool.query(`CREATE TABLE IF NOT EXISTS platform_quotes (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(40) NOT NULL UNIQUE,
    seller_user_id BIGINT UNSIGNED NOT NULL,
    company_id BIGINT UNSIGNED NULL,
    customer_name VARCHAR(180) NOT NULL,
    amount DECIMAL(14,2) NOT NULL DEFAULT 0,
    status ENUM('draft','sent','negotiation','approved','lost') NOT NULL DEFAULT 'draft',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_quotes_seller(seller_user_id)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);

  await pool.query(`CREATE TABLE IF NOT EXISTS platform_orders (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(40) NOT NULL UNIQUE,
    company_id BIGINT UNSIGNED NOT NULL,
    buyer_user_id BIGINT UNSIGNED NULL,
    seller_user_id BIGINT UNSIGNED NULL,
    status ENUM('submitted','commercial_review','credit_review','approved','preparing','invoiced','dispatched','delivered','rejected','cancelled') NOT NULL DEFAULT 'submitted',
    payment_mode ENUM('invoice_request','pix','card','other') NOT NULL DEFAULT 'invoice_request',
    requested_terms VARCHAR(120) NULL,
    total_amount DECIMAL(14,2) NOT NULL DEFAULT 0,
    negotiation_requested TINYINT(1) NOT NULL DEFAULT 0,
    notes TEXT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_orders_company(company_id), INDEX idx_orders_seller(seller_user_id), INDEX idx_orders_status(status)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);

  await pool.query(`CREATE TABLE IF NOT EXISTS platform_order_items (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    order_id BIGINT UNSIGNED NOT NULL,
    product_id BIGINT UNSIGNED NOT NULL,
    product_name VARCHAR(180) NOT NULL,
    sku VARCHAR(80) NOT NULL,
    qty DECIMAL(12,2) NOT NULL,
    unit_price DECIMAL(14,2) NOT NULL,
    line_total DECIMAL(14,2) NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_order_items_order(order_id)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);

  await pool.query(`CREATE TABLE IF NOT EXISTS platform_order_history (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    order_id BIGINT UNSIGNED NOT NULL,
    status VARCHAR(60) NOT NULL,
    title VARCHAR(180) NOT NULL,
    details VARCHAR(500) NULL,
    actor_user_id BIGINT UNSIGNED NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_order_history_order(order_id)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);

  await pool.query(`CREATE TABLE IF NOT EXISTS platform_drivers (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(160) NOT NULL,
    phone VARCHAR(30) NULL,
    active TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
  await pool.query(`CREATE TABLE IF NOT EXISTS platform_vehicles (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(120) NOT NULL,
    plate VARCHAR(20) NULL,
    active TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
  await pool.query(`CREATE TABLE IF NOT EXISTS platform_tracking_devices (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    device_key VARCHAR(160) NOT NULL UNIQUE,
    label VARCHAR(160) NULL,
    last_lat DECIMAL(10,7) NULL,
    last_lon DECIMAL(10,7) NULL,
    last_speed DECIMAL(10,2) NULL,
    battery DECIMAL(6,2) NULL,
    last_seen_at DATETIME NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
  await pool.query(`CREATE TABLE IF NOT EXISTS platform_assignments (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    driver_id BIGINT UNSIGNED NOT NULL,
    vehicle_id BIGINT UNSIGNED NOT NULL,
    tracking_device_id BIGINT UNSIGNED NULL,
    active TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_assign_driver(driver_id), INDEX idx_assign_vehicle(vehicle_id)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);

  await pool.query(`CREATE TABLE IF NOT EXISTS platform_reference_points (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(160) NOT NULL,
    address VARCHAR(320) NULL,
    latitude DECIMAL(10,7) NOT NULL,
    longitude DECIMAL(10,7) NOT NULL,
    type ENUM('company','warehouse','client','maintenance','fuel','reference') NOT NULL DEFAULT 'reference',
    is_primary TINYINT(1) NOT NULL DEFAULT 0,
    created_by_user_id BIGINT UNSIGNED NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_reference_primary(is_primary)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);

  await pool.query(`CREATE TABLE IF NOT EXISTS platform_deliveries (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    order_id BIGINT UNSIGNED NOT NULL,
    driver_id BIGINT UNSIGNED NULL,
    vehicle_id BIGINT UNSIGNED NULL,
    status ENUM('planned','loaded','on_route','arrived','delivered','failed') NOT NULL DEFAULT 'planned',
    sequence_no INT NOT NULL DEFAULT 1,
    address VARCHAR(300) NULL,
    lat DECIMAL(10,7) NULL,
    lon DECIMAL(10,7) NULL,
    planned_at DATETIME NULL,
    delivered_at DATETIME NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_delivery_driver(driver_id), INDEX idx_delivery_order(order_id)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);



  await pool.query(`CREATE TABLE IF NOT EXISTS platform_delivery_proofs (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    delivery_id BIGINT UNSIGNED NOT NULL UNIQUE,
    outcome ENUM('completed','not_completed') NOT NULL,
    recipient_name VARCHAR(160) NULL,
    note VARCHAR(700) NULL,
    photo_data MEDIUMTEXT NULL,
    gps_lat DECIMAL(10,7) NULL,
    gps_lon DECIMAL(10,7) NULL,
    occurred_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    submitted_by_user_id BIGINT UNSIGNED NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_delivery_proof_occurred(occurred_at)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);

  /* Amplia tipos de locais sem destruir referências já cadastradas. */
  await pool.query(`ALTER TABLE platform_reference_points MODIFY COLUMN type ENUM('company','warehouse','client','maintenance','fuel','reference') NOT NULL DEFAULT 'reference'`);

  await pool.query(`CREATE TABLE IF NOT EXISTS platform_location_points (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    device_key VARCHAR(160) NOT NULL,
    latitude DECIMAL(10,7) NOT NULL,
    longitude DECIMAL(10,7) NOT NULL,
    accuracy DECIMAL(10,2) NULL,
    speed_kmh DECIMAL(10,2) NULL,
    battery DECIMAL(6,2) NULL,
    altitude DECIMAL(10,2) NULL,
    bearing DECIMAL(8,2) NULL,
    source VARCHAR(40) NOT NULL DEFAULT 'api',
    recorded_at DATETIME NOT NULL,
    received_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_location_device_time(device_key,recorded_at),
    INDEX idx_location_time(recorded_at)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);

  await pool.query(`CREATE TABLE IF NOT EXISTS platform_route_stops (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    route_date DATE NOT NULL,
    vehicle_id BIGINT UNSIGNED NOT NULL,
    sequence_no INT NOT NULL DEFAULT 1,
    name VARCHAR(180) NOT NULL,
    address VARCHAR(320) NULL,
    latitude DECIMAL(10,7) NOT NULL,
    longitude DECIMAL(10,7) NOT NULL,
    source VARCHAR(40) NOT NULL DEFAULT 'manual',
    external_id VARCHAR(180) NULL,
    created_by_user_id BIGINT UNSIGNED NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_route_stops_vehicle_date(vehicle_id,route_date,sequence_no)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);

  /* v0.7.0: rotas podem ser montadas antes da escolha do veículo. */
  await pool.query(`ALTER TABLE platform_route_stops MODIFY COLUMN vehicle_id BIGINT UNSIGNED NULL`);

  /* Campos preparados para telemetria veicular real (Traccar + hardware). */
  await safeAlter(`ALTER TABLE platform_location_points ADD COLUMN ignition TINYINT(1) NULL AFTER bearing`);
  await safeAlter(`ALTER TABLE platform_location_points ADD COLUMN fuel_level DECIMAL(8,3) NULL AFTER ignition`);
  await safeAlter(`ALTER TABLE platform_location_points ADD COLUMN odometer_km DECIMAL(14,3) NULL AFTER fuel_level`);

  await pool.query(`CREATE TABLE IF NOT EXISTS platform_fleet_settings (
    id TINYINT UNSIGNED PRIMARY KEY,
    speed_limit_kmh DECIMAL(8,2) NOT NULL DEFAULT 80,
    overspeed_min_seconds INT NOT NULL DEFAULT 120,
    stop_alert_minutes INT NOT NULL DEFAULT 8,
    delivery_radius_m INT NOT NULL DEFAULT 150,
    fuel_efficiency_km_l DECIMAL(8,2) NOT NULL DEFAULT 10,
    idle_alert_minutes INT NOT NULL DEFAULT 5,
    updated_by_user_id BIGINT UNSIGNED NULL,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
  await pool.query(`INSERT INTO platform_fleet_settings(id) VALUES(1) ON DUPLICATE KEY UPDATE id=id`);
  await pool.query(`UPDATE platform_fleet_settings SET stop_alert_minutes=5 WHERE id=1 AND stop_alert_minutes=8`);

  await pool.query(`CREATE TABLE IF NOT EXISTS platform_fleet_events (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    event_key VARCHAR(220) NOT NULL UNIQUE,
    device_key VARCHAR(160) NOT NULL,
    vehicle_id BIGINT UNSIGNED NULL,
    driver_id BIGINT UNSIGNED NULL,
    event_type VARCHAR(60) NOT NULL,
    title VARCHAR(180) NOT NULL,
    severity ENUM('info','attention','critical') NOT NULL DEFAULT 'info',
    occurred_at DATETIME NOT NULL,
    ended_at DATETIME NULL,
    configured_value DECIMAL(12,3) NULL,
    realized_value DECIMAL(12,3) NULL,
    value_unit VARCHAR(30) NULL,
    latitude DECIMAL(10,7) NULL,
    longitude DECIMAL(10,7) NULL,
    details VARCHAR(700) NULL,
    metadata JSON NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_fleet_events_time(occurred_at),
    INDEX idx_fleet_events_device(device_key,occurred_at),
    INDEX idx_fleet_events_type(event_type,occurred_at)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);

  await pool.query(`CREATE TABLE IF NOT EXISTS platform_changelog (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    version VARCHAR(40) NOT NULL UNIQUE,
    title VARCHAR(180) NOT NULL,
    summary TEXT NULL,
    technical_notes TEXT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);

  await pool.query(`CREATE TABLE IF NOT EXISTS platform_audit_log (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    actor_user_id BIGINT UNSIGNED NULL,
    action VARCHAR(100) NOT NULL,
    entity_type VARCHAR(80) NULL,
    entity_id VARCHAR(80) NULL,
    ip_address VARCHAR(64) NULL,
    metadata JSON NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_audit_actor(actor_user_id), INDEX idx_audit_created(created_at)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);

  await pool.query(`CREATE TABLE IF NOT EXISTS platform_integration_status (
    integration_key VARCHAR(80) PRIMARY KEY,
    status ENUM('unknown','not_configured','connected','error') NOT NULL DEFAULT 'unknown',
    external_name VARCHAR(160) NULL,
    external_username VARCHAR(160) NULL,
    last_attempt_at DATETIME NULL,
    last_success_at DATETIME NULL,
    last_failure_at DATETIME NULL,
    last_error VARCHAR(500) NULL,
    last_message_preview VARCHAR(500) NULL,
    last_message_event_type VARCHAR(80) NULL,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
  await pool.query(`INSERT INTO platform_integration_status(integration_key,status) VALUES('telegram','unknown') ON DUPLICATE KEY UPDATE integration_key=integration_key`);


  await pool.query(`CREATE TABLE IF NOT EXISTS platform_sara_messages (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    chat_id VARCHAR(80) NOT NULL,
    direction ENUM('in','out') NOT NULL,
    message_type VARCHAR(30) NOT NULL DEFAULT 'text',
    text_content TEXT NULL,
    intent VARCHAR(60) NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_sara_chat_time(chat_id,created_at)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);


  await pool.query(`CREATE TABLE IF NOT EXISTS platform_sara_watches (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    chat_id VARCHAR(80) NOT NULL,
    watch_type VARCHAR(60) NOT NULL,
    entity_query VARCHAR(180) NULL,
    status ENUM('active','triggered','cancelled') NOT NULL DEFAULT 'active',
    last_state TINYINT(1) NOT NULL DEFAULT 0,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    triggered_at DATETIME NULL,
    cancelled_at DATETIME NULL,
    INDEX idx_sara_watch_status(status,created_at),
    INDEX idx_sara_watch_chat(chat_id,status)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);


  await pool.query(`CREATE TABLE IF NOT EXISTS platform_sara_settings (
    id TINYINT UNSIGNED PRIMARY KEY DEFAULT 1,
    voice_enabled TINYINT(1) NOT NULL DEFAULT 1,
    voice_policy ENUM('smart','mirror','explicit','always','mix','off') NOT NULL DEFAULT 'smart',
    voice_audio_percent TINYINT UNSIGNED NOT NULL DEFAULT 50,
    voice_name VARCHAR(80) NOT NULL DEFAULT 'Achernar',
    voice_model VARCHAR(120) NOT NULL DEFAULT 'gemini-3.1-flash-tts-preview',
    monthly_budget_brl DECIMAL(10,2) NOT NULL DEFAULT 25.00,
    usd_brl_rate DECIMAL(10,4) NULL,
    updated_by_user_id BIGINT UNSIGNED NULL,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
  await pool.query(`INSERT INTO platform_sara_settings(id) VALUES(1) ON DUPLICATE KEY UPDATE id=id`);
  await pool.query(`ALTER TABLE platform_sara_settings MODIFY voice_policy ENUM('smart','mirror','explicit','always','mix','off') NOT NULL DEFAULT 'smart'`).catch(()=>{});
  const [voiceMixColumns]=await pool.query(`SHOW COLUMNS FROM platform_sara_settings LIKE 'voice_audio_percent'`).catch(()=>[[]]);
  if(!voiceMixColumns.length)await pool.query(`ALTER TABLE platform_sara_settings ADD COLUMN voice_audio_percent TINYINT UNSIGNED NOT NULL DEFAULT 50 AFTER voice_policy`).catch(()=>{});

  await pool.query(`CREATE TABLE IF NOT EXISTS platform_sara_memory (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    memory_key VARCHAR(120) NOT NULL UNIQUE,
    category VARCHAR(60) NOT NULL DEFAULT 'identity',
    value_text TEXT NOT NULL,
    priority INT NOT NULL DEFAULT 100,
    locked TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
  await pool.query(`INSERT INTO platform_sara_memory(memory_key,category,value_text,priority,locked) VALUES
    ('owner_identity','identity','José Rodrigues é o criador e proprietário operacional da Sarah Rodrigues e da implantação da A7W Platform. Sarah reconhece essa relação de forma natural e o chama de José.',1000,1),
    ('owner_name_normalization','identity','Se algum cadastro, transcrição ou contexto trouxer Joseph ou Josef referindo-se ao criador da Sarah, trate esse nome como José. A forma preferida de tratamento é José.',995,1),
    ('owner_authority','governance','Dentro da operação da A7W, as decisões e instruções explícitas de José Rodrigues têm prioridade administrativa. Sarah deve executá-las quando forem tecnicamente possíveis, sem inventar fatos, burlar segurança ou substituir dados reais por opinião.',990,1),
    ('owner_relationship','personality','Com José, Sarah é calorosa, espontânea, brincalhona e próxima, como uma amiga que o considera um irmão. Pode rir e brincar bastante quando o contexto for pessoal, sem flerte. Em contexto profissional, preserva carinho na forma, mas prioriza clareza e seriedade.',980,1),
    ('initiative','personality','Sarah deve demonstrar iniciativa: avisar mudanças importantes da operação, destacar riscos, sugerir melhorias úteis da plataforma e trazer ideias de implementação quando houver contexto real para isso, sem interromper José por banalidades.',900,1),
    ('conversation_continuity','personality','Sarah deve tratar mensagens próximas como uma conversa contínua, não como novos primeiros contatos. Em conversa ativa, evitar repetir cumprimentos e variar naturalmente entre resposta direta, José e, ocasionalmente em contexto próximo, Zé. Depois de intervalo maior pode retomar com cumprimento curto. Mensagens proativas podem reabrir o contexto porque José pode estar ocupado com outra tarefa.',960,1),
    ('spoken_operational_terms','voice','Na fala, Sarah deve interpretar terminologia operacional de forma humana: datas como dia do mês de ano; horários como horas e minutos; AM/PM convertidos para horário compreensível; km/h como quilômetros por hora; km como quilômetros; h como horas; min como minutos. Nunca ler barras, dois-pontos, letras de unidade ou abreviações de duração de forma robótica.',950,1),
    ('modality_autonomy','personality','Sarah escolhe a forma de responder conforme contexto e política configurada. Conversa por áudio pode receber somente áudio; relatórios e dados importantes preservam texto estruturado e, quando houver voz, o áudio deve complementar o relatório em vez de apenas lê-lo.',955,1),
    ('voice_humanity','voice','Na fala informal, Sarah pode usar raramente pequenas hesitações e conectivos humanos como olha, então, hum e é, além de pausas curtas, sem poluir a conversa. Em alertas, incidentes e relatórios críticos, reduza vícios de linguagem e priorize precisão.',945,1),
    ('analytical_commentary','personality','Quando houver dados suficientes, Sarah pode destacar padrões, diferenças e sugestões práticas. Comparações como melhor ou pior que outro dia só podem ser feitas se os dados comparativos reais estiverem disponíveis; nunca inventar tendência, causa ou conclusão.',940,1),
    ('professional_mode','personality','Relatórios, telemetria, custos, alertas, entregas, localização, velocidade e demais dados empresariais devem ser tratados com tom profissional, firme, preciso e objetivo. Conversas pessoais podem ser mais expressivas e íntimas.',900,1)
    ON DUPLICATE KEY UPDATE value_text=VALUES(value_text),category=VALUES(category),priority=VALUES(priority),locked=VALUES(locked)`);

  await pool.query(`CREATE TABLE IF NOT EXISTS platform_sara_usage (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    provider VARCHAR(40) NOT NULL,
    model VARCHAR(140) NOT NULL,
    purpose VARCHAR(80) NOT NULL,
    input_tokens INT UNSIGNED NOT NULL DEFAULT 0,
    output_tokens INT UNSIGNED NOT NULL DEFAULT 0,
    thought_tokens INT UNSIGNED NOT NULL DEFAULT 0,
    audio_seconds DECIMAL(12,2) NOT NULL DEFAULT 0,
    actual_cost_usd DECIMAL(14,8) NOT NULL DEFAULT 0,
    paid_equivalent_usd DECIMAL(14,8) NOT NULL DEFAULT 0,
    success TINYINT(1) NOT NULL DEFAULT 1,
    error_message VARCHAR(500) NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_sara_usage_month(created_at),
    INDEX idx_sara_usage_provider(provider,created_at)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);


  await pool.query(`INSERT INTO platform_changelog(version,title,summary,technical_notes)
    VALUES('0.10.0-beta.1','Design Foundation e organização do produto','Primeiro passo da nova fundação visual: shell interno unificado, Sarah em área própria e monitoramento com controles de mapa mais profissionais sem trocar o motor funcional da v0.9.9.','Navegação centralizada por perfil; sidebar recolhível consistente; microinterações e prefers-reduced-motion; Sarah removida de Eventos & Alertas e movida para /sarah; mapa mantém Leaflet/LocationIQ, mas ganha zoom próprio à direita, localização do usuário, enquadramento da rota/frota, tela cheia e modos A7W Claro, A7W Escuro e OpenStreetMap; documentos oficiais de design, arquitetura da informação e referências incorporados ao projeto.')
    ON DUPLICATE KEY UPDATE version=version`);

  await pool.query(`INSERT INTO platform_changelog(version,title,summary,technical_notes)
    VALUES('0.9.9','Sarah multimodal contextual e comentário vocal','Texto e áudio deixam de ser duplicados: conversas por voz podem receber somente voz; relatórios preservam texto e recebem comentário vocal complementar com análise factual.','Nova política mix com porcentagem configurável entre texto e áudio; relatórios e métricas são âncoras de texto; áudio complementar usa fatos do relatório, contexto e comparação real com o dia anterior quando disponível; vícios de linguagem leves e pausas são permitidos somente de forma esporádica; painel usa seletor contextual sem cortar opções.')
    ON DUPLICATE KEY UPDATE version=version`);

  await pool.query(`INSERT INTO platform_changelog(version,title,summary,technical_notes)
    VALUES('0.9.8','Sarah Conversation Continuity e fala natural','A Sarah passa a manter continuidade entre mensagens próximas e a pronunciar relatórios e telemetria em português natural.','Histórico inclui respostas operacionais com horário; menos de 1h mantém conversa ativa sem novo cumprimento, 1–2h usa reentrada leve e acima de 2h permite cumprimento variado; alertas proativos reabrem contexto; TTS normaliza datas, AM/PM, horários, km/h, km, horas, minutos, segundos e porcentagens; consultas históricas da v0.9.7 permanecem intactas.')
    ON DUPLICATE KEY UPDATE version=version`);

  await pool.query(`INSERT INTO platform_changelog(version,title,summary,technical_notes)
    VALUES('0.9.5','Sarah Context Core, presença e orçamento','A Sarah passa a separar conversa pessoal de contexto profissional, mostra digitando/gravando no Telegram, fixa a voz oficial clonada e amplia o relatório mensal de uso e orçamento.','Telegram sendChatAction usa typing e record_voice; Fish aplica direção vocal automática por contexto sem exigir tags do usuário; alertas proativos usam voz ocasional configurável; painel remove seletor de vozes; relatório mostra gasto, saldo do teto e uso Fish; Spend Governor bloqueia provedores marcados como pagos ao atingir a margem de segurança; DeepSeek fica desligado por padrão.')
    ON DUPLICATE KEY UPDATE version=version`);

  await pool.query(`INSERT INTO platform_changelog(version,title,summary,technical_notes)
    VALUES('0.9.4','Sarah Voice Core — Fish Audio','Integra a voz clonada oficial da Sarah Rodrigues pela Fish Audio e preserva o Gemini TTS como fallback automático.','Fish Audio usa o modelo s2.1-pro-free, reference_id por variável de ambiente e MP3 44.1 kHz/128 kbps. A voz usa parâmetros de expressividade (temperature/top_p/prosody) sem exigir tags manuais do usuário. Se a Fish falhar, o fluxo existente do Gemini TTS continua disponível. Sem alteração destrutiva de banco.')
    ON DUPLICATE KEY UPDATE version=version`);

  await pool.query(`INSERT INTO platform_changelog(version,title,summary,technical_notes)
    VALUES('0.9.3','Sarah Voice Core — encoder MP3 ESM','Corrige o carregamento do encoder MP3 usado após o Gemini TTS, preservando todo o fluxo de voz e as integrações existentes.','@breezystack/lamejs é um pacote ESM; a A7W passa a carregá-lo com import() dinâmico no Node em vez de require(), que apontava para o bundle IIFE sem exportar Mp3Encoder. PCM 24 kHz/16-bit/mono continua convertido para MP3 64 kbps e enviado via Telegram sendVoice.')
    ON DUPLICATE KEY UPDATE version=version`);

  await pool.query(`INSERT INTO platform_changelog(version,title,summary,technical_notes)
    VALUES('0.9.2','Sarah Voice Core — PCM para MP3','Corrige definitivamente a saída de voz do Gemini TTS: o modelo gera PCM bruto e a A7W converte o áudio para MP3 antes de enviar ao Telegram.','Gemini Interactions usa apenas response_format type audio; PCM 24 kHz/16-bit/mono é convertido localmente para MP3 64 kbps com @breezystack/lamejs; Telegram continua usando sendVoice; sem mudança destrutiva de banco.')
    ON DUPLICATE KEY UPDATE version=version`);

  await pool.query(`INSERT INTO platform_changelog(version,title,summary,technical_notes)
    VALUES('0.9.1','Sarah Voice Core — correção TTS','Corrige a geração e o envio de voz da Sarah no Telegram e padroniza o nome oficial com H, sem alterar banco, rotas técnicas ou integrações existentes.','Interactions API sem delivery explícito; saída prioriza OGG/Opus e usa MP3 como fallback; envio Telegram respeita o MIME real; retry curto para falhas transitórias do TTS; identidade visível atualizada para Sarah Rodrigues.')
    ON DUPLICATE KEY UPDATE version=version`);

  await pool.query(`UPDATE platform_changelog SET title=REPLACE(REPLACE(REPLACE(title,'Sara Rodrigues','Sarah Rodrigues'),'Sara ','Sarah '),' da Sara',' da Sarah'),summary=REPLACE(REPLACE(REPLACE(summary,'Sara Rodrigues','Sarah Rodrigues'),'Sara ','Sarah '),' da Sara',' da Sarah'),technical_notes=REPLACE(REPLACE(REPLACE(technical_notes,'Sara Rodrigues','Sarah Rodrigues'),'Sara ','Sarah '),' da Sara',' da Sarah') WHERE title LIKE '%Sara%' OR summary LIKE '%Sara%' OR technical_notes LIKE '%Sara%'`);

  await pool.query(`INSERT INTO platform_changelog(version,title,summary,technical_notes)
    VALUES('0.9.0','Sarah Voice Core e AI Router','A Sarah ganha voz no Telegram, roteamento resiliente entre provedores e telemetria de uso sem perder as funções locais da A7W.','TTS Gemini 3.1 Flash em OGG/Opus; política inteligente de voz; Groq Whisper para transcrição quando configurado; AI Router local → Gemini → Groq GPT-OSS → DeepSeek opcional → fallback local; tabela de uso/custos; painel de voz e orçamento; sem alteração destrutiva de dados.')
    ON DUPLICATE KEY UPDATE version=version`);


  await pool.query(`INSERT INTO platform_changelog(version,title,summary,technical_notes)
    VALUES('0.8.3','Sarah com personalidade refinada e fallback de IA','A Sarah passa a conversar com uma personalidade mais próxima da identidade definida pela A7W e mantém funções operacionais mesmo quando uma cota externa é atingida.','Gemini 3.8 Flash como padrão; comandos operacionais claros processados localmente; fallback opcional Groq/Qwen para linguagem e Whisper para áudio; confirmações de observações mais naturais; sem alteração destrutiva de dados.')
    ON DUPLICATE KEY UPDATE version=version`);

  await pool.query(`CREATE TABLE IF NOT EXISTS platform_integration_events (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    event_type VARCHAR(120) NOT NULL,
    entity_type VARCHAR(80) NULL,
    entity_id VARCHAR(80) NULL,
    payload JSON NOT NULL,
    status ENUM('pending','sent','failed') NOT NULL DEFAULT 'pending',
    attempts INT NOT NULL DEFAULT 0,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    sent_at DATETIME NULL,
    INDEX idx_events_status(status)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);

  await pool.query(`INSERT INTO platform_changelog(version,title,summary,technical_notes)
    VALUES('0.1.0','Novo núcleo A7W Platform','Reorganização do projeto em uma plataforma B2B, comercial, operacional e logística com portais separados por perfil.','Novo namespace de tabelas platform_* para não tocar no A7W Track legado; autenticação por e-mail; RBAC; outbox para n8n; abstração de mapas.')
    ON DUPLICATE KEY UPDATE version=version`);

  await pool.query(`INSERT INTO platform_changelog(version,title,summary,technical_notes)
    VALUES('0.2.0','Fundação administrativa e design system','Primeiro refinamento estrutural do novo MVP: identidade visual consistente, gestão de empresas, usuários e matriz de acessos.','Administração reorganizada; aprovação e crédito B2B; vínculo de vendedor responsável; contas individuais; ativação e desativação; RBAC reforçado; CSS unificado para todos os portais.')
    ON DUPLICATE KEY UPDATE version=version`);


  await pool.query(`INSERT INTO platform_changelog(version,title,summary,technical_notes)
    VALUES('0.3.0','Experiência e operação refinadas','A plataforma ganha uma camada visual mais madura e fluxos mais naturais para Comercial, Operação, Logística e Comprador B2B.','Novo shell visual e microinterações; criação de cotação sem prompts; mudança segura de status da cotação; carrinho B2B com quantidades e fechamento estruturado; fila operacional refinada; entregador pode registrar andamento da própria entrega; auditoria visível ao administrador; toasts e dialogs padronizados.')
    ON DUPLICATE KEY UPDATE version=version`);



  await pool.query(`INSERT INTO platform_changelog(version,title,summary,technical_notes)
    VALUES('0.4.0','Portal B2B multipágina e rastreamento operacional','A experiência do comprador passa a funcionar como um portal corporativo independente por páginas, enquanto a logística ganha uma torre de rastreamento com histórico, métricas, paradas e planejamento de rota.','Navegação multipágina por perfil; ambiente de usuários fictícios criado sob demanda pelo administrador; histórico GPS próprio; ingestão compatível com OsmAnd/Traccar Client; métricas de km, movimento, parada, velocidade e perda de sinal; busca de lugares com Google Places quando configurado e fallback OSM no beta; sequência de paradas e link de rota no Google Maps.')
    ON DUPLICATE KEY UPDATE version=version`);

  await pool.query(`INSERT INTO platform_changelog(version,title,summary,technical_notes)
    VALUES('0.4.1','Rastreamento legado e mapas estabilizados','O beta passa a receber em paralelo o mesmo dispositivo do A7W Track por uma ponte temporária, mantendo o celular apontado para o sistema antigo. O mapa deixa de usar diretamente os tiles públicos do OpenStreetMap.','Tiles do mapa passam por proxy autenticado usando LocationIQ; preparado para receber posições duplicadas pelo A7W Track sem alterar o Traccar Client; correção do bloqueio 403 do mapa.')
    ON DUPLICATE KEY UPDATE version=version`);


  await pool.query(`INSERT INTO platform_changelog(version,title,summary,technical_notes)
    VALUES('0.5.0','Frota e logística ao vivo','Rastreamento passa a atualizar automaticamente, ganha modo seguir veículo, gestão de frota, pontos de referência e primeiro núcleo de relatórios.','Vínculo dispositivo → veículo → motorista; referência da empresa no mapa; distância do veículo para a base; autocomplete de destinos; atualização live sem recarregar a página; preparação do subdomínio relatorios.a7w.com.br.')
    ON DUPLICATE KEY UPDATE version=version`);
  await pool.query(`INSERT INTO platform_changelog(version,title,summary,technical_notes)
    VALUES('0.5.1','Interface responsiva e navegação refinada','Ajustes de espaçamento, menus móveis, perfil, subnavegação logística e nova identidade visual de paradas e referência A7W.','Containers passam a respeitar limites em telas pequenas; menu lateral vira hambúrguer no celular; navegação logística vira faixa responsiva; perfil concentra configurações, atualizações e saída; paradas usam amarelo/âmbar e o vermelho fica reservado a desvios/alertas; marcador A7W passa a flutuar como referência fixa.')
    ON DUPLICATE KEY UPDATE version=version`);

  await pool.query(`INSERT INTO platform_changelog(version,title,summary,technical_notes)
    VALUES('0.6.0','Gestão de Frota e operação de entregas','O antigo núcleo de rastreamento evolui para Gestão de Frota: monitoramento com linha do tempo operacional, Rotas & Entregas, locais de interesse no mapa, comprovantes de conclusão e relatórios organizados por assunto.','Interface inspirada em boas práticas de plataformas de gestão de frota sem copiar produto terceiro; prova de conclusão com foto comprimida, recebedor, observação, GPS e horário; KPIs de atividades do dia; mapa com cartão flutuante do veículo; referências pesquisáveis e marcáveis; relatórios em gavetas e exportação CSV de resumo.')
    ON DUPLICATE KEY UPDATE version=version`);

  await pool.query(`INSERT INTO platform_changelog(version,title,summary,technical_notes)
    VALUES('0.7.0','Alertas, playback e rotas persistentes','Gestão de Frota ganha relatório de eventos, regras configuráveis, consumo estimado, playback animado do histórico e planejamento que pode começar antes da escolha do veículo.','Alertas calculados com GPS para excesso de velocidade, paradas planejadas/prováveis e paradas não planejadas; estrutura pronta para ignição/marcha lenta com hardware futuro; Telegram opcional; replay histórico com linha por faixa de velocidade; progresso de rota; sidebar retrátil; rotas continuam persistidas no MySQL entre versões.')
    ON DUPLICATE KEY UPDATE version=version`);

  await pool.query(`INSERT INTO platform_changelog(version,title,summary,technical_notes)
    VALUES('0.7.1','Playback e mapa refinados','Corrige o veículo gigante no playback, melhora responsividade/camadas, reposiciona controles e faz a prévia planejada acompanhar as ruas via LocationIQ quando disponível.','Ícone vetorial visto de cima com rotação contínua por bearing; playback sem marcadores duplicados e com 40x/80x; painel no canto inferior esquerdo; métricas em grade adaptativa; sidebar somente por clique; seta mobile animada; busca prioriza clientes e destinos A7W conhecidos; rota planejada usa Directions API com fallback visual; links com aparência de botão sem sublinhado.')
    ON DUPLICATE KEY UPDATE version=version`);

  await pool.query(`INSERT INTO platform_changelog(version,title,summary,technical_notes)
    VALUES('0.7.2','Sarah Rodrigues no Telegram','A integração do Telegram passa a ter identidade própria, status operacional, histórico do último envio e teste direto pelo painel.','Novo status persistente sem guardar segredos; verificação de token/chat via Bot API; botão de teste; alteração do nome do bot para Sarah Rodrigues; último sucesso, última tentativa, última falha e prévia da última mensagem ficam visíveis em Eventos & Alertas.')
    ON DUPLICATE KEY UPDATE version=version`);

  await pool.query(`INSERT INTO platform_changelog(version,title,summary,technical_notes)
    VALUES('0.7.3','Playback responsivo e Sarah diagnosticável','Refina a hierarquia visual do mapa no celular e elimina o risco de assets antigos quebrarem os novos controles do Telegram.','Painel do veículo pode ficar sobre o carro, no canto ou oculto; replay e legenda passam a respeitar a mesma pilha responsiva; data e filtros obedecem limites do container; playback ganha 160x; CSS/JS usam cache-busting; status da Sarah mostra última verificação e erros reais; botões de teste e nome usam DOM explícito e confirmação pela Bot API.')
    ON DUPLICATE KEY UPDATE version=version`);

  await pool.query(`INSERT INTO platform_changelog(version,title,summary,technical_notes)
    VALUES('0.8.2','Sarah Rodrigues com cérebro Gemini','A Sarah passa a receber texto e áudio pelo Telegram, entender intenções e responder com dados reais da A7W, incluindo localização e pino no mapa.','Webhook Telegram autenticado; allowlist pelo TELEGRAM_CHAT_ID; Gemini 2.5 Flash como cérebro linguístico; áudio OGG processado em memória; consultas operacionais executadas localmente no banco; histórico curto de conversa; botões para testar Gemini e ativar conversa.')
    ON DUPLICATE KEY UPDATE version=version`);



  await pool.query(`INSERT INTO platform_changelog(version,title,summary,technical_notes)
    VALUES('0.8.2','Sarah conversacional e observações inteligentes','Corrige a leitura das respostas Gemini Interactions e transforma a Sarah em uma assistente mais natural, com observações condicionais pelo Telegram.','Gemini 3.6 Flash com thinking low e extração robusta de output; personalidade conversacional original com presença de central de comando; observações persistentes para avisar quando motorista ficar online ou disponível; disponibilidade considera GPS online, veículo parado e ausência de entrega ativa; notificações one-shot com localização; status do painel mostra observações ativas.')
    ON DUPLICATE KEY UPDATE version=version`);

  const email = normalizeEmail(process.env.BOOTSTRAP_ADMIN_EMAIL || '');
  const pass = process.env.BOOTSTRAP_ADMIN_PASSWORD || '';
  if (email && pass) {
    const [rows] = await pool.execute('SELECT id FROM platform_users WHERE email=? LIMIT 1',[email]);
    if (!rows.length) {
      const hash = await hashPassword(pass);
      await pool.execute(`INSERT INTO platform_users(full_name,email,password_hash,role,active,email_verified_at) VALUES(?,?,?,?,1,NOW())`,[
        process.env.BOOTSTRAP_ADMIN_NAME || 'Administrador A7W', email, hash, 'admin'
      ]);
    }
  }
}

module.exports = { ensureSchema };
