const crypto = require('crypto');
const bcrypt = require('bcryptjs');

const ROLES = Object.freeze({
  ADMIN: 'admin',
  MANAGER: 'manager',
  SALES: 'sales',
  OPERATIONS: 'operations',
  LOGISTICS: 'logistics',
  BUYER: 'buyer'
});

function normalizeEmail(value='') {
  return String(value).trim().toLowerCase();
}
function validEmail(value='') {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalizeEmail(value));
}
function newCsrfToken() {
  return crypto.randomBytes(24).toString('hex');
}
async function hashPassword(password) {
  return bcrypt.hash(String(password), 12);
}
async function verifyPassword(password, hash) {
  return bcrypt.compare(String(password), String(hash || ''));
}
function roleHome(role) {
  return ({
    admin: '/admin',
    manager: '/admin',
    sales: '/commercial',
    operations: '/operations',
    logistics: '/logistics',
    buyer: '/client'
  })[role] || '/login';
}
function requireAuth(req, res, next) {
  if (!req.session?.user) return res.status(401).json({error:'AUTH_REQUIRED'});
  next();
}
function requireRole(...roles) {
  return (req,res,next) => {
    const role = req.session?.user?.role;
    if (!role) return res.status(401).json({error:'AUTH_REQUIRED'});
    if (!roles.includes(role)) return res.status(403).json({error:'FORBIDDEN'});
    next();
  };
}
function requireCsrf(req,res,next) {
  if (['GET','HEAD','OPTIONS'].includes(req.method)) return next();
  const token = req.get('x-csrf-token');
  if (!token || token !== req.session?.csrfToken) return res.status(403).json({error:'INVALID_CSRF'});
  next();
}

module.exports = { ROLES, normalizeEmail, validEmail, newCsrfToken, hashPassword, verifyPassword, roleHome, requireAuth, requireRole, requireCsrf };
